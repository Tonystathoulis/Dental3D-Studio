"""Dental3D Studio application package."""

__version__ = "0.4.0-alpha"
APP_NAME = "Dental3D Studio"
APP_STATUS = "Alpha"

def version_string() -> str:
    return f"{APP_NAME} — {APP_STATUS} v{__version__}"
