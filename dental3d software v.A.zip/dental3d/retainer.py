"""Preliminary Essix-style retainer generation from a dental scan mesh.

Thin-shell generation via surface offset. Uses PyVista/VTK only.
"""

import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

import numpy as np
import pyvista as pv

from dental3d.analysis.geometric_analysis import (
    ALGORITHM_VERSION,
    create_uncomputed_record,
)
from dental3d.domain.case_manager import DentalCase, ScanRecord
from dental3d.domain.retainer_record import RetainerRecord, utc_now
from pathlib import Path
from typing import Optional


class RetainerGenerationError(ValueError):
    """A retained surrogate cannot be generated safely."""


class RetainerParameterError(ValueError):
    """A design parameter value is out of range."""


@dataclass(frozen=True)
class RetainerGenerationInput:
    case: DentalCase
    scan: ScanRecord
    jaw: str
    max_distance: float
    min_distance: float
    coverage_trim_mm: float


def generate_retainer_surface(
    validated_mesh: pv.PolyData,
    jaw: str,
    max_distance: float,
    min_distance: float,
    coverage_trim_mm: float,
) -> pv.PolyData:
    if jaw not in ("upper", "lower"):
        raise RetainerGenerationError(f"Unsupported jaw: {jaw!r}")
    if max_distance <= 0 or min_distance <= 0:
        raise RetainerGenerationError("max_distance and min_distance must be positive")
    if max_distance < min_distance:
        raise RetainerGenerationError("max_distance must be >= min_distance")

    mesh = validated_mesh.copy()
    mesh = mesh.triangulate()
    mesh = _clean_mesh(mesh)
    if mesh.n_points < 3 or mesh.n_cells < 1:
        raise RetainerGenerationError("Mesh has no usable surface after cleaning")

    mesh.point_data["Normals"] = mesh.compute_normals(cell_normals=False, inplace=False)["Normals"]
    normals = np.asarray(mesh.point_data["Normals"], dtype=np.float64)
    normals = normals / (np.linalg.norm(normals, axis=1, keepdims=True) + 1e-12)

    bounds = mesh.bounds
    x_min, x_max, y_min, y_max, z_min, z_max = bounds
    x_len, y_len, z_len = (x_max - x_min), (y_max - y_min), (z_max - z_min)

    if jaw == "upper" and y_len >= x_len and y_len >= z_len:
        extent_axis = 1
    else:
        extent_axis = 0 if x_len >= z_len else 2

    points = np.asarray(mesh.points, dtype=np.float64)
    new_points = points + normals * max_distance

    shell = pv.PolyData(new_points, mesh.faces)
    shell = shell.clean()

    if coverage_trim_mm > 0:
        shell = _clip_to_coverage(shell, extent_axis)

    shell = _recompute_normals(shell)

    pts = np.asarray(shell.points)
    if not np.isfinite(pts).all():
        raise RetainerGenerationError("Generated shell contains non-finite coordinates")

    return shell


def generate_retainer_mesh(input: RetainerGenerationInput) -> pv.PolyData:
    return generate_retainer_surface(
        input.scan.mesh, input.jaw, input.max_distance, input.min_distance, input.coverage_trim_mm
    )


def _clean_mesh(mesh: pv.PolyData) -> pv.PolyData:
    if mesh.n_points == 0:
        raise RetainerGenerationError("Empty mesh supplied")
    try:
        mesh = mesh.clean()
    except Exception:
        pass
    pts = np.asarray(mesh.points)
    mask = np.isfinite(pts).all(axis=1)
    if not mask.all():
        mesh = mesh.extract_points(mask)
    return mesh


def _clip_to_coverage(shell: pv.PolyData, extent_axis: int) -> pv.PolyData:
    bounds = shell.bounds
    margin = 0.254  # 1mm

    if extent_axis == 1:
        x_lo, x_hi = bounds[0] + margin, bounds[1] - margin
        y_lo, y_hi = bounds[2] + margin, bounds[3] - margin
        z_lo, z_hi = bounds[4] + margin, bounds[5] - margin
    elif extent_axis == 0:
        x_lo, x_hi = bounds[0] + margin, bounds[1] - margin
        y_lo, y_hi = bounds[2] - margin, bounds[3] + margin
        z_lo, z_hi = bounds[4] - margin, bounds[5] + margin
    else:
        x_lo, x_hi = bounds[0] - margin, bounds[1] + margin
        y_lo, y_hi = bounds[2] - margin, bounds[3] + margin
        z_lo, z_hi = bounds[4] + margin, bounds[5] - margin

    return shell.clip_box([x_lo, y_lo, z_lo, x_hi, y_hi, z_hi])


def _recompute_normals(shell: pv.PolyData) -> pv.PolyData:
    try:
        shell.point_data["Normals"] = shell.compute_normals(cell_normals=False, inplace=False)["Normals"]
    except Exception:
        pass
    return shell


def validate_generated_mesh(mesh: pv.PolyData) -> tuple[bool, list[str]]:
    warnings_list = []

    if mesh is None or mesh.n_points < 3:
        return False, ["Generated mesh has fewer than 3 points"]

    pts = np.asarray(mesh.points, dtype=np.float64)
    if not np.isfinite(pts).all():
        return False, ["Generated mesh contains non-finite coordinates"]

    if mesh.n_cells < 1:
        return False, ["Generated mesh has no triangles"]

    valid = True
    # Check for degenerate geometry using face areas
    try:
        if mesh.n_faces > 0 and isinstance(mesh, pv.PolyData):
            faces = mesh.faces.reshape(-1, 4)
            if len(faces) > 0 and faces.shape[1] >= 4:
                triangles = faces[:, 1:4]
                tri_points = pts[triangles]
                v1 = tri_points[:, 1] - tri_points[:, 0]
                v2 = tri_points[:, 2] - tri_points[:, 0]
                cross = np.cross(v1, v2)
                areas = np.linalg.norm(cross, axis=1) / 2.0
                total_area = np.sum(areas)
                if total_area < 1e-12:
                    warnings_list.append("Mesh has effectively zero total surface area")
                    valid = False
    except Exception:
        pass

    # Watertightness check: count edges that belong to exactly one face
    try:
        if isinstance(mesh, pv.PolyData) and mesh.n_faces > 0:
            edges = mesh.extract_all_edges()
            if edges.n_cells > 0:
                # An edge shared by exactly 2 faces is manifold; 1 means boundary
                edge_counts = {}
                for cell in mesh.faces.reshape(-1, 4)[:, 1:]:
                    for i in range(3):
                        pair = tuple(sorted((int(cell[i]), int(cell[(i + 1) % 3]))))
                        edge_counts[pair] = edge_counts.get(pair, 0) + 1
                boundary_edges = sum(1 for c in edge_counts.values() if c == 1)
                if boundary_edges > 0:
                    warnings_list.append(
                        f"Mesh has {boundary_edges} boundary edge(s); not watertight"
                    )
    except Exception:
        pass

    # Self-intersection detection: note that this requires expensive computation
    # and is not performed by default. See module docstring for limitations.
    warnings_list.append(
        "Self-intersection detection is not implemented; generated shells may self-intersect"
    )

    return valid, warnings_list


def create_retainer_record(
    case: DentalCase,
    scan: ScanRecord,
    mesh_path: Path,
    mesh_sha256: str,
    file_size_bytes: int,
    point_count: int,
    face_count: int,
    jaw: str,
    parameters: dict,
    warnings_list: list[str],
    source_metadata: Optional[dict] = None,
) -> RetainerRecord:
    source_meta = {
        "label": scan.label,
        "original_filename": scan.original_filename,
        "file_format": scan.file_format,
        "unit": scan.unit,
        "coordinate_system": scan.coordinate_system,
        "anatomical_identity": scan.anatomical_identity,
        "validation_status": scan.validation_status,
    }
    if source_metadata:
        source_meta.update(source_metadata)

    return RetainerRecord(
        retainer_id="RET-" + np.random.bytes(6).hex().upper(),
        case_id=case.case_id,
        source_scan_id=scan.scan_id,
        jaw=jaw,
        generation_method="thin_surface_shell_offset",
        generation_method_version=ALGORITHM_VERSION,
        source_metadata=source_meta,
        source_sha256=scan.sha256,
        parameters=parameters,
        mesh_path=mesh_path,
        mesh_sha256=mesh_sha256,
        file_size_bytes=file_size_bytes,
        point_count=point_count,
        face_count=face_count,
        units=scan.unit,
        coordinate_system=scan.coordinate_system,
        coordinate_frame_id=scan.coordinate_frame_id,
        coordinate_system_evidence=scan.coordinate_system_evidence,
        anatomical_identity=scan.anatomical_identity,
        warnings=warnings_list,
    )
