"""Main Dental3D Studio window and UI event routing."""
from pathlib import Path
from dataclasses import replace
import sys

import pyvista as pv
import numpy as np
import vtk
from pyvistaqt import QtInteractor
from PySide6.QtCore import Qt, QSettings, Signal, QSize, QEvent, QObject
from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap, QFontMetrics
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout,
    QFrame, QGridLayout, QHBoxLayout, QLabel, QLineEdit, QListView, QListWidget, QMainWindow, QMessageBox,
    QPushButton, QRadioButton, QScrollArea, QDoubleSpinBox, QSlider, QSplitter, QStackedWidget, QTabBar, QTextEdit,
    QVBoxLayout, QWidget, QSizePolicy, QStyle, QStyledItemDelegate, QStyleOptionViewItem,
)

from dental3d.analysis.geometric_analysis import (
    AnalysisInputError, AnalysisPrerequisiteError, AnalysisRecord, SurfaceDistanceResult,
    analyze_mesh, compare_surfaces,
)
from dental3d.domain.case_manager import CaseManager, DentalCase, ScanMetadata, ScanRecord, SUPPORTED_UNITS
from dental3d.persistence.case_store import CaseStore, CaseStoreError, default_cases_root, list_retainer_ids, load_retainer_record
from dental3d.persistence.analysis_records import load_record, save_record
from dental3d.persistence.retainer_store import store_retainer_record, sha256_file, import_retainer_file, remove_retainer_record
from dental3d.retainer import (
    generate_retainer_surface,
    validate_generated_mesh,
    RetainerGenerationError,
    create_retainer_record,
)
from dental3d.domain.retainer_comparison import check_compatibility, compare_retainer_to_scan, RetainerComparisonError, RetainerComparisonRecord
from dental3d.validation.mesh_validation import ValidatedMesh, load_and_validate_mesh
from dental3d.validation.dataset_metadata import bits2bites_metadata_for_hash
from dental3d.visualization.demo_model import add_demo_arches
from dental3d import __version__ as APP_VERSION


class ButtonCursorEventFilter(QObject):
    """Ensure all QPushButton instances display a pointing hand cursor on hover and interaction."""

    def eventFilter(self, watched: QObject, event: QEvent) -> bool:
        if isinstance(watched, QPushButton):
            if event.type() in (QEvent.Type.Enter, QEvent.Type.Show, QEvent.Type.Paint):
                if watched.cursor().shape() != Qt.CursorShape.PointingHandCursor:
                    watched.setCursor(Qt.CursorShape.PointingHandCursor)
        return super().eventFilter(watched, event)


STYLE = """
QWidget { font-family: 'Segoe UI'; color: #252b32; font-size: 13px; }
QMainWindow { background: #0d1729; }
QWidget#centralCanvas { background: #0d1729; }
QFrame#panelCard, QFrame#footerCard, QFrame#viewportCard, QFrame#innerCard, QMessageBox, QDialog#appModalDialog {
    background: #ffffff; color: #252b32; border: 1px solid #cbd3dc; border-radius: 0px;
}
QLabel#muted { color: #68727c; }
QLabel#title { font-size: 18px; font-weight: 700; color: #20262d; }
QLabel#brand { font-size: 17px; font-weight: 750; color: #1a2e4a; }
QLabel#cardTitle { font-size: 11px; font-weight: 700; color: #4a5a6a; letter-spacing: 0.5px; }
QLabel#workspaceSectionTitle { font-size: 15px; font-weight: 700; color: #ffffff; letter-spacing: 0.4px; }
QPushButton { background: #ffffff; border: 1px solid transparent; border-radius: 0px; padding: 6px 12px; color: #28313a; font-weight: 600; min-height: 20px; }
QPushButton:hover { background: #f1f4f7; border: 1px solid #9ba8b7; }
QPushButton:pressed { background: #e3e9ef; border: 1px solid #718099; }
QPushButton:checked { background: #e7edf3; color: #1a2e4a; border: 1px solid #9ba8b7; }
QPushButton:disabled { color: #8c97a4; background: #f4f6f8; border: 1px solid transparent; }
QPushButton#primary { background: #e7edf3; color: #1a2e4a; border: 1px solid transparent; }
QPushButton#primary:hover { background: #dce3ea; border: 1px solid #718099; }
QPushButton#primary:pressed { background: #d3dce6; border: 1px solid #586a7d; }
QPushButton#primary:disabled { color: #8c97a4; background: #f4f6f8; border: 1px solid transparent; }
/* Compact action buttons for side panels - natural width, no stretching */
QPushButton.compactAction { min-width: 0; }
QCheckBox { spacing: 8px; color: #252b32; }
QCheckBox::indicator { width: 16px; height: 16px; border: 1px solid #7f8995; background: #ffffff; border-radius: 0px; }
QCheckBox::indicator:hover { border: 1px solid #586a7d; }
QCheckBox::indicator:checked { background: #4a5a6a; border: 1px solid #334150; }
QRadioButton { spacing: 6px; color: #252b32; font-weight: 500; }
QRadioButton::indicator { width: 16px; height: 16px; border: 1px solid #7f8995; background: #ffffff; border-radius: 0px; }
QRadioButton::indicator:hover { border: 1px solid #586a7d; }
QRadioButton::indicator:checked { background: #4a5a6a; border: 1px solid #334150; }
QLineEdit, QTextEdit { background: #ffffff; color: #202a35; border: 1px solid #c2cad3; border-radius: 0px; padding: 6px; }
QComboBox { background: #ffffff; color: #202a35; border: 1px solid #c2cad3; border-radius: 0px; padding: 6px 8px; min-height: 20px; }
QComboBox QAbstractItemView { background: #ffffff; color: #202a35; selection-background-color: #e3e9ef; selection-color: #202a35; border: 1px solid #c2cad3; outline: 0; padding: 4px; }
QComboBox QAbstractItemView::item { min-height: 26px; padding: 4px 8px; }
QSpinBox, QDoubleSpinBox {
    background: #ffffff;
    color: #202a35;
    border: 1px solid #c2cad3;
    border-radius: 0px;
    padding: 4px 8px;
    min-height: 22px;
    min-width: 90px;
}
QSpinBox:disabled, QDoubleSpinBox:disabled {
    background: #f4f6f8;
    color: #8c97a4;
    border: 1px solid #d8dee5;
}
QSpinBox::up-button, QDoubleSpinBox::up-button {
    subcontrol-origin: border;
    subcontrol-position: top right;
    width: 18px;
    background: #eef2f6;
    border-left: 1px solid #c2cad3;
    border-bottom: 1px solid #c2cad3;
}
QSpinBox::up-button:hover, QDoubleSpinBox::up-button:hover { background: #dde5ed; }
QSpinBox::down-button, QDoubleSpinBox::down-button {
    subcontrol-origin: border;
    subcontrol-position: bottom right;
    width: 18px;
    background: #eef2f6;
    border-left: 1px solid #c2cad3;
}
QSpinBox::down-button:hover, QDoubleSpinBox::down-button:hover { background: #dde5ed; }
QMenu { background: #ffffff; color: #202a35; border: 1px solid #c2cad3; }
QMenu::item { padding: 6px 20px; }
QMenu::item:selected { background: #e3e9ef; color: #202a35; }
QSplitter::handle { background: #0d1729; }
QSplitter::handle:horizontal { width: 8px; }
QSplitter::handle:hover { background: #6c7b8c; }
QScrollArea { border: 0; background: transparent; }
QScrollBar:vertical { background: #f1f3f5; width: 9px; margin: 0px; }
QScrollBar::handle:vertical { background: #aeb8c4; min-height: 25px; border-radius: 0px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: #f1f3f5; height: 9px; margin: 0px; }
QScrollBar::handle:horizontal { background: #aeb8c4; min-width: 25px; border-radius: 0px; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
QSlider::groove:horizontal { background: #d8dee5; height: 5px; border-radius: 0px; }
QSlider::sub-page:horizontal { background: #74879b; border-radius: 0px; }
QSlider::handle:horizontal { background: #ffffff; border: 1px solid #718099; width: 13px; margin: -5px 0; border-radius: 0px; }
QStatusBar { color: #d3dce6; background: transparent; }
QToolTip { color: #202a35; background: #ffffff; border: 1px solid #9ba8b7; border-radius: 0px; }
/* Header - white ribbon background */
QFrame#headerBar { background: #ffffff; border-bottom: 1px solid #cbd3dc; }
QFrame#casesTreatmentWorkspace { background: #0d1729; border: 0; }
QWidget#casesTreatmentContent { background: #0d1729; }
QLabel#appTitle { font-size: 17px; font-weight: 750; color: #1a2e4a; }
QLabel#appSubtitle { font-size: 11px; font-weight: 600; color: #68727c; }

/* Header action buttons - white background, subtle borders */
QPushButton[headerButton="true"] { background: #ffffff; border: 1px solid transparent; color: #1a2e4a; padding: 6px 12px; }
QPushButton[headerButton="true"]:hover { background: #f7f9fb; border: 1px solid #aeb8c4; }
QPushButton[headerButton="true"]:pressed { background: #eef1f4; border: 1px solid #9ba8b7; }
QPushButton[headerButton="true"]:disabled { color: #aeb8c4; background: #ffffff; border: 1px solid transparent; }

/* Workspace tabs - connected browser-style appearance */
QFrame#workspaceTabs { background: transparent; border: 0; }
QPushButton#workspaceTab { 
    background: #dce3eb; 
    color: #4a5a6a; 
    border: 1px solid #cbd3dc; 
    border-bottom: 1px solid #cbd3dc; 
    padding: 8px 20px; 
    font-weight: 700; 
    font-size: 12px; 
    min-width: 0; 
    text-align: center; 
}
QPushButton#workspaceTab:checked { 
    background: #ffffff; 
    color: #1a2e4a; 
    border: 1px solid #cbd3dc; 
    border-bottom: 1px solid #ffffff; 
}
QPushButton#workspaceTab:hover:!checked { 
    background: #e9eef3; 
    border-color: #aeb8c4; 
}
QPushButton#workspaceTab:disabled { 
    color: #7f8995; 
    background: #f2f3f5; 
    border: 1px solid transparent; 
}
"""

LIGHTING_MIN = 55  # Preserve the existing low-light bound.
LIGHTING_DEFAULT = 100
LIGHTING_MAX = 250


class CtrlRotateTrackballStyle(vtk.vtkInteractorStyleTrackballCamera):
    """Trackball controls with deliberate, documented left-drag bindings.

    VTK's standard trackball style maps Ctrl+left drag to *spin*, whereas
    this application documents Ctrl+left drag as camera rotation.  Plain left
    drags are ignored so the visible guidance remains accurate; Shift+left
    drag retains VTK's standard pan behavior.
    """

    def __init__(self) -> None:
        super().__init__()
        self._left_interaction = "none"

    def OnLeftButtonDown(self) -> None:
        interactor = self.GetInteractor()
        if interactor is None:
            return
        if interactor.GetControlKey():
            # Temporarily clear Ctrl so VTK enters ROTATE rather than SPIN.
            interactor.SetControlKey(0)
            try:
                super().OnLeftButtonDown()
            finally:
                interactor.SetControlKey(1)
            self._left_interaction = "rotate"
        elif interactor.GetShiftKey():
            super().OnLeftButtonDown()
            self._left_interaction = "pan"
        else:
            self._left_interaction = "none"

    def OnLeftButtonUp(self) -> None:
        if self._left_interaction == "none":
            return
        interactor = self.GetInteractor()
        if interactor is None:
            return
        if self._left_interaction == "rotate":
            interactor.SetControlKey(0)
            try:
                super().OnLeftButtonUp()
            finally:
                interactor.SetControlKey(1)
        else:
            super().OnLeftButtonUp()
        self._left_interaction = "none"


def configure_viewport_controls(plotter: QtInteractor) -> None:
    """Install the interaction mapping stated in the viewport footer."""
    style = CtrlRotateTrackballStyle()
    plotter.render_window.GetInteractor().SetInteractorStyle(style)
    # Keep the Python wrapper alive for the lifetime of the VTK interactor.
    plotter._dental3d_interaction_style = style

class ScanRowDelegate(QStyledItemDelegate):
    """Paint scan names with a compact remove affordance aligned on the right."""

    def paint(self, painter: QPainter, option: QStyleOptionViewItem, index) -> None:
        item_option = QStyleOptionViewItem(option)
        self.initStyleOption(item_option, index)
        text = item_option.text
        item_option.text = ""
        style = item_option.widget.style() if item_option.widget else QApplication.style()
        style.drawControl(QStyle.ControlElement.CE_ItemViewItem, item_option, painter, item_option.widget)

        has_scan = index.data(Qt.ItemDataRole.UserRole) is not None
        text_rect = item_option.rect.adjusted(9, 0, -34 if has_scan else -8, 0)
        painter.save()
        painter.setPen(QColor("#28313a"))
        metrics = QFontMetrics(item_option.font)
        painter.drawText(
            text_rect, int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft),
            metrics.elidedText(text, Qt.TextElideMode.ElideRight, text_rect.width()),
        )
        if has_scan:
            x_color = QColor("#a3424a" if option.state & QStyle.StateFlag.State_MouseOver else "#68727c")
            painter.setPen(QPen(x_color, 1.8, Qt.PenStyle.SolidLine, Qt.PenCapStyle.SquareCap))
            x = item_option.rect.right() - 20
            y = item_option.rect.center().y()
            painter.drawLine(x - 4, y - 4, x + 4, y + 4)
            painter.drawLine(x - 4, y + 4, x + 4, y - 4)
        painter.restore()


class ScanSelectionComboBox(QComboBox):
    """Case scan selector with an X hit area on each scan row."""

    removeRequested = Signal(str)
    _remove_gutter = 34

    def __init__(self, parent=None):
        super().__init__(parent)
        view = QListView(self)
        view.setItemDelegate(ScanRowDelegate(view))
        view.setMinimumWidth(260)
        view.setMouseTracking(True)
        self.setView(view)
        view.viewport().installEventFilter(self)

    def eventFilter(self, watched, event) -> bool:
        viewport = self.view().viewport()
        if (watched is viewport and event.type() == QEvent.Type.MouseButtonPress
                and event.button() == Qt.MouseButton.LeftButton):
            position = event.position().toPoint()
            index = self.view().indexAt(position)
            scan_id = index.data(Qt.ItemDataRole.UserRole) if index.isValid() else None
            if (scan_id is not None and position.x() >= viewport.width() - self._remove_gutter):
                self.hidePopup()
                self.removeRequested.emit(str(scan_id))
                return True
        return super().eventFilter(watched, event)


def make_label(text: str, name: str | None = None, wrap: bool = False) -> QLabel:
    item = QLabel(text)
    if name:
        item.setObjectName(name)
    item.setWordWrap(wrap)
    return item


def inner_card(title: str | None = None) -> tuple[QFrame, QVBoxLayout]:
    card = QFrame()
    card.setObjectName("innerCard")
    layout = QVBoxLayout(card)
    layout.setContentsMargins(12, 11, 12, 11)
    layout.setSpacing(8)
    if title:
        layout.addWidget(make_label(title.upper(), "cardTitle"))
    return card, layout


def apply_viewport_lighting(plotter: QtInteractor, level: int) -> None:
    """Apply camera-following key and diffuse fill lights to either viewport."""
    factor = max(LIGHTING_MIN, min(LIGHTING_MAX, int(level))) / 100.0
    plotter.set_background("#ffffff")
    try:
        plotter.renderer.RemoveAllLights()
    except Exception:
        pass
    lights = (
        ("headlight", (0.0, 0.0, 1.0), .40),
        ("scene light", (-0.6, -0.4, 1.0), .35),
        ("scene light", (0.5, 0.7, 1.0), .25),
    )
    for light_type, position, intensity in lights:
        try:
            plotter.add_light(pv.Light(
                position=position, focal_point=(0, 0, 0), color="#ffffff",
                intensity=intensity * factor, light_type=light_type))
        except Exception:
            pass


def configure_viewport_renderer(plotter: QtInteractor, level: int) -> None:
    """Reapply settings that scene-clearing operations can reset.

    Shadow maps are intentionally disabled: on open dental scans they can
    generate hard self-shadow patches that look like missing scan data.
    """
    apply_viewport_lighting(plotter, level)


def prepare_visualization_mesh(mesh: pv.PolyData) -> pv.PolyData:
    """Generate display normals on a copy without changing face winding or source data."""
    display_mesh = mesh.copy(deep=True)
    try:
        display_mesh.compute_normals(
            cell_normals=True, point_normals=True, split_vertices=False,
            consistent_normals=False, auto_orient_normals=False,
            non_manifold_traversal=False, inplace=True,
        )
    except Exception:
        # Preserve the original surface if a file's topology prevents normal generation.
        return mesh.copy(deep=True)
    return display_mesh


def scrollable_panel(compact: bool = False) -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setObjectName("panelCard")
    frame.setMinimumWidth(185 if compact else 170)
    outer = QVBoxLayout(frame)
    outer.setContentsMargins(0, 0, 0, 0)
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setMinimumWidth(0)
    scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
    inner = QWidget()
    inner.setStyleSheet("background:#ffffff; color:#252b32;")
    inner.setMinimumWidth(0)
    inner.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
    content = QVBoxLayout(inner)
    if compact:
        content.setContentsMargins(8, 11, 8, 11)
        content.setSpacing(9)
    else:
        content.setContentsMargins(15, 16, 15, 15)
        content.setSpacing(12)
    scroll.setWidget(inner)
    outer.addWidget(scroll)
    frame.content_layout = content
    return frame, content


def popout_view_icon() -> QIcon:
    """Return a small standard open-in-new-window square-and-arrow icon."""
    pixmap = QPixmap(24, 24)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(QPen(QColor("#28313a"), 1.8, Qt.PenStyle.SolidLine,
                        Qt.PenCapStyle.SquareCap, Qt.PenJoinStyle.MiterJoin))
    # Window outline with a gap in its upper-right corner, plus the outward arrow.
    painter.drawLine(3, 7, 11, 7)
    painter.drawLine(3, 7, 3, 20)
    painter.drawLine(3, 20, 16, 20)
    painter.drawLine(16, 20, 16, 13)
    painter.drawLine(9, 14, 20, 3)
    painter.drawLine(13, 3, 20, 3)
    painter.drawLine(20, 3, 20, 10)
    painter.end()
    return QIcon(pixmap)


def align_arch_pair_for_display(upper: pv.PolyData, lower: pv.PolyData) -> tuple[pv.PolyData, pv.PolyData]:
    """Make a display-only, roughly centered pair when source frames are unknown."""
    aligned = []
    for source in (upper, lower):
        mesh = source.copy(deep=True)
        xy = mesh.points[:, :2]
        centered = xy - xy.mean(axis=0)
        covariance = np.cov(centered, rowvar=False)
        eigenvalues, eigenvectors = np.linalg.eigh(covariance)
        if eigenvalues[-1] > max(eigenvalues[0], 1e-9) * 1.15:
            axis = eigenvectors[:, -1]
            angle = float(np.arctan2(axis[1], axis[0]))
            if angle > np.pi / 2:
                angle -= np.pi
            elif angle < -np.pi / 2:
                angle += np.pi
            mesh.rotate_z(-np.degrees(angle), inplace=True)
        x_values = mesh.points[:, 0]
        y_values = mesh.points[:, 1]
        half_width = max(float(np.ptp(x_values)) / 2, 1e-9)
        center_y = y_values[np.abs(x_values) <= half_width * .16]
        side_y = y_values[np.abs(x_values) >= half_width * .45]
        if center_y.size and side_y.size and float(np.median(center_y)) > float(np.median(side_y)):
            mesh.rotate_z(180, inplace=True)
        aligned.append(mesh)

    upper_mesh, lower_mesh = aligned
    upper_center = upper_mesh.center
    lower_center = lower_mesh.center
    span = max(upper_mesh.length, lower_mesh.length, 1.0)
    gap = span * 0.035
    for mesh, center, target_z in (
        (upper_mesh, upper_center, mesh_half_height(upper_mesh) + gap / 2),
        (lower_mesh, lower_center, -mesh_half_height(lower_mesh) - gap / 2),
    ):
        mesh.translate((-center[0], -center[1], target_z - center[2]), inplace=True)
    return upper_mesh, lower_mesh


def mesh_half_height(mesh: pv.PolyData) -> float:
    return max((mesh.bounds[5] - mesh.bounds[4]) / 2, 0.0)


class NewCaseDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("appModalDialog")
        self.setWindowTitle("Create case")
        self.setMinimumWidth(420)
        layout = QVBoxLayout(self)
        layout.addWidget(make_label("New dental case", "title"))
        layout.addWidget(make_label("A unique case ID will be assigned automatically. Do not enter a real patient name.", "muted", True))
        form = QFormLayout()
        self.patient_reference = QLineEdit()
        self.patient_reference.setMaxLength(120)
        self.patient_reference.setPlaceholderText("Optional pseudonymous reference")
        form.addRow("Patient reference", self.patient_reference)
        self.description = QTextEdit()
        self.description.setMaximumHeight(90)
        self.description.setPlaceholderText("Optional case description")
        form.addRow("Description", self.description)
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


class StageDialog(QDialog):
    """Small editor for the intentionally simple treatment-stage model."""
    def __init__(self, parent=None, stage=None, intermediate_only: bool = False):
        super().__init__(parent)
        self.setObjectName("appModalDialog")
        self.setWindowTitle("Add intermediate stage" if intermediate_only else "Edit treatment stage")
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.name_field = QLineEdit(stage.name if stage else "Intermediate stage")
        self.name_field.setMaxLength(120)
        self.notes_field = QTextEdit(stage.description if stage else "")
        self.notes_field.setMaximumHeight(90)
        self.date_field = QLineEdit(stage.stage_date or "" if stage else "")
        self.date_field.setPlaceholderText("Optional YYYY-MM-DD")
        form.addRow("Stage name", self.name_field)
        form.addRow("Clinical notes", self.notes_field)
        form.addRow("Stage date", self.date_field)
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


class ScanImportDialog(QDialog):
    def __init__(self, filename: str, parent=None, suggested_metadata: ScanMetadata | None = None):
        super().__init__(parent)
        self.suggested_metadata = suggested_metadata
        self.setObjectName("appModalDialog")
        self.setWindowTitle("Describe imported scan")
        self.setMinimumWidth(430)
        layout = QVBoxLayout(self)
        layout.addWidget(make_label("Add scan to active case", "title"))
        layout.addWidget(make_label(f"Source file: {filename}", "muted", True))
        form = QFormLayout()
        self.label_field = QLineEdit()
        self.label_field.setMaxLength(120)
        self.label_field.setPlaceholderText("Optional, e.g. Upper Jaw or Stage 1")
        form.addRow("Description label", self.label_field)
        self.unit_field = QComboBox()
        self.unit_field.addItem("Unknown", "unknown")
        for text, value in [("Millimeters (mm)", "mm"), ("Centimeters (cm)", "cm"),
                            ("Micrometers (µm)", "um"), ("Inches (in)", "in")]:
            self.unit_field.addItem(text, value)
        form.addRow("Coordinate unit", self.unit_field)
        if suggested_metadata and suggested_metadata.declared_units:
            suggested_unit = self.unit_field.findData(suggested_metadata.declared_units)
            if suggested_unit >= 0:
                self.unit_field.setCurrentIndex(suggested_unit)
        self.anatomical_identity_field = QComboBox()
        self.anatomical_identity_field.addItem("Unknown", "unknown")
        self.anatomical_identity_field.addItem("Upper arch", "upper_arch")
        self.anatomical_identity_field.addItem("Lower arch", "lower_arch")
        self.anatomical_identity_field.addItem("Whole dentition", "whole_dentition")
        self.anatomical_identity_field.addItem("Other region", "other")
        if suggested_metadata and suggested_metadata.anatomical_identity:
            suggested_region = self.anatomical_identity_field.findData(suggested_metadata.anatomical_identity)
            if suggested_region >= 0:
                self.anatomical_identity_field.setCurrentIndex(suggested_region)
        form.addRow("Anatomical region", self.anatomical_identity_field)
        self.anatomical_identity_detail = QLineEdit()
        self.anatomical_identity_detail.setMaxLength(120)
        self.anatomical_identity_detail.setPlaceholderText("Describe the specific anatomical region")
        self.anatomical_identity_detail.hide()
        self.anatomical_identity_field.currentIndexChanged.connect(
            lambda _index: self.anatomical_identity_detail.setVisible(
                self.anatomical_identity_field.currentData() == "other"))
        form.addRow("Other region detail", self.anatomical_identity_detail)
        self.coordinate_system_field = QComboBox()
        self.coordinate_system_field.addItem("Unknown", "unknown")
        self.coordinate_system_field.addItem("RAS", "RAS")
        self.coordinate_system_field.addItem("LPS", "LPS")
        self.coordinate_system_field.addItem("Local frame", "local")
        self.coordinate_system_field.setEditable(True)
        self.coordinate_system_field.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
        if suggested_metadata and suggested_metadata.coordinate_system:
            self.coordinate_system_field.setCurrentText(suggested_metadata.coordinate_system)
        form.addRow("Coordinate convention", self.coordinate_system_field)
        self.coordinate_frame_id_field = QLineEdit()
        self.coordinate_frame_id_field.setMaxLength(160)
        self.coordinate_frame_id_field.setPlaceholderText("Shared frame ID, if documented")
        if suggested_metadata and suggested_metadata.coordinate_frame_id:
            self.coordinate_frame_id_field.setText(suggested_metadata.coordinate_frame_id)
        form.addRow("Frame identity", self.coordinate_frame_id_field)
        self.coordinate_evidence_field = QLineEdit()
        self.coordinate_evidence_field.setMaxLength(500)
        self.coordinate_evidence_field.setPlaceholderText("Source documenting convention and frame identity")
        if suggested_metadata and suggested_metadata.coordinate_system_evidence:
            self.coordinate_evidence_field.setText(suggested_metadata.coordinate_system_evidence)
        form.addRow("Coordinate evidence", self.coordinate_evidence_field)
        layout.addLayout(form)
        layout.addWidget(make_label(
            "Unit, anatomy, and coordinate frame are user-provided metadata unless supported by cited source documentation.",
            "muted", True))
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


class SimulationPopoutWindow(QMainWindow):
    """Independent, interactive viewer for the currently displayed model."""

    closed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Dental3D Studio · Simulation View")
        self.setWindowIcon(QIcon(str(Path(__file__).resolve().parents[2] / "assets" / "dental3d_studio_icon.ico")))
        self.resize(1280, 860)
        self.setMinimumSize(720, 520)
        root = QWidget(self)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self.lighting_level = max(
            LIGHTING_MIN, min(LIGHTING_MAX, int(getattr(parent, "lighting_level", LIGHTING_DEFAULT))))
        self.stack = QStackedWidget(root)
        self.plotter = QtInteractor(root)
        configure_viewport_controls(self.plotter)
        configure_viewport_renderer(self.plotter, self.lighting_level)
        self.render_page = QWidget(root)
        render_layout = QGridLayout(self.render_page)
        render_layout.setContentsMargins(0, 0, 0, 0)
        render_layout.addWidget(self.plotter.interactor, 0, 0)
        self.controls_hint = QLabel("CTRL DRAG TO ROTATE · SHIFT + DRAG TO PAN", self.render_page)
        self.controls_hint.setAlignment(Qt.AlignCenter)
        self.controls_hint.setStyleSheet("color:#68727c; font-size:10px; letter-spacing:0.6px; font-weight:500; background:transparent; padding:10px;")
        self.controls_hint.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        render_layout.addWidget(self.controls_hint, 0, 0, Qt.AlignBottom | Qt.AlignHCenter)
        self.stack.addWidget(self.render_page)
        self.empty_label = QLabel("No scan or simulation is currently loaded.")
        self.empty_label.setAlignment(Qt.AlignCenter)
        self.empty_label.setStyleSheet("color:#68727c; background:#ffffff; font-size:16px; padding:32px;")
        self.stack.addWidget(self.empty_label)
        layout.addWidget(self.stack, 1)
        self.setCentralWidget(root)
        self.setStyleSheet("QMainWindow { background:#ffffff; }")
        for btn in self.findChildren(QPushButton):
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.set_simulation("empty")
        try:
            self.plotter.render_window.GetInteractor().AddObserver(
                "InteractionEvent", self._on_interaction)
            self.plotter.render_window.GetInteractor().AddObserver(
                "EndInteractionEvent", self._on_interaction)
        except Exception:
            pass

    def set_simulation(self, mode: str, scene: list[dict] | None = None, camera=None) -> None:
        """Mirror the main renderer's geometry, transforms, visibility, and camera."""
        try:
            self.plotter.clear(clear_camera=False)
        except TypeError:
            self.plotter.clear()
        self.lighting_level = max(
            LIGHTING_MIN, min(LIGHTING_MAX, int(getattr(self.parent(), "lighting_level", LIGHTING_DEFAULT))))
        configure_viewport_renderer(self.plotter, self.lighting_level)
        if camera is not None:
            self.plotter.renderer.SetActiveCamera(camera)
        if mode not in {"imported", "demo"} or not scene:
            self.stack.setCurrentWidget(self.empty_label)
            self.plotter.render()
            return
        for item in scene:
            try:
                actor = self.plotter.add_mesh(
                    item["mesh"], color=item["color"], opacity=item["opacity"],
                    ambient=item["ambient"], diffuse=item["diffuse"],
                    specular=item["specular"], specular_power=item["specular_power"],
                    smooth_shading=False, lighting=True, show_edges=item["show_edges"],
                    culling=False,
                )
                actor.prop.SetInterpolationToPhong()
                actor.prop.SetBackfaceCulling(False)
                actor.SetOrigin(item["origin"])
                actor.SetPosition(item["position"])
                actor.SetOrientation(item["orientation"])
                actor.SetScale(item["scale"])
                actor.SetVisibility(item["visibility"])
            except Exception:
                continue
        self.plotter.add_axes(line_width=1)
        self.stack.setCurrentWidget(self.render_page)
        self.plotter.render()

    def _on_interaction(self, *_args) -> None:
        owner = self.parent()
        if owner is not None and hasattr(owner, "_render_popout_view"):
            owner._render_popout_view()

    def closeEvent(self, event) -> None:
        self.plotter.close()
        self.closed.emit()
        super().closeEvent(event)


class DentalStudioWindow(QMainWindow):
    """Main window. UI handlers delegate validation, state, and persistence to modules."""

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(f"Dental3D Studio — Alpha v{APP_VERSION}")
        self.setWindowIcon(QIcon(str(Path(__file__).resolve().parents[2] / "assets" / "dental3d_studio_icon.ico")))
        self.resize(1440, 900)
        self.setMinimumSize(1000, 680)
        self.settings = QSettings("Dental3DStudio", "Dental3DStudio")
        cases_root = self.settings.value("case_root", str(default_cases_root()))
        self.case_store = CaseStore(cases_root)
        self.case_manager = CaseManager()
        self.case_dirty = False
        self.lighting_level = max(
            LIGHTING_MIN,
            min(LIGHTING_MAX, int(self.settings.value("lighting_intensity", LIGHTING_DEFAULT))),
        )
        self.settings_lighting_slider: QSlider | None = None
        self.imported_mesh: ValidatedMesh | None = None
        self.display_meshes: dict[str, pv.PolyData] = {}
        self.quick_view_mode = False
        self.quick_view_meshes: dict[str, ValidatedMesh] = {}
        self.quick_view_paths: list[Path] = []
        self.analysis_unit_overrides: dict[str, str] = {}
        self.selected_stage_id: str | None = None
        self.display_pair_source_aligned = False
        self.render_meshes: dict[str, pv.PolyData] = {}
        self.display_mode = "empty"
        self.upper_visible = True
        self.lower_visible = True
        self.treatment_visible = False
        self.contact_visible = False
        self.alternative_design = False
        self.treatment_opacity = .78
        self.deviation_visible = False
        self.loaded_record: dict | None = None
        self.current_analysis_record: AnalysisRecord | None = None
        self.surface_distance_result: SurfaceDistanceResult | None = None
        self.analysis_mode = "mesh_characteristics"
        self.analysis_type_combo = None
        self.compare_scan_combo = None
        self.alignment_confirmation = None
        self.comparison_unit_combo = None
        self.thresholds_input = None
        self.sample_limit_combo = None
        self.jaw_actors: dict[str, list] = {"upper": [], "lower": []}
        self.overlay_actors: list = []
        self.popout_window: SimulationPopoutWindow | None = None
        # Retainer state tracking
        self.retainers: dict[str, RetainerRecord] = {}  # retainer_id -> record
        self.retainer_actors: dict[str, object] = {}  # retainer_id -> plotter actor
        self.retainer_visible: dict[str, bool] = {}
        self.retainer_opacity: dict[str, float] = {}
        self.selected_retainer_id: str | None = None
        # Comparison state
        self.comparison_mode: str | None = None  # "retainer_vs_scan" or None
        self.compare_retainer_id: str | None = None
        self.compare_scan_id: str | None = None

        root = QWidget()
        root.setObjectName("centralCanvas")
        root_layout = QVBoxLayout(root)
        root_layout.setContentsMargins(12, 0, 12, 6)
        root_layout.setSpacing(0)
        self.headerBar = self._build_header()
        root_layout.addWidget(self.headerBar)
        self.workspace_tabs = self._build_workspace_tabs()
        root_layout.addWidget(self.workspace_tabs)

        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(8)
        self.scan_left_panel = self._build_scan_left_panel()
        self.viewport_panel = self._build_viewport()
        self.right_panel = self._build_right_panel()
        self.scan_left_panel.setMinimumWidth(185)
        self.viewport_panel.setMinimumWidth(300)
        self.right_panel.setMinimumWidth(215)
        self.splitter.addWidget(self.scan_left_panel)
        self.splitter.addWidget(self.viewport_panel)
        self.splitter.addWidget(self.right_panel)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.setStretchFactor(2, 0)
        self.splitter.setSizes([245, 785, 335])

        self.cases_treatment_panel = self._build_cases_treatment_panel()

        self.workspaces = QStackedWidget()
        self.workspaces.addWidget(self.splitter)
        self.workspaces.addWidget(self.cases_treatment_panel)
        root_layout.addWidget(self.workspaces, 1)
        root_layout.addSpacing(6)
        root_layout.addWidget(self._build_footer())

        # Backward-compatible alias for existing tests.
        self.left_panel = self.cases_treatment_panel

        # Set application icon from the ICO asset.
        icon_path = Path(__file__).resolve().parents[2] / "assets" / "dental3d_studio_icon.ico"
        self.setWindowIcon(QIcon(str(icon_path)))
        self.setCentralWidget(root)
        self.statusBar().setSizeGripEnabled(False)
        self.statusBar().setFixedHeight(20)
        self.statusBar().setContentsMargins(0, 0, 0, 0)
        self.statusBar().setStyleSheet("QStatusBar{background:transparent;border:0;color:#bdc9dc;}")

        configure_viewport_renderer(self.plotter, self.lighting_level)
        self.plotter.enable_anti_aliasing("ssaa")
        self._button_cursor_filter = ButtonCursorEventFilter(self)
        app_instance = QApplication.instance()
        if app_instance is not None:
            app_instance.installEventFilter(self._button_cursor_filter)
        for btn in self.findChildren(QPushButton):
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._refresh_case_controls()
        self._show_empty_state()
        self._refresh_right_panel()

    def _build_header(self) -> QFrame:
        """Application header: logo, title, subtitle, action buttons, workspace tabs anchor."""
        bar = QFrame()
        bar.setObjectName("headerBar")
        bar.setFixedHeight(52)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(16, 8, 16, 8)
        layout.setSpacing(10)
        logo_path = Path(__file__).resolve().parents[2] / "assets" / "dental3d_studio_logo.svg"
        logo = QLabel()
        logo.setPixmap(QPixmap(str(logo_path)).scaled(28, 28, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        logo.setFixedSize(30, 30)
        logo.setAccessibleName("Dental3D Studio logo")
        layout.addWidget(logo)
        title_col = QVBoxLayout()
        title_col.setSpacing(0)
        title_col.setContentsMargins(0, 0, 0, 0)
        title_col.addWidget(make_label("Dental3D Studio — Alpha", "appTitle"))
        title_col.addWidget(make_label("Dental scan organization and 3D surface review", "appSubtitle"))
        layout.addLayout(title_col)
        layout.addStretch(1)
        self.case_badge = QPushButton("No case open")
        self.case_badge.setEnabled(False)
        self.case_badge.setProperty("headerButton", True)
        layout.addWidget(self.case_badge)
        self.quick_view_exit_button = QPushButton("Exit Quick View")
        self.quick_view_exit_button.clicked.connect(self._exit_quick_view)
        self.quick_view_exit_button.hide()
        self.quick_view_exit_button.setProperty("headerButton", True)
        layout.addWidget(self.quick_view_exit_button)
        open_button = QPushButton("Open")
        open_button.clicked.connect(self.open_item)
        open_button.setProperty("headerButton", True)
        layout.addWidget(open_button)
        self.save_button = QPushButton("Save")
        self.save_button.clicked.connect(self.save_analysis_record)
        self.save_button.setProperty("headerButton", True)
        layout.addWidget(self.save_button)
        self.reset_button = QPushButton("Reset View")
        self.reset_button.clicked.connect(self.reset_camera)
        self.reset_button.setProperty("headerButton", True)
        layout.addWidget(self.reset_button)
        self.settings_button = QPushButton("Settings")
        self.settings_button.clicked.connect(self.show_settings)
        self.settings_button.setProperty("headerButton", True)
        layout.addWidget(self.settings_button)
        return bar

    def _build_workspace_tabs(self) -> QFrame:
        """Connected browser-style workspace tabs.

        Active tab has white background matching the workspace surface.
        Inactive tab has subtle neutral background.
        No visible separator line between active tab and content below.
        """
        container = QFrame()
        container.setObjectName("workspaceTabs")
        container.setFixedHeight(36)
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.sim_tab_button = QPushButton("Scan Simulation")
        self.sim_tab_button.setObjectName("workspaceTab")
        self.sim_tab_button.setCheckable(True)
        self.sim_tab_button.setChecked(True)
        self.sim_tab_button.clicked.connect(lambda: self._set_workspace_index(0))
        layout.addWidget(self.sim_tab_button)

        self.cases_tab_button = QPushButton("Cases & Treatment")
        self.cases_tab_button.setObjectName("workspaceTab")
        self.cases_tab_button.setCheckable(True)
        self.cases_tab_button.clicked.connect(lambda: self._set_workspace_index(1))
        layout.addWidget(self.cases_tab_button)

        layout.addStretch(1)

        # Backward-compatible QTabBar-like API for existing tests and callers.
        container.tabText = lambda index: ["Scan Simulation", "Cases & Treatment"][index]
        container.count = lambda: 2
        container.setCurrentIndex = self._set_workspace_index

        return container

    def _set_workspace_index(self, index: int) -> None:
        """Switch workspace via button-style tabs, keeping shared case/scan state."""
        self.workspaces.setCurrentIndex(index)
        self.sim_tab_button.setChecked(index == 0)
        self.cases_tab_button.setChecked(index == 1)

    def _workspace_tab_changed(self, index: int) -> None:
        """Switch presentation only; active case, viewport, and analysis state are shared."""
        self.workspaces.setCurrentIndex(index)
        self.sim_tab_button.setChecked(index == 0)
        self.cases_tab_button.setChecked(index == 1)






    def _build_scan_left_panel(self) -> QFrame:
        """Visualization + scan management controls for the Scan & Simulation workspace."""
        panel, layout = scrollable_panel(compact=True)
        layout.addWidget(make_label("Simulation controls", "title", True))

        jaw_card, jaw_layout = inner_card("Jaw visibility")
        self.upper_button = QPushButton("Upper arch")
        self.upper_button.setCheckable(True)
        self.upper_button.setChecked(True)
        self.upper_button.clicked.connect(self._set_upper_visible)
        jaw_layout.addWidget(self.upper_button)
        self.lower_button = QPushButton("Lower arch")
        self.lower_button.setCheckable(True)
        self.lower_button.setChecked(True)
        self.lower_button.clicked.connect(self._set_lower_visible)
        jaw_layout.addWidget(self.lower_button)
        self.demo_preview_button = QPushButton("Illustrative Preview")
        self.demo_preview_button.setToolTip("Show the illustrative two-arch model; this is not scan data or analysis")
        self.demo_preview_button.clicked.connect(self._toggle_demo_preview)
        jaw_layout.addWidget(self.demo_preview_button)
        self.jaw_card = jaw_card
        layout.addWidget(jaw_card)

        # Scan import and imported-scan management
        files_card, files_layout = inner_card("Scans & unassigned")
        self.scan_selection_card = files_card
        self.scan_combo = ScanSelectionComboBox()
        self.scan_combo.setToolTip("Select a scan. Click the X at the far right of a scan row to remove it from this case.")
        self.scan_combo.currentIndexChanged.connect(self._scan_selection_changed)
        self.scan_combo.removeRequested.connect(self.remove_selected_scan)
        files_layout.addWidget(self.scan_combo)
        self.file_state_label = make_label("No external scan loaded", "muted", True)
        files_layout.addWidget(self.file_state_label)
        self.import_scan_button = QPushButton("Import scan")
        self.import_scan_button.clicked.connect(self.open_item)
        files_layout.addWidget(self.import_scan_button)
        layout.addWidget(files_card)

        # Compact current-case card - only Open Case, Save Case, Close Case
        case_card, case_layout = inner_card("Current case")
        self.case_sim_card = case_card
        self.open_case_sim_button = QPushButton("Open Case")
        self.open_case_sim_button.clicked.connect(self.open_case)
        case_layout.addWidget(self.open_case_sim_button)
        self.save_case_sim_button = QPushButton("Save Case")
        self.save_case_sim_button.clicked.connect(self.save_case)
        case_layout.addWidget(self.save_case_sim_button)
        self.close_case_sim_button = QPushButton("Close Case")
        self.close_case_sim_button.clicked.connect(self.close_case)
        case_layout.addWidget(self.close_case_sim_button)
        layout.addWidget(case_card)

        treatment_card, treatment_layout = inner_card("Illustrative stages")
        self.treatment_card = treatment_card
        treatment_layout.addWidget(make_label("Illustrative controls are unavailable until a scan is loaded.", "muted", True))
        self.treatment_button = QPushButton("Show treatment")
        self.treatment_button.setToolTip("Show the illustrative treatment concept")
        self.treatment_button.setCheckable(True)
        self.treatment_button.clicked.connect(self._toggle_treatment)
        treatment_layout.addWidget(self.treatment_button)
        treatment_layout.addWidget(make_label("Treatment overlay opacity", "muted", True))
        self.treatment_opacity_slider = QSlider(Qt.Horizontal)
        self.treatment_opacity_slider.setRange(15, 100)
        self.treatment_opacity_slider.setValue(78)
        self.treatment_opacity_slider.valueChanged.connect(self._set_treatment_opacity)
        treatment_layout.addWidget(self.treatment_opacity_slider)
        self.contact_button = QPushButton("Contact map")
        self.contact_button.setToolTip("Show the simulated contact map")
        self.contact_button.setCheckable(True)
        self.contact_button.clicked.connect(self._toggle_contacts)
        treatment_layout.addWidget(self.contact_button)
        alt_button = QPushButton("Alt. design")
        alt_button.clicked.connect(self._toggle_alternative)
        treatment_layout.addWidget(alt_button)
        self.deviation_button = QPushButton("Deviation map")
        self.deviation_button.setToolTip("Show the simulated deviation preview")
        self.deviation_button.setCheckable(True)
        self.deviation_button.clicked.connect(self._toggle_deviation)
        treatment_layout.addWidget(self.deviation_button)
        treatment_layout.addWidget(make_label("Comparison preview variants", "muted"))
        self.demo_variant_combo = QComboBox()
        self.demo_variant_combo.addItems(["Variant A", "Variant B"])
        self.demo_variant_combo.currentIndexChanged.connect(self._set_demo_variant)
        treatment_layout.addWidget(self.demo_variant_combo)
        self.treatment_type = QComboBox()
        self.treatment_type.addItems(["Retainer", "Crown", "Implant"])
        treatment_layout.addWidget(self.treatment_type)
        layout.addWidget(treatment_card)
        layout.addStretch(1)
        return panel

    def _build_cases_treatment_panel(self) -> QFrame:
        """Cases & Treatment workspace: Case Information left, Treatment Stages middle, Preliminary Retainer right."""
        container = QFrame()
        container.setObjectName("casesTreatmentWorkspace")
        outer = QVBoxLayout(container)
        outer.setContentsMargins(0, 8, 0, 0)
        outer.setSpacing(0)

        scroll = QScrollArea(container)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        scroll.setStyleSheet("QScrollArea { border: 0; background: transparent; }")

        content = QWidget()
        content.setObjectName("casesTreatmentContent")
        layout = QHBoxLayout(content)
        layout.setContentsMargins(0, 0, 0, 8)
        layout.setSpacing(12)

        # 1. Left: Case Information panel (compact, similar to Current Case in Scan & Sim)
        case_panel = QFrame()
        case_panel_layout = QVBoxLayout(case_panel)
        case_panel_layout.setContentsMargins(0, 0, 0, 0)
        case_panel_layout.setSpacing(8)
        case_panel_layout.addWidget(make_label("Case Information", "workspaceSectionTitle"))

        case_card, case_card_layout = inner_card("Current case")
        self.case_info_card = case_card
        self.case_id_label = make_label("No case open", "title")
        self.case_id_label.setWordWrap(True)
        self.case_reference_label = make_label("No patient reference", "muted", True)
        self.case_description_label = make_label("Create a case to organize imported scans.", "muted", True)
        self.case_dates_label = make_label("", "muted", True)
        case_card_layout.addWidget(self.case_id_label)
        case_card_layout.addWidget(self.case_reference_label)
        case_card_layout.addWidget(self.case_description_label)
        case_card_layout.addWidget(self.case_dates_label)
        case_card_layout.addSpacing(6)

        btn_layout = QVBoxLayout()
        btn_layout.setSpacing(6)
        self.new_case_button = QPushButton("New Case")
        self.new_case_button.clicked.connect(self.create_case)
        self.open_case_button = QPushButton("Open Case")
        self.open_case_button.clicked.connect(self.open_case)
        self.save_case_button = QPushButton("Save Case")
        self.save_case_button.clicked.connect(self.save_case)
        self.close_case_button = QPushButton("Close Case")
        self.close_case_button.clicked.connect(self.close_case)
        for button in (self.new_case_button, self.open_case_button, self.save_case_button, self.close_case_button):
            button.setMinimumHeight(30)
            btn_layout.addWidget(button)
        case_card_layout.addLayout(btn_layout)

        case_panel_layout.addWidget(case_card)
        case_panel_layout.addStretch(1)

        case_panel.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        case_panel.setFixedWidth(255)

        # 2. Middle: Treatment Stages panel
        stages_panel = QFrame()
        stages_panel_layout = QVBoxLayout(stages_panel)
        stages_panel_layout.setContentsMargins(0, 0, 0, 0)
        stages_panel_layout.setSpacing(8)
        stages_panel_layout.addWidget(make_label("Treatment Stages", "workspaceSectionTitle"))

        stages_card, stages_card_layout = inner_card("Stages")
        self.stages_card = stages_card
        self.stage_combo = QComboBox()
        self.stage_combo.currentIndexChanged.connect(self._stage_selection_changed)
        stages_card_layout.addWidget(self.stage_combo)

        self.stage_cards_container = QWidget()
        self.stage_cards_layout = QVBoxLayout(self.stage_cards_container)
        self.stage_cards_layout.setContentsMargins(0, 0, 0, 0)
        self.stage_cards_layout.setSpacing(5)
        stages_card_layout.addWidget(self.stage_cards_container)

        self.stage_summary_label = make_label("Open a case to organize treatment stages.", "muted", True)
        stages_card_layout.addWidget(self.stage_summary_label)

        self.add_stage_button = QPushButton("Add intermediate stage")
        self.add_stage_button.setMinimumHeight(30)
        self.add_stage_button.clicked.connect(self.add_intermediate_stage)
        stages_card_layout.addWidget(self.add_stage_button)

        stage_actions = QHBoxLayout()
        stage_actions.setSpacing(6)
        self.edit_stage_button = QPushButton("Edit")
        self.edit_stage_button.clicked.connect(self.edit_selected_stage)
        self.stage_up_button = QPushButton("Move up")
        self.stage_up_button.clicked.connect(lambda: self._move_selected_stage(-1))
        self.stage_down_button = QPushButton("Move down")
        self.stage_down_button.clicked.connect(lambda: self._move_selected_stage(1))
        self.delete_stage_button = QPushButton("Delete")
        self.delete_stage_button.clicked.connect(self.delete_selected_stage)
        for button in (self.edit_stage_button, self.stage_up_button, self.stage_down_button, self.delete_stage_button):
            button.setMinimumHeight(28)
            stage_actions.addWidget(button)
        stages_card_layout.addLayout(stage_actions)

        stages_card_layout.addSpacing(4)
        stages_card_layout.addWidget(make_label("Selected scan stage", "cardTitle"))
        self.scan_stage_combo = QComboBox()
        self.scan_stage_combo.currentIndexChanged.connect(self._scan_stage_changed)
        stages_card_layout.addWidget(self.scan_stage_combo)

        stages_panel_layout.addWidget(stages_card)
        stages_panel_layout.addStretch(1)

        stages_panel.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        stages_panel.setMinimumWidth(340)
        stages_panel.setMaximumWidth(440)

        # 3. Right: Preliminary Retainer panel (2 sub-columns: Generate/Import | Retainers/Comparison)
        retainer_panel = QFrame()
        retainer_panel_layout = QVBoxLayout(retainer_panel)
        retainer_panel_layout.setContentsMargins(0, 0, 0, 0)
        retainer_panel_layout.setSpacing(8)
        retainer_panel_layout.addWidget(make_label("Preliminary Retainer", "workspaceSectionTitle"))

        # Two-column container for retainer content to avoid excessive height and waste of width
        retainer_columns = QWidget()
        retainer_cols_layout = QHBoxLayout(retainer_columns)
        retainer_cols_layout.setContentsMargins(0, 0, 0, 0)
        retainer_cols_layout.setSpacing(12)

        # Left sub-column: Generate + Import
        gen_col = QVBoxLayout()
        gen_col.setContentsMargins(0, 0, 0, 0)
        gen_col.setSpacing(8)

        retainer_card, retainer_card_layout = inner_card("Generate Preliminary Retainer")
        retainer_card_layout.addWidget(make_label("Source scan", "cardTitle", True))
        self.retainer_source_combo = QComboBox()
        self.retainer_source_combo.setMinimumWidth(0)
        self.retainer_source_combo.addItem("No scan available", None)
        retainer_card_layout.addWidget(self.retainer_source_combo)

        jaw_row = QHBoxLayout()
        jaw_row.setContentsMargins(0, 0, 0, 0)
        jaw_row.setSpacing(12)
        jaw_row.addWidget(make_label("Jaw", "cardTitle", True))
        self.retainer_jaw_upper = QRadioButton("Upper")
        self.retainer_jaw_upper.setChecked(True)
        self.retainer_jaw_lower = QRadioButton("Lower")
        jaw_row.addWidget(self.retainer_jaw_upper)
        jaw_row.addWidget(self.retainer_jaw_lower)
        jaw_row.addStretch(1)
        retainer_card_layout.addLayout(jaw_row)

        params_grid = QGridLayout()
        params_grid.setContentsMargins(0, 0, 0, 0)
        params_grid.setHorizontalSpacing(10)
        params_grid.setVerticalSpacing(6)
        params_grid.addWidget(make_label("Shell thickness", "cardTitle", True), 0, 0)
        self.retainer_thickness_spin = QDoubleSpinBox()
        self.retainer_thickness_spin.setRange(0.1, 5.0)
        self.retainer_thickness_spin.setSingleStep(0.1)
        self.retainer_thickness_spin.setValue(0.8)
        self.retainer_thickness_spin.setSuffix(" mm")
        self.retainer_thickness_spin.setMinimumWidth(95)
        params_grid.addWidget(self.retainer_thickness_spin, 0, 1)

        params_grid.addWidget(make_label("Coverage trim", "cardTitle", True), 1, 0)
        self.retainer_trim_spin = QDoubleSpinBox()
        self.retainer_trim_spin.setRange(0.0, 10.0)
        self.retainer_trim_spin.setSingleStep(0.5)
        self.retainer_trim_spin.setValue(1.0)
        self.retainer_trim_spin.setSuffix(" mm")
        self.retainer_trim_spin.setMinimumWidth(95)
        params_grid.addWidget(self.retainer_trim_spin, 1, 1)
        retainer_card_layout.addLayout(params_grid)

        self.retainer_generate_button = QPushButton("Generate Retainer")
        self.retainer_generate_button.setObjectName("primary")
        self.retainer_generate_button.setMinimumHeight(32)
        self.retainer_generate_button.clicked.connect(self._generate_retainer)
        self.retainer_generate_button.setEnabled(False)
        retainer_card_layout.addWidget(self.retainer_generate_button)

        self.retainer_save_button = QPushButton("Save Retainer")
        self.retainer_save_button.setMinimumHeight(30)
        self.retainer_save_button.clicked.connect(self._save_retainer)
        self.retainer_save_button.setEnabled(False)
        retainer_card_layout.addWidget(self.retainer_save_button)

        self.retainer_status_label = make_label("Select a source scan to begin.", "muted", True)
        self.retainer_status_label.setWordWrap(True)
        retainer_card_layout.addWidget(self.retainer_status_label)

        # Import Retainer section
        import_card, import_card_layout = inner_card("Import Retainer")
        import_card_layout.addWidget(make_label("Import existing STL or PLY retainer mesh into active case.", "muted", True))
        self.retainer_import_button = QPushButton("Import STL/PLY")
        self.retainer_import_button.setMinimumHeight(30)
        self.retainer_import_button.clicked.connect(self._import_retainer)
        self.retainer_import_button.setEnabled(False)
        import_card_layout.addWidget(self.retainer_import_button)

        gen_col.addWidget(retainer_card)
        gen_col.addWidget(import_card)
        gen_col.addStretch(1)

        # Right sub-column: Retainers in Case + Comparison
        mgmt_col = QVBoxLayout()
        mgmt_col.setContentsMargins(0, 0, 0, 0)
        mgmt_col.setSpacing(8)

        retainer_list_card, retainer_list_layout = inner_card("Retainers in Case")
        header_row = QHBoxLayout()
        header_row.setContentsMargins(0, 0, 0, 0)
        header_row.setSpacing(8)
        lbl_r = make_label("Retainer", "cardTitle", True)
        lbl_r.setMinimumWidth(120)
        header_row.addWidget(lbl_r)
        header_row.addWidget(make_label("Type", "cardTitle", True))
        header_row.addWidget(make_label("Jaw", "cardTitle", True))
        lbl_v = make_label("Visible", "cardTitle", True)
        lbl_v.setFixedWidth(40)
        header_row.addWidget(lbl_v)
        lbl_o = make_label("Opacity", "cardTitle", True)
        lbl_o.setFixedWidth(100)
        header_row.addWidget(lbl_o)
        lbl_rm = make_label("Remove", "cardTitle", True)
        lbl_rm.setFixedWidth(70)
        header_row.addWidget(lbl_rm)
        header_row.addStretch(1)
        retainer_list_layout.addLayout(header_row)

        self.retainer_rows_container = QWidget()
        self.retainer_rows_layout = QVBoxLayout(self.retainer_rows_container)
        self.retainer_rows_layout.setContentsMargins(0, 0, 0, 0)
        self.retainer_rows_layout.setSpacing(4)
        retainer_list_layout.addWidget(self.retainer_rows_container)
        mgmt_col.addWidget(retainer_list_card)

        compare_card, compare_card_layout = inner_card("Retainer vs Scan Comparison")
        compare_card_layout.addWidget(make_label("Select Retainer", "cardTitle", True))
        self.compare_retainer_combo = QComboBox()
        self.compare_retainer_combo.addItem("No retainers", None)
        self.compare_retainer_combo.currentIndexChanged.connect(self._compare_retainer_changed)
        compare_card_layout.addWidget(self.compare_retainer_combo)

        compare_card_layout.addWidget(make_label("Select Scan", "cardTitle", True))
        self.compare_scan_combo = QComboBox()
        self.compare_scan_combo.addItem("No scans", None)
        self.compare_scan_combo.currentIndexChanged.connect(self._compare_scan_changed)
        compare_card_layout.addWidget(self.compare_scan_combo)

        self.compare_alignment_checkbox = QCheckBox("Alignment confirmed (user assertion)")
        self.compare_alignment_checkbox.setChecked(False)
        compare_card_layout.addWidget(self.compare_alignment_checkbox)

        self.compare_button = QPushButton("Compare Geometrically")
        self.compare_button.setMinimumHeight(32)
        self.compare_button.clicked.connect(self._compare_retainer_to_scan)
        self.compare_button.setEnabled(False)
        compare_card_layout.addWidget(self.compare_button)

        self.compare_result_label = make_label("No comparison performed.", "muted", True)
        self.compare_result_label.setWordWrap(True)
        compare_card_layout.addWidget(self.compare_result_label)
        mgmt_col.addWidget(compare_card)

        disclaimer = make_label("Preliminary Retainer Design — Not Clinically Validated", "muted", True)
        disclaimer.setWordWrap(True)
        disclaimer.setStyleSheet("font-size: 10px; color: #8c97a4; font-style: italic; padding: 2px 4px;")
        mgmt_col.addWidget(disclaimer)
        mgmt_col.addStretch(1)

        retainer_cols_layout.addLayout(gen_col, 1)
        retainer_cols_layout.addLayout(mgmt_col, 1)
        retainer_panel_layout.addWidget(retainer_columns)

        retainer_panel.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        retainer_panel.setMinimumWidth(560)

        layout.addWidget(case_panel, 0)
        layout.addWidget(stages_panel, 0)
        layout.addWidget(retainer_panel, 1)

        scroll.setWidget(content)
        outer.addWidget(scroll)
        return container

    def _build_viewport(self) -> QFrame:
        panel = QFrame()
        panel.setObjectName("viewportCard")
        layout = QVBoxLayout(panel)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self.plotter = QtInteractor(panel)
        configure_viewport_controls(self.plotter)
        try:
            self.plotter.render_window.GetInteractor().AddObserver(
                "InteractionEvent", self._render_popout_view)
            self.plotter.render_window.GetInteractor().AddObserver(
                "EndInteractionEvent", self._render_popout_view)
        except Exception:
            pass
        self.viewport_stack = QStackedWidget(panel)
        self.viewport_stack.setObjectName("viewportStack")
        self.viewport_stack.setStyleSheet("QStackedWidget#viewportStack { background: #ffffff; border: 0; }")
        self.viewport_render_page = QWidget(self.viewport_stack)
        render_layout = QGridLayout(self.viewport_render_page)
        render_layout.setContentsMargins(0, 0, 0, 0)
        render_layout.addWidget(self.plotter.interactor, 0, 0)

        # Centered subtle interaction hint near bottom edge with padding
        self.viewport_hint = make_label("CTRL DRAG TO ROTATE · SHIFT + DRAG TO PAN", wrap=True)
        self.viewport_hint.setAlignment(Qt.AlignCenter)
        self.viewport_hint.setMinimumWidth(0)
        self.viewport_hint.setStyleSheet(
            "color: #68727c; font-size: 10px; letter-spacing: 0.6px; font-weight: 500; "
            "background: transparent; padding: 10px;"
        )
        self.viewport_hint.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)
        self.controls_hint = self.viewport_hint
        render_layout.addWidget(self.viewport_hint, 0, 0, Qt.AlignBottom | Qt.AlignHCenter)

        # Pop-out button overlay positioned at bottom right of the simulation viewport
        self.popout_button = QPushButton(self.viewport_render_page)
        self.popout_button.setIcon(popout_view_icon())
        self.popout_button.setIconSize(QSize(20, 20))
        self.popout_button.setFixedSize(36, 36)
        self.popout_button.setAccessibleName("Pop out simulation view")
        self.popout_button.setToolTip("Open the current simulation in a larger, separate window")
        self.popout_button.setStyleSheet(
            "QPushButton { background: rgba(255, 255, 255, 0.9); border: 1px solid transparent; "
            "border-radius: 0px; padding: 4px; margin: 10px; } "
            "QPushButton:hover { background: #f1f4f7; border: 1px solid #9ba8b7; } "
            "QPushButton:pressed { background: #e3e9ef; border: 1px solid #718099; }"
        )
        self.popout_button.clicked.connect(self._toggle_popout_window)
        render_layout.addWidget(self.popout_button, 0, 0, Qt.AlignBottom | Qt.AlignRight)

        self.viewport_stack.addWidget(self.viewport_render_page)
        self.empty_state_page = self._build_empty_state_page()
        self.viewport_stack.addWidget(self.empty_state_page)
        layout.addWidget(self.viewport_stack, 1)
        return panel

    def _build_empty_state_page(self) -> QWidget:
        page = QWidget()
        page.setObjectName("emptyViewport")
        page.setStyleSheet("QWidget#emptyViewport { background:#ffffff; }")
        page_layout = QVBoxLayout(page)
        page_layout.setContentsMargins(16, 20, 16, 20)
        page_layout.addStretch(2)
        content = QWidget(page)
        content.setMinimumWidth(0)
        content.setMaximumWidth(560)
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(20, 18, 20, 18)
        content_layout.setSpacing(16)
        self.empty_title = make_label("No Scan Loaded", "title")
        self.empty_title.setAlignment(Qt.AlignCenter)
        self.empty_title.setMinimumHeight(34)
        content_layout.addWidget(self.empty_title)
        self.empty_message = make_label("Open an existing case or create a new one, then import a dental scan.", "muted", True)
        self.empty_message.setAlignment(Qt.AlignCenter)
        self.empty_message.setStyleSheet("font-size:14px; color:#68727c;")
        self.empty_message.setMinimumWidth(0)
        self.empty_message.setMinimumHeight(52)
        content_layout.addWidget(self.empty_message)
        actions = QVBoxLayout()
        actions.setSpacing(10)
        self.empty_open_case_button = QPushButton("Open Existing Case")
        self.empty_open_case_button.clicked.connect(self.open_case)
        self.empty_new_case_button = QPushButton("Create New Case")
        self.empty_new_case_button.clicked.connect(self.create_case)
        self.empty_import_button = QPushButton("Import Dental Scan")
        self.empty_import_button.setObjectName("primary")
        self.empty_import_button.clicked.connect(self.open_item)
        for button in (self.empty_open_case_button, self.empty_new_case_button, self.empty_import_button):
            button.setMinimumSize(230, 44)
            actions.addWidget(button, 0, Qt.AlignHCenter)
        content_layout.addLayout(actions)
        self.empty_formats = make_label("Supported formats: STL and PLY", "muted")
        self.empty_formats.setAlignment(Qt.AlignCenter)
        self.empty_formats.setStyleSheet("font-size:11px; color:#87919b;")
        self.empty_formats.setMinimumHeight(24)
        content_layout.addWidget(self.empty_formats)
        page_layout.addWidget(content, 0, Qt.AlignHCenter)
        page_layout.addStretch(3)
        return page

    def _update_empty_state_content(self) -> None:
        state = self.case_manager.viewport_state
        if state == "no_case":
            self.empty_title.setText("No Scan Loaded")
            self.empty_message.setText("Open an existing case or create a new one, then import a dental scan.")
            self.empty_open_case_button.show()
            self.empty_new_case_button.show()
            self.empty_import_button.hide()
        elif state == "empty_case":
            self.empty_title.setText("This Case Has No Scans")
            self.empty_message.setText("This case is empty. Import an STL or PLY scan to view it here.")
            self.empty_open_case_button.hide()
            self.empty_new_case_button.hide()
            self.empty_import_button.show()
        else:
            self.empty_title.setText("No Scan Selected")
            self.empty_message.setText("Select a scan from the case's scan list to display it in this workspace.")
            self.empty_open_case_button.hide()
            self.empty_new_case_button.hide()
            self.empty_import_button.show()

    def _set_scan_controls_enabled(self, scan_loaded: bool) -> None:
        self.save_button.setEnabled(self.current_analysis_record is not None)
        has_model = scan_loaded or (self.quick_view_mode and self.display_mode == "imported")
        self.reset_button.setEnabled(has_model)
        self.demo_preview_button.setEnabled(not has_model)
        self.upper_button.setEnabled(has_model and bool(self.jaw_actors["upper"]))
        self.lower_button.setEnabled(has_model and bool(self.jaw_actors["lower"]))
        # These demo-only overlays do not represent calculations on imported meshes.
        for control in (self.treatment_button, self.contact_button,
                        self.deviation_button, self.demo_variant_combo,
                        self.treatment_opacity_slider, self.treatment_type):
            control.setEnabled(False)

    def _build_right_panel(self) -> QFrame:
        panel, layout = scrollable_panel()
        layout.addWidget(make_label("Scan & analysis", "title"))
        self.right_content = layout
        return panel

    def _build_footer(self) -> QFrame:
        footer = QFrame()
        footer.setObjectName("footerCard")
        footer.setFixedHeight(34)
        layout = QHBoxLayout(footer)
        layout.setContentsMargins(14, 3, 14, 3)
        self.footer_text = make_label("No scan loaded · STL and PLY supported", "muted")
        layout.addWidget(self.footer_text)
        layout.addStretch(1)
        return footer

    def _refresh_case_controls(self) -> None:
        case = self.case_manager.active_case
        if case is None:
            self.case_badge.setText("Quick View" if self.quick_view_mode else "No case open")
            self.case_id_label.setText("No case open")
            self.case_reference_label.setText("No patient reference")
            self.case_description_label.setText("Create or open a case to organize imported scans.")
            self.case_dates_label.setText("")
            self.save_case_button.setEnabled(False)
            self.close_case_button.setEnabled(False)
            self.import_scan_button.setText("Import scan")
            # Match Open: the selected file can enter the existing no-case prompt.
            self.import_scan_button.setEnabled(True)
        else:
            self.case_badge.setText(case.case_id)
            self.case_id_label.setText(case.case_id)
            self.case_reference_label.setText(case.patient_reference or "No patient reference")
            self.case_description_label.setText(case.description or "No description")
            self.case_dates_label.setText(
                f"Created {case.created_at_utc[:10]} · Updated {case.last_modified_utc[:10]}"
            )
            self.save_case_button.setEnabled(True)
            self.close_case_button.setEnabled(True)
            self.import_scan_button.setText("Import scan")
            self.import_scan_button.setEnabled(True)
        self.scan_combo.blockSignals(True)
        self.scan_combo.clear()
        if case is None:
            self.scan_combo.addItem("No case open", None)
        elif not case.scans:
            self.scan_combo.addItem("No scans in this case", None)
        else:
            self.scan_combo.addItem("Select a scan…", None)
            for scan in case.scans:
                display = f"{scan.label or scan.original_filename} · {scan.scan_id[:6]}"
                self.scan_combo.addItem(display, scan.scan_id)
        selected_data = self.case_manager.selected_scan_id
        index = self.scan_combo.findData(selected_data)
        self.scan_combo.setCurrentIndex(index if index >= 0 else 0)
        self.scan_combo.blockSignals(False)
        self._refresh_stage_controls()
        self.file_state_label.setText(
            f"{len(case.scans)} scan(s) stored in active case" if case
            else ("Mesh is not saved to a case" if self.quick_view_mode else "Open or create a case to import scans")
        )
        self._set_scan_controls_enabled(self.case_manager.viewport_state == "scan_loaded")
        self.case_info_card.setVisible(not self.quick_view_mode)
        self.scan_selection_card.setVisible(not self.quick_view_mode)
        self.treatment_card.setVisible(not self.quick_view_mode)
        self.demo_preview_button.setVisible(not self.quick_view_mode)
        self.settings_button.setVisible(not self.quick_view_mode)
        self.quick_view_exit_button.setVisible(self.quick_view_mode)
        if self.display_mode == "empty":
            self._update_empty_state_content()

    def _refresh_stage_controls(self) -> None:
        case, scan = self.case_manager.active_case, self.case_manager.scan
        self.stage_combo.blockSignals(True)
        self.stage_combo.clear()
        self.scan_stage_combo.blockSignals(True)
        self.scan_stage_combo.clear()
        while self.stage_cards_layout.count():
            item = self.stage_cards_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        if case is None:
            self.stage_combo.addItem("No case open", None)
            self.scan_stage_combo.addItem("No scan selected", None)
            self.stage_summary_label.setText("Open a case to organize treatment stages.")
        else:
            for stage in case.ordered_stages():
                assigned = [item for item in case.scans if item.stage_id == stage.stage_id]
                anatomy = {item.anatomical_identity for item in assigned}
                state = "empty" if not assigned else ("upper/lower incomplete" if not {"upper_arch", "lower_arch"}.issubset(anatomy) else "upper/lower")
                self.stage_combo.addItem(f"{stage.name} · {state} ({len(assigned)})", stage.stage_id)
                self.scan_stage_combo.addItem(stage.name, stage.stage_id)
                card, card_layout = inner_card()
                card_layout.setContentsMargins(7, 6, 7, 6)
                card_layout.setSpacing(2)
                card_layout.addWidget(make_label(f"{stage.name} · {stage.stage_type.title()}", "cardTitle", True))
                card_layout.addWidget(make_label(f"{len(assigned)} scan(s) · {state}", "muted", True))
                self.stage_cards_layout.addWidget(card)
            unassigned = [item for item in case.scans if item.stage_id is None]
            unassigned_card, unassigned_layout = inner_card("Unassigned scans")
            unassigned_layout.setContentsMargins(7, 6, 7, 6)
            unassigned_layout.addWidget(make_label(
                ", ".join(item.label or item.original_filename for item in unassigned) if unassigned else "No unassigned scans.",
                "muted", True))
            self.stage_cards_layout.addWidget(unassigned_card)
            self.scan_stage_combo.insertItem(0, "Unassigned", None)
            wanted = self.selected_stage_id if case.find_stage(self.selected_stage_id or "") else case.ordered_stages()[0].stage_id
            self.selected_stage_id = wanted
            self.stage_combo.setCurrentIndex(self.stage_combo.findData(wanted))
            stage = case.find_stage(wanted)
            self.stage_summary_label.setText(
                f"{stage.stage_type.title()} stage: {stage.description or 'No notes.'}"
                if stage else "Select a stage.")
            self.scan_stage_combo.setCurrentIndex(self.scan_stage_combo.findData(scan.stage_id) if scan else 0)
        self.stage_combo.blockSignals(False)
        self.scan_stage_combo.blockSignals(False)
        selected = case.find_stage(self.selected_stage_id) if case and self.selected_stage_id else None
        intermediate = selected is not None and selected.stage_type == "intermediate"
        for control in (self.add_stage_button, self.edit_stage_button):
            control.setEnabled(case is not None and (control is self.add_stage_button or selected is not None))
        self.stage_up_button.setEnabled(intermediate and selected.display_order > 1)
        self.stage_down_button.setEnabled(intermediate and selected.display_order < len(case.stages) - 2 if case else False)
        self.delete_stage_button.setEnabled(intermediate)
        self.scan_stage_combo.setEnabled(scan is not None)

    def _stage_selection_changed(self, index: int) -> None:
        self.selected_stage_id = self.stage_combo.itemData(index)
        self._refresh_stage_controls()

    def add_intermediate_stage(self) -> None:
        case = self.case_manager.active_case
        if case is None:
            return
        dialog = StageDialog(self, intermediate_only=True)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            stage = self.case_store.create_stage(case, dialog.name_field.text(), dialog.notes_field.toPlainText(),
                                                 dialog.date_field.text().strip() or None)
        except CaseStoreError as exc:
            QMessageBox.warning(self, "Could not add stage", str(exc)); return
        self.selected_stage_id = stage.stage_id
        self._refresh_case_controls()

    def edit_selected_stage(self) -> None:
        case = self.case_manager.active_case
        stage = case.find_stage(self.selected_stage_id) if case and self.selected_stage_id else None
        if stage is None:
            return
        dialog = StageDialog(self, stage)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            self.case_store.update_stage(case, stage.stage_id, name=dialog.name_field.text(),
                                         description=dialog.notes_field.toPlainText(),
                                         stage_date=dialog.date_field.text().strip() or None)
        except CaseStoreError as exc:
            QMessageBox.warning(self, "Could not update stage", str(exc)); return
        self._refresh_case_controls(); self._refresh_right_panel()

    def _move_selected_stage(self, direction: int) -> None:
        case = self.case_manager.active_case
        stage = case.find_stage(self.selected_stage_id) if case and self.selected_stage_id else None
        if stage is None or stage.stage_type != "intermediate":
            return
        ids = [item.stage_id for item in case.ordered_stages() if item.stage_type == "intermediate"]
        position = ids.index(stage.stage_id); target = position + direction
        if not 0 <= target < len(ids):
            return
        ids[position], ids[target] = ids[target], ids[position]
        try: self.case_store.reorder_intermediate_stages(case, ids)
        except CaseStoreError as exc: QMessageBox.warning(self, "Could not reorder stages", str(exc)); return
        self._refresh_case_controls()

    def delete_selected_stage(self) -> None:
        case = self.case_manager.active_case
        stage = case.find_stage(self.selected_stage_id) if case and self.selected_stage_id else None
        if stage is None or stage.stage_type != "intermediate":
            return
        assigned = [scan for scan in case.scans if scan.stage_id == stage.stage_id]
        text = "Delete this intermediate stage?"
        if assigned: text += " Its scans will be moved to Unassigned; no files will be deleted."
        if QMessageBox.question(self, "Delete treatment stage", text) != QMessageBox.StandardButton.Yes:
            return
        try: self.case_store.delete_stage(case, stage.stage_id, unassign_scans=True)
        except CaseStoreError as exc: QMessageBox.warning(self, "Could not delete stage", str(exc)); return
        self.selected_stage_id = None; self._refresh_case_controls(); self._refresh_right_panel()

    def _scan_stage_changed(self, index: int) -> None:
        case, scan = self.case_manager.active_case, self.case_manager.scan
        if case is None or scan is None:
            return
        stage_id = self.scan_stage_combo.itemData(index)
        if stage_id == scan.stage_id:
            return
        try: self.case_store.assign_scan_to_stage(case, scan.scan_id, stage_id)
        except CaseStoreError as exc: QMessageBox.warning(self, "Could not assign scan", str(exc)); return
        self._refresh_case_controls(); self._refresh_right_panel()

    def create_case(self) -> None:
        dialog = NewCaseDialog(self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        if not self._confirm_unsaved_case_changes():
            return
        try:
            case = self.case_store.create_case(
                dialog.patient_reference.text(), dialog.description.toPlainText())
        except (CaseStoreError, OSError) as exc:
            QMessageBox.warning(self, "Could not create case", str(exc))
            return
        self._clear_retainers_from_viewport()
        self.retainers = {}
        self.retainer_actors = {}
        self.retainer_visible = {}
        self.retainer_opacity = {}
        self.selected_retainer_id = None
        self.compare_retainer_id = None
        self.compare_scan_id = None
        self.case_manager.open_case(case)
        self.case_dirty = False
        self.loaded_record = None
        self._refresh_case_controls()
        self._show_empty_state()
        self._refresh_right_panel()
        self.statusBar().showMessage(f"Created {case.case_id}", 4000)

    def open_case(self) -> None:
        folder = QFileDialog.getExistingDirectory(
            self, "Open dental case", str(self.case_store.root), QFileDialog.Option.ShowDirsOnly)
        if not folder:
            return
        try:
            case = CaseStore(Path(folder).parent).load_case(folder)
        except (CaseStoreError, OSError) as exc:
            QMessageBox.warning(self, "Could not open case", str(exc))
            return
        if not self._confirm_unsaved_case_changes():
            return
        self._clear_retainers_from_viewport()
        self.retainers = {}
        self.retainer_actors = {}
        self.retainer_visible = {}
        self.retainer_opacity = {}
        self.selected_retainer_id = None
        self.compare_retainer_id = None
        self.compare_scan_id = None
        self.case_store = CaseStore(case.case_folder.parent)
        self.settings.setValue("case_root", str(self.case_store.root))
        self.case_manager.open_case(case)
        self.case_dirty = False
        self.loaded_record = None
        self._refresh_case_controls()
        if case.scans:
            self.case_manager.select_scan(case.scans[0].scan_id)
            self._refresh_case_controls()
            try:
                self._display_case_scan(case.scans[0].scan_id)
            except CaseStoreError as exc:
                self.case_manager.select_scan(None)
                self._refresh_case_controls()
                self._show_empty_state()
                QMessageBox.warning(self, "Case opened with a missing scan", str(exc))
        else:
            self._show_empty_state()
        self._refresh_case_controls()
        self._refresh_right_panel()
        self.statusBar().showMessage(f"Opened case {case.case_id}", 4000)

    def save_case(self) -> bool:
        case = self.case_manager.active_case
        if case is None:
            QMessageBox.information(self, "No case open", "Create or open a case before saving case data.")
            return False
        try:
            self.case_store.save_case(case)
        except CaseStoreError as exc:
            QMessageBox.warning(self, "Could not save case", str(exc))
            return False
        self.case_dirty = False
        self._refresh_case_controls()
        self._refresh_right_panel()
        self.statusBar().showMessage(f"Saved case {case.case_id}", 4000)
        return True

    def close_case(self) -> None:
        if self.case_manager.active_case is None:
            return
        if not self._confirm_unsaved_case_changes():
            return
        self._clear_retainers_from_viewport()
        self.retainers = {}
        self.retainer_actors = {}
        self.retainer_visible = {}
        self.retainer_opacity = {}
        self.selected_retainer_id = None
        self.compare_retainer_id = None
        self.compare_scan_id = None
        self.case_manager.close_case()
        self.case_dirty = False
        self.loaded_record = None
        self._refresh_case_controls()
        self._show_empty_state()
        self._refresh_right_panel()
        self.statusBar().showMessage("Closed case", 3000)

    def _confirm_unsaved_case_changes(self) -> bool:
        if not self.case_dirty or self.case_manager.active_case is None:
            return True
        dialog = QMessageBox(self)
        dialog.setIcon(QMessageBox.Icon.Warning)
        dialog.setWindowTitle("Unsaved case changes")
        dialog.setText("The active case has unsaved changes. Save them before continuing?")
        save_button = dialog.addButton("Save", QMessageBox.ButtonRole.AcceptRole)
        discard_button = dialog.addButton("Discard", QMessageBox.ButtonRole.DestructiveRole)
        cancel_button = dialog.addButton(QMessageBox.StandardButton.Cancel)
        dialog.setDefaultButton(save_button)
        dialog.exec()
        clicked = dialog.clickedButton()
        if clicked is save_button:
            return self.save_case()
        if clicked is discard_button:
            selected_scan_id = self.case_manager.selected_scan_id
            try:
                case = self.case_store.load_case(self.case_manager.active_case.case_folder)
            except CaseStoreError as exc:
                QMessageBox.warning(self, "Could not discard changes", str(exc))
                return False
            self.case_manager.open_case(case)
            if selected_scan_id and case.find_scan(selected_scan_id):
                self.case_manager.select_scan(selected_scan_id)
            self.case_dirty = False
            self._refresh_case_controls()
            self._refresh_right_panel()
            return True
        return False

    def import_scan(self, source_path: str | None = None) -> None:
        if not source_path:
            self.open_item()
            return
        case = self.case_manager.active_case
        if case is None:
            self._offer_quick_view_for_file(Path(source_path))
            return
        try:
            validated = load_and_validate_mesh(source_path)
        except ValueError as exc:
            QMessageBox.warning(self, "Scan import failed", f"The case was not changed.\n\n{exc}")
            return
        suggested_metadata = bits2bites_metadata_for_hash(validated.sha256)
        dialog = ScanImportDialog(Path(source_path).name, self, suggested_metadata)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        label = dialog.label_field.text().strip()
        unit = dialog.unit_field.currentData()
        unit_evidence = "User selected in the import dialog."
        if (suggested_metadata and unit == suggested_metadata.declared_units):
            unit_evidence = suggested_metadata.units_evidence
        anatomical_identity = dialog.anatomical_identity_field.currentData() or "unknown"
        if anatomical_identity == "other":
            anatomical_identity = dialog.anatomical_identity_detail.text().strip()
            if not anatomical_identity:
                QMessageBox.information(self, "Region needed", "Describe the anatomical region or choose Unknown.")
                return
        coordinate_system = dialog.coordinate_system_field.currentText().strip() or "unknown"
        coordinate_frame_id = dialog.coordinate_frame_id_field.text().strip() or "unknown"
        coordinate_evidence = dialog.coordinate_evidence_field.text().strip()
        if (suggested_metadata
                and coordinate_evidence == suggested_metadata.coordinate_system_evidence
                and (coordinate_system != suggested_metadata.coordinate_system
                     or coordinate_frame_id != suggested_metadata.coordinate_frame_id
                     or anatomical_identity != suggested_metadata.anatomical_identity)):
            coordinate_evidence = ""
        try:
            scan = self.case_store.add_scan(
                case, validated, label, unit,
                anatomical_identity=anatomical_identity,
                coordinate_system=coordinate_system,
                coordinate_frame_id=coordinate_frame_id,
                coordinate_system_evidence=coordinate_evidence,
                unit_evidence=unit_evidence,
                stage_id=self.selected_stage_id,
            )
        except (CaseStoreError, OSError) as exc:
            QMessageBox.warning(self, "Scan import failed", f"The case was not changed.\n\n{exc}")
            return
        self.case_dirty = False
        self.case_manager.select_scan(scan.scan_id)
        self._refresh_case_controls()
        try:
            self._display_case_scan(scan.scan_id)
        except CaseStoreError as exc:
            self.case_manager.select_scan(None)
            self._refresh_case_controls()
            self._show_empty_state()
            self._refresh_right_panel()
            QMessageBox.warning(self, "Scan stored but not displayed", str(exc))
            return
        self.statusBar().showMessage(f"Imported {scan.original_filename} into {case.case_id}", 5000)

    def _offer_quick_view_for_file(self, path: Path) -> None:
        dialog = QMessageBox(self)
        dialog.setWindowTitle("No case open")
        dialog.setText(f"{path.name} was selected, but no case is open.")
        dialog.setInformativeText(
            "Enter Quick View to inspect this mesh without adding it to a case, or cancel and open/create a case first."
        )
        enter_button = dialog.addButton("Enter Quick View", QMessageBox.ButtonRole.AcceptRole)
        dialog.addButton(QMessageBox.StandardButton.Cancel)
        dialog.exec()
        if dialog.clickedButton() is enter_button:
            self._load_quick_view_paths([path])

    def _exit_quick_view(self) -> None:
        if not self.quick_view_mode:
            return
        self._show_empty_state()
        self._refresh_case_controls()
        self._refresh_right_panel()

    @staticmethod
    def _jaw_from_name(name: str) -> str | None:
        lowered = name.casefold()
        if "upper" in lowered or "maxilla" in lowered:
            return "upper"
        if "lower" in lowered or "mandible" in lowered:
            return "lower"
        return None

    @classmethod
    def _jaw_for_scan(cls, scan: ScanRecord) -> str | None:
        identity = scan.anatomical_identity.casefold()
        if "upper" in identity or "maxilla" in identity:
            return "upper"
        if "lower" in identity or "mandible" in identity:
            return "lower"
        return cls._jaw_from_name(scan.original_filename) or cls._jaw_from_name(scan.label)

    def _load_quick_view_paths(self, paths: list[Path]) -> None:
        if not paths:
            return
        if len(paths) > 2:
            QMessageBox.information(self, "Quick View", "Quick View accepts one scan or an upper/lower pair.")
            return
        validated_meshes: dict[str, ValidatedMesh] = {}
        for path in paths:
            try:
                validated = load_and_validate_mesh(path)
            except ValueError as exc:
                QMessageBox.warning(self, "Mesh could not be opened", f"{path.name}\n\n{exc}")
                return
            documented = bits2bites_metadata_for_hash(validated.sha256)
            if documented is not None:
                validated = replace(validated, metadata=documented)
            jaw = self._jaw_from_name(path.stem)
            key = jaw if jaw and jaw not in validated_meshes else path.stem
            if key in validated_meshes:
                key = f"{key} ({len(validated_meshes) + 1})"
            validated_meshes[key] = validated
        self.quick_view_meshes = validated_meshes
        self.quick_view_paths = list(paths)
        self.quick_view_mode = True
        self.display_pair_source_aligned = False
        self.imported_mesh = next(iter(self.quick_view_meshes.values()))
        self.display_meshes = {
            key: validated.mesh for key, validated in self.quick_view_meshes.items()
        }
        self.current_analysis_record = None
        self.surface_distance_result = None
        self.loaded_record = None
        self.case_manager.select_scan(None)
        self._show_imported()
        self._refresh_case_controls()
        self._refresh_right_panel()
        self.statusBar().showMessage("Quick View opened. No case data was created or changed.", 5000)

    def _display_case_scan(self, scan_id: str) -> None:
        case = self.case_manager.active_case
        if case is None:
            raise CaseStoreError("Open a case before selecting one of its scans.")
        scan = case.find_scan(scan_id)
        if scan is None:
            raise CaseStoreError("The selected scan is not part of the active case.")
        validated = self.case_store.load_scan_mesh(case, scan)
        self.current_analysis_record = None
        self.surface_distance_result = None
        self.loaded_record = None
        self.imported_mesh = validated
        self.quick_view_mode = False
        self.quick_view_meshes.clear()
        self.quick_view_paths.clear()
        self.display_meshes = {"single": validated.mesh}
        jaw = self._jaw_for_scan(scan)
        self.display_pair_source_aligned = False
        if jaw:
            self.display_meshes = {jaw: validated.mesh}
            case = self.case_manager.active_case
            if case is not None:
                for other in case.scans:
                    if other.scan_id == scan.scan_id:
                        continue
                    if Path(other.original_source_path).parent != Path(scan.original_source_path).parent:
                        continue
                    if self._jaw_for_scan(other) != ("lower" if jaw == "upper" else "upper"):
                        continue
                    try:
                        companion = self.case_store.load_scan_mesh(case, other)
                    except CaseStoreError as exc:
                        self.statusBar().showMessage(f"Could not load companion jaw: {exc}", 6000)
                        break
                    self.display_meshes["lower" if jaw == "upper" else "upper"] = companion.mesh
                    break
            # A common coordinate label is not proof that two surfaces are rigidly registered.
            # Keep the source untouched and normalize the display copies for a readable pair.
            self.display_pair_source_aligned = False
        self.case_manager.select_scan(scan_id)
        self._show_imported()
        self._refresh_case_controls()
        self._refresh_right_panel()

    def remove_selected_scan(self, scan_id: str | None = None) -> None:
        case = self.case_manager.active_case
        scan = case.find_scan(scan_id) if case is not None and scan_id else self.case_manager.scan
        if case is None or scan is None:
            return
        target_scan_id = scan.scan_id
        answer = QMessageBox.question(
            self, "Remove scan from case?",
            f"Remove {scan.original_filename} from {case.case_id}?\n\nThe managed copy will be removed. The original source file will not be deleted.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Cancel,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        if not self._confirm_unsaved_case_changes():
            return
        # Re-fetch because discard may have reloaded the case object.
        case = self.case_manager.active_case
        scan = case.find_scan(target_scan_id) if case is not None else None
        if case is None or scan is None:
            return
        selected_scan_id = self.case_manager.selected_scan_id
        try:
            self.case_store.remove_scan(case, target_scan_id)
        except CaseStoreError as exc:
            QMessageBox.warning(self, "Could not remove scan", str(exc))
            return
        self.case_dirty = False
        if selected_scan_id == target_scan_id:
            self.case_manager.select_scan(None)
            self._refresh_case_controls()
            self._show_empty_state()
            self._refresh_right_panel()
        elif selected_scan_id is None:
            self._refresh_case_controls()
            self._show_empty_state()
            self._refresh_right_panel()
        else:
            self._display_case_scan(selected_scan_id)

    def _unit_selection_changed(self, _index: int) -> None:
        scan = self.case_manager.scan
        if scan is None or self.unit_combo is None:
            return
        self._set_analysis_unit_override(f"case:{scan.scan_id}", scan.unit, self.unit_combo.currentData())
        self.current_analysis_record = None
        self.surface_distance_result = None
        self.loaded_record = None
        self.save_button.setEnabled(False)
        self._refresh_right_panel()

    def _coordinate_metadata_changed(self, *_args) -> None:
        case, scan = self.case_manager.active_case, self.case_manager.scan
        if (case is None or scan is None or self.coordinate_system_combo is None
                or self.coordinate_frame_id_field is None or self.coordinate_evidence_field is None):
            return
        coordinate_system = self.coordinate_system_combo.currentText().strip() or "unknown"
        frame_id = self.coordinate_frame_id_field.text().strip() or "unknown"
        evidence = self.coordinate_evidence_field.text().strip()
        if (coordinate_system, frame_id, evidence) == (
                scan.coordinate_system, scan.coordinate_frame_id, scan.coordinate_system_evidence):
            return
        try:
            self.case_store.update_scan_coordinate_metadata(
                case, scan.scan_id, coordinate_system=coordinate_system,
                coordinate_frame_id=frame_id, coordinate_system_evidence=evidence, save=False,
            )
        except CaseStoreError as exc:
            QMessageBox.warning(self, "Coordinate metadata not changed", str(exc))
            self._refresh_right_panel()
            return
        self.case_dirty = True
        self.current_analysis_record = None
        self.surface_distance_result = None
        self.loaded_record = None
        self.save_button.setEnabled(False)
        self._refresh_case_controls()
        self._refresh_right_panel()

    def _comparison_unit_changed(self, _index: int) -> None:
        if self.compare_scan_combo is None or self.comparison_unit_combo is None:
            return
        case = self.case_manager.active_case
        scan = case.find_scan(self.compare_scan_combo.currentData()) if case else None
        if scan is None:
            return
        self._set_analysis_unit_override(
            f"case:{scan.scan_id}", scan.unit, self.comparison_unit_combo.currentData())
        self.current_analysis_record = None
        self.surface_distance_result = None
        self.loaded_record = None
        self.save_button.setEnabled(False)
        self._refresh_right_panel()

    def _quick_view_unit_changed(self, key: str, source_unit: str, unit: str) -> None:
        self._set_analysis_unit_override(key, source_unit, unit)
        self.current_analysis_record = None
        self.surface_distance_result = None
        self.loaded_record = None
        self.save_button.setEnabled(False)
        self._refresh_right_panel()

    def _set_analysis_unit_override(self, key: str, source_unit: str, unit: str) -> None:
        if unit == source_unit:
            self.analysis_unit_overrides.pop(key, None)
        else:
            self.analysis_unit_overrides[key] = unit

    def _analysis_unit(self, key: str, source_unit: str) -> str:
        return self.analysis_unit_overrides.get(key, source_unit)

    @staticmethod
    def _add_unit_options(combo: QComboBox) -> None:
        for text, value in [("Unknown", "unknown"), ("mm", "mm"), ("cm", "cm"),
                            ("µm", "um"), ("in", "in")]:
            combo.addItem(text, value)
        combo.setMinimumContentsLength(3)
        combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)

    def _change_cases_root(self) -> None:
        root = QFileDialog.getExistingDirectory(
            self, "Choose case storage folder", str(self.case_store.root), QFileDialog.Option.ShowDirsOnly)
        if not root:
            return
        self.case_store = CaseStore(root)
        self.settings.setValue("case_root", str(self.case_store.root))
        self.statusBar().showMessage("Case storage folder updated", 4000)

    def _clear_right_panel(self) -> None:
        while self.right_content.count():
            item = self.right_content.takeAt(0)
            widget = item.widget()
            if widget:
                widget.hide()
                widget.deleteLater()

    def _fit_right_panel_contents(self) -> None:
        """Let right-panel text wrap and controls shrink to the splitter width."""
        for label in self.right_panel.findChildren(QLabel):
            label.setWordWrap(True)
            label.setMinimumWidth(0)
            label.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        for widget_type in (QPushButton, QComboBox, QLineEdit, QSlider):
            for widget in self.right_panel.findChildren(widget_type):
                widget.setMinimumWidth(0)
                horizontal = (QSizePolicy.Policy.Ignored if isinstance(widget, QPushButton)
                              else QSizePolicy.Policy.Expanding)
                widget.setSizePolicy(horizontal, QSizePolicy.Policy.Preferred)

    def _refresh_right_panel(self) -> None:
        self._clear_right_panel()
        if self.quick_view_mode:
            self._refresh_quick_view_right_panel()
            self._fit_right_panel_contents()
            return
        self.right_content.addWidget(make_label("Scan & analysis", "title"))

        active_case = self.case_manager.active_case
        scan_record = self.case_manager.scan
        case_card, case_layout = inner_card("Active case")
        if active_case is None:
            case_layout.addWidget(make_label("No case open", "cardTitle"))
            case_layout.addWidget(make_label("Create or open a case before importing scans. The illustrative model is available separately.", "muted", True))
        else:
            case_layout.addWidget(make_label(active_case.case_id, "cardTitle"))
            case_layout.addWidget(make_label(active_case.patient_reference or "No patient reference", "muted", True))
            case_layout.addWidget(make_label(f"{len(active_case.scans)} scan(s) in this case", "muted"))
            if self.case_dirty:
                case_layout.addWidget(make_label("Unsaved case changes", "cardTitle"))
        self.right_content.addWidget(case_card)

        scan_card, scan_layout = inner_card("Displayed model")
        scan_layout.setContentsMargins(14, 14, 14, 14)
        scan_layout.setSpacing(10)
        self.unit_combo = None
        self.coordinate_system_combo = None
        self.coordinate_frame_id_field = None
        self.coordinate_evidence_field = None
        self.comparison_unit_combo = None
        if self.display_mode == "demo":
            scan_layout.addWidget(make_label("Procedural two-arch illustration", "muted", True))
            scan_layout.addWidget(make_label("28 stylized crowns · generated in-app", "muted", True))
            scan_layout.addWidget(make_label("Arbitrary display scale; not measured in physical units.", "muted", True))
        elif scan_record is not None:
            assert self.imported_mesh is not None
            mesh = self.imported_mesh
            scan_layout.addWidget(make_label(scan_record.label or scan_record.original_filename, "cardTitle", True))
            scan_layout.addWidget(make_label(f"Source file: {scan_record.original_filename}", "muted", True))
            if set(self.display_meshes) == {"upper", "lower"}:
                scan_layout.addWidget(make_label(
                    "Upper/lower pair · display-only centering and direction alignment; no registration",
                    "muted", True))
            scan_layout.addWidget(make_label(f"Format: {scan_record.file_format.upper()} · {scan_record.file_size_bytes:,} bytes", "muted", True))
            scan_layout.addWidget(make_label(f"Anatomical region: {scan_record.anatomical_identity}", "muted", True))
            scan_layout.addWidget(make_label(
                f"Imported unit: {scan_record.unit}"
                + (f" · {scan_record.unit_evidence}" if scan_record.unit_evidence else " · provenance not recorded"),
                "muted", True))
            scan_layout.addWidget(make_label("Analysis unit (override)", "muted", True))
            self.unit_combo = QComboBox()
            self._add_unit_options(self.unit_combo)
            analysis_unit = self._analysis_unit(f"case:{scan_record.scan_id}", scan_record.unit)
            selected_unit = self.unit_combo.findData(analysis_unit)
            self.unit_combo.setCurrentIndex(max(selected_unit, 0))
            self.unit_combo.currentIndexChanged.connect(self._unit_selection_changed)
            scan_layout.addWidget(self.unit_combo)
            scan_layout.addWidget(make_label(
                "An analysis override does not change imported metadata or rescale the source mesh.",
                "muted", True))
            scan_layout.addWidget(make_label("Coordinate convention", "muted", True))
            self.coordinate_system_combo = QComboBox()
            for text, value in [("Unknown", "unknown"), ("RAS", "RAS"), ("LPS", "LPS"),
                                ("Local / other", "local")]:
                self.coordinate_system_combo.addItem(text, value)
            self.coordinate_system_combo.setEditable(True)
            self.coordinate_system_combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
            self.coordinate_system_combo.setCurrentText(scan_record.coordinate_system)
            self.coordinate_system_combo.activated.connect(self._coordinate_metadata_changed)
            self.coordinate_system_combo.lineEdit().editingFinished.connect(self._coordinate_metadata_changed)
            scan_layout.addWidget(self.coordinate_system_combo)
            scan_layout.addWidget(make_label("Coordinate-frame identity", "muted", True))
            self.coordinate_frame_id_field = QLineEdit(scan_record.coordinate_frame_id)
            self.coordinate_frame_id_field.setMaxLength(160)
            self.coordinate_frame_id_field.setPlaceholderText("Unknown unless shared frame is documented")
            self.coordinate_frame_id_field.editingFinished.connect(self._coordinate_metadata_changed)
            scan_layout.addWidget(self.coordinate_frame_id_field)
            scan_layout.addWidget(make_label("Coordinate evidence / provenance", "muted", True))
            self.coordinate_evidence_field = QLineEdit(scan_record.coordinate_system_evidence)
            self.coordinate_evidence_field.setMaxLength(500)
            self.coordinate_evidence_field.setPlaceholderText("Source supporting convention and frame identity")
            self.coordinate_evidence_field.setToolTip(scan_record.coordinate_system_evidence)
            self.coordinate_evidence_field.editingFinished.connect(self._coordinate_metadata_changed)
            scan_layout.addWidget(self.coordinate_evidence_field)
            scan_layout.addWidget(make_label(f"Points: {mesh.point_count:,} · Faces: {mesh.face_count:,}", "muted", True))
            scan_layout.addWidget(make_label(f"Triangular surface: {'Yes' if mesh.is_triangular_surface else 'No'}", "muted"))
            scan_layout.addWidget(make_label("Dimensions (source coordinates): " + " × ".join(f"{v:.4g}" for v in mesh.dimensions), "muted", True))
            b = mesh.bounds
            scan_layout.addWidget(make_label(
                "Bounds: " + ", ".join(f"{v:.4g}" for v in b), "muted", True))
            scan_layout.addWidget(make_label("Imported from: " + scan_record.original_source_path, "muted", True))
            scan_layout.addWidget(make_label("Managed copy: scans/" + scan_record.managed_filename, "muted", True))
            scan_layout.addWidget(make_label(f"SHA-256: {scan_record.sha256}", "muted", True))
            scan_layout.addWidget(make_label(f"Validation: {scan_record.validation_status.replace('_', ' ')}", "cardTitle"))
        else:
            scan_layout.addWidget(make_label("No scan is currently displayed.", "muted", True))
            scan_layout.addWidget(make_label("Import a scan or select one from the active case.", "muted", True))
        self.right_content.addWidget(scan_card)

        quality_card, quality_layout = inner_card("Data quality & limits")
        if scan_record is not None:
            quality_messages = list(scan_record.validation_warnings)
        elif self.display_mode == "demo":
            quality_messages = [
                "This is a built-in illustration, not patient scan data.",
                "No scan-quality score or clinical measurement is produced.",
            ]
        else:
            quality_messages = ["No scan loaded. No scan measurements are available."]
        for message in quality_messages:
            quality_layout.addWidget(make_label("•  " + message, "muted", True))
        self.right_content.addWidget(quality_card)

        analysis_card, analysis_layout = inner_card("Geometric analysis")
        self._build_analysis_controls(analysis_layout, scan_record)
        self.right_content.addWidget(analysis_card)

        comparison_card, comparison_layout = inner_card("Scan comparison")
        if self.display_mode == "demo":
            comparison_layout.addWidget(make_label("Illustrative preview only", "cardTitle"))
            comparison_layout.addWidget(make_label(
                "A/B display variants and the deviation marker are simulated. They are not registered scans and do not show measured change.",
                "muted", True))
        elif self.display_mode == "imported":
            comparison_layout.addWidget(make_label("Not available", "cardTitle"))
            comparison_layout.addWidget(make_label(
                "Scan compatibility and alignment have not been checked. No comparison is shown.",
                "muted", True))
        else:
            comparison_layout.addWidget(make_label("No scan loaded", "cardTitle"))
            comparison_layout.addWidget(make_label("Load a scan before reviewing a comparison.", "muted", True))
        self.right_content.addWidget(comparison_card)

        record_card, record_layout = inner_card("Loaded analysis record")
        if self.loaded_record is None:
            record_layout.addWidget(make_label("No saved record loaded", "muted"))
        else:
            record = self.loaded_record
            record_layout.addWidget(make_label(f"Case: {record['case_id']}", "muted"))
            record_layout.addWidget(make_label(f"Status: {record['status']}", "cardTitle"))
            record_layout.addWidget(make_label(f"Source type: {record['source_kind']}", "muted"))
            record_layout.addWidget(make_label(f"Stored measurements: {len(record['measurements'])}", "muted"))
            digest = record.get("source_sha256")
            if digest:
                record_layout.addWidget(make_label(f"Source SHA-256: {digest[:16]}…", "muted", True))
        self.right_content.addWidget(record_card)
        self.right_content.addStretch(1)
        self._fit_right_panel_contents()

    def _refresh_quick_view_right_panel(self) -> None:
        self.right_content.addWidget(make_label("Quick mesh view", "title"))
        card, layout = inner_card("Displayed mesh files")
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(16)
        for name, validated in self.quick_view_meshes.items():
            mesh_card, mesh_layout = inner_card(name.replace("_", " ").title())
            mesh_layout.setContentsMargins(14, 14, 14, 14)
            mesh_layout.setSpacing(11)
            mesh_layout.addWidget(make_label(validated.source_path.name, "muted", True))
            mesh_layout.addWidget(make_label(f"Points: {validated.point_count:,}", "muted"))
            mesh_layout.addWidget(make_label(f"Faces: {validated.face_count:,}", "muted"))
            mesh_layout.addWidget(make_label(
                "Dimensions (source units): " + " × ".join(f"{dimension:.4g}" for dimension in validated.dimensions),
                "muted", True))
            mesh_layout.addWidget(make_label(f"SHA-256: {validated.sha256}", "muted", True))
            metadata = validated.metadata
            source_unit = metadata.declared_units or "unknown"
            mesh_layout.addWidget(make_label(
                f"Documented unit: {source_unit}"
                + (f" · {metadata.units_evidence}" if metadata.units_evidence else " · not documented"),
                "muted", True))
            mesh_layout.addWidget(make_label(
                f"Coordinate convention: {metadata.coordinate_system or 'unknown'} · "
                f"Frame: {metadata.coordinate_frame_id or 'unknown'}", "muted", True))
            if metadata.coordinate_system_evidence:
                mesh_layout.addWidget(make_label(
                    "Coordinate provenance: " + metadata.coordinate_system_evidence, "muted", True))
            mesh_layout.addWidget(make_label("Analysis unit (session override)", "muted", True))
            unit_combo = QComboBox()
            self._add_unit_options(unit_combo)
            override_key = f"quick:{validated.sha256}"
            analysis_unit = self._analysis_unit(override_key, source_unit)
            selected = unit_combo.findData(analysis_unit)
            unit_combo.setCurrentIndex(max(selected, 0))
            unit_combo.currentIndexChanged.connect(
                lambda index, key=override_key, source=source_unit, combo=unit_combo:
                self._quick_view_unit_changed(key, source, combo.itemData(index)))
            mesh_layout.addWidget(unit_combo)
            layout.addWidget(mesh_card)
        layout.addWidget(make_label(
            "Quick View keeps files in place and does not create or modify a case.", "muted", True))
        if set(self.quick_view_meshes) == {"upper", "lower"}:
            layout.addWidget(make_label(
                "The pair is centered and oriented for viewing only. Original files are untouched; this is not scan registration.",
                "muted", True))
        self.right_content.addWidget(card)
        analysis_card, analysis_layout = inner_card("Geometric analysis")
        self._build_analysis_controls(analysis_layout, None, quick_view=True)
        self.right_content.addWidget(analysis_card)
        self.right_content.addStretch(1)
        self._fit_right_panel_contents()

    def _build_analysis_controls(
        self, layout: QVBoxLayout, scan_record: ScanRecord | None, quick_view: bool = False,
    ) -> None:
        if (scan_record is None and not quick_view) or self.display_mode != "imported":
            layout.addWidget(make_label("Load and select a real scan to run geometric analysis.", "muted", True))
            return
        if quick_view:
            self.analysis_mode = "mesh_characteristics"
        self.analysis_type_combo = QComboBox()
        self.analysis_type_combo.addItem("Mesh characteristics", "mesh_characteristics")
        if not quick_view:
            self.analysis_type_combo.addItem("Surface distance comparison", "surface_distance")
        selected = self.analysis_type_combo.findData(self.analysis_mode)
        self.analysis_type_combo.setCurrentIndex(max(selected, 0))
        self.analysis_type_combo.currentIndexChanged.connect(self._analysis_mode_changed)
        layout.addWidget(self.analysis_type_combo)

        self.compare_scan_combo = None
        self.alignment_confirmation = None
        self.thresholds_input = None
        self.sample_limit_combo = None
        if self.analysis_mode == "surface_distance" and not quick_view:
            self.compare_scan_combo = QComboBox()
            case = self.case_manager.active_case
            source_stage = case.find_stage(scan_record.stage_id) if case and scan_record.stage_id else None
            layout.addWidget(make_label(
                f"Scan A stage: {source_stage.name if source_stage else 'Unassigned'}", "muted", True))
            if case is not None:
                for scan in case.scans:
                    if scan.scan_id != scan_record.scan_id:
                        stage = case.find_stage(scan.stage_id) if scan.stage_id else None
                        self.compare_scan_combo.addItem(
                            f"{stage.name if stage else 'Unassigned'} · {scan.label or scan.original_filename}", scan.scan_id)
            if self.compare_scan_combo.count() == 0:
                self.compare_scan_combo.addItem("Import another scan in this case", None)
                self.compare_scan_combo.setEnabled(False)
            self.compare_scan_combo.currentIndexChanged.connect(self._comparison_target_changed)
            layout.addWidget(make_label("Compare with scan", "muted"))
            layout.addWidget(self.compare_scan_combo)
            other_scan = case.find_scan(self.compare_scan_combo.currentData()) if case else None
            if other_scan is not None:
                other_stage = case.find_stage(other_scan.stage_id) if other_scan.stage_id else None
                layout.addWidget(make_label(
                    f"Scan B stage: {other_stage.name if other_stage else 'Unassigned'}", "muted", True))
                layout.addWidget(make_label(
                    f"Scan B imported unit: {other_scan.unit}"
                    + (f" · {other_scan.unit_evidence}" if other_scan.unit_evidence else " · provenance not recorded"),
                    "muted", True))
                layout.addWidget(make_label("Scan B analysis unit (override)", "muted", True))
                self.comparison_unit_combo = QComboBox()
                self._add_unit_options(self.comparison_unit_combo)
                analysis_unit_b = self._analysis_unit(f"case:{other_scan.scan_id}", other_scan.unit)
                selected_b = self.comparison_unit_combo.findData(analysis_unit_b)
                self.comparison_unit_combo.setCurrentIndex(max(selected_b, 0))
                self.comparison_unit_combo.currentIndexChanged.connect(self._comparison_unit_changed)
                layout.addWidget(self.comparison_unit_combo)
            layout.addWidget(make_label(
                "Convention, documented shared-frame identity, same anatomy, and alignment confirmation are required.",
                "muted", True))
            self.alignment_confirmation = QCheckBox("I confirm the scans are already aligned")
            self.alignment_confirmation.setText("I confirm the scans are already\naligned")
            self.alignment_confirmation.setMinimumWidth(0)
            self.alignment_confirmation.setSizePolicy(
                QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
            layout.addWidget(self.alignment_confirmation)
            layout.addWidget(make_label("Distance thresholds (mm, comma separated)", "muted", True))
            self.thresholds_input = QLineEdit("0.1, 0.2, 0.5, 1.0")
            layout.addWidget(self.thresholds_input)
            layout.addWidget(make_label("Maximum samples per direction", "muted"))
            self.sample_limit_combo = QComboBox()
            for count in (5000, 10000, 20000, 50000):
                self.sample_limit_combo.addItem(f"{count:,}", count)
            self.sample_limit_combo.setCurrentIndex(2)
            layout.addWidget(self.sample_limit_combo)

        run = QPushButton("Calculate mesh\ncharacteristics" if self.analysis_mode == "mesh_characteristics"
                          else "Compare surfaces")
        run.setObjectName("primary")
        run.clicked.connect(self.run_selected_analysis)
        layout.addWidget(run)

        record = self.current_analysis_record
        if record is None:
            layout.addWidget(make_label("No analysis has been run for this scan selection.", "muted", True))
            return
        layout.addWidget(make_label(f"Status: {record.status}", "cardTitle"))
        for measurement in record.measurements:
            if measurement.get("type") == "mesh_characteristics":
                values = measurement["values"]
                rows = [
                    f"Points: {values['point_count']:,} · Faces: {values['face_count']:,}",
                    "Dimensions: " + " × ".join(f"{v:.4g}" for v in values["dimensions"])
                    + f" {values['dimension_unit']}",
                    "Bounds: " + ", ".join(f"{v:.4g}" for v in values["bounds"]),
                    f"Surface area: {values['surface_area']:.4g} {values['surface_area_unit']}",
                    f"Connected components: {values['connected_component_count']}",
                    f"Degenerate triangles: {values['degenerate_triangle_count']}",
                    f"Enclosed volume: {values['enclosed_volume']:.4g} {values['volume_unit']}"
                    if values["enclosed_volume"] is not None else "Enclosed volume: not reported (open/unsuitable surface)",
                ]
                for row in rows:
                    layout.addWidget(make_label(row, "muted", True))
            elif measurement.get("type") == "bidirectional_surface_distance":
                for direction in ("scan_a_to_scan_b", "scan_b_to_scan_a", "symmetric_point_weighted"):
                    stats = measurement[direction]
                    layout.addWidget(make_label(direction.replace("_", " ").title(), "cardTitle"))
                    layout.addWidget(make_label(
                        f"Mean {stats['mean_mm']:.4g} mm · Median {stats['median_mm']:.4g} mm · "
                        f"RMS {stats['root_mean_square_mm']:.4g} mm", "muted", True))
                    layout.addWidget(make_label(
                        f"95th percentile {stats['percentile_95_mm']:.4g} mm · "
                        f"Maximum {stats['maximum_mm']:.4g} mm", "muted", True))
                layout.addWidget(make_label(
                    "Spatial samples were saved in the record; viewport deviation overlay is unavailable.",
                    "muted", True))
        for warning in record.warnings:
            layout.addWidget(make_label("Warning: " + warning, "muted", True))

    def _analysis_mode_changed(self, _index: int) -> None:
        if self.analysis_type_combo is None:
            return
        mode = self.analysis_type_combo.currentData()
        if mode == self.analysis_mode:
            return
        self.analysis_mode = mode
        self.current_analysis_record = None
        self.surface_distance_result = None
        self.loaded_record = None
        self.save_button.setEnabled(False)
        self._refresh_right_panel()

    def _comparison_target_changed(self, _index: int) -> None:
        self.current_analysis_record = None
        self.surface_distance_result = None
        self.loaded_record = None
        self.save_button.setEnabled(False)
        self._refresh_right_panel()

    def run_selected_analysis(self) -> None:
        case, scan, validated = self.case_manager.active_case, self.case_manager.scan, self.imported_mesh
        if self.quick_view_mode:
            if validated is None or self.display_mode != "imported":
                QMessageBox.information(self, "No mesh selected", "Open a mesh in Quick View before running analysis.")
                return
            try:
                source_path = validated.source_path
                metadata = validated.metadata
                source_unit = metadata.declared_units or "unknown"
                analysis_unit = self._analysis_unit(f"quick:{validated.sha256}", source_unit)
                record = analyze_mesh(
                    validated.mesh, case_id="QUICK-VIEW",
                    scan_id=f"{source_path.stem}-{validated.sha256[:12]}",
                    source_sha256=validated.sha256, unit=analysis_unit,
                    source_unit=source_unit, unit_evidence=metadata.units_evidence,
                    coordinate_system=metadata.coordinate_system or "unknown",
                    coordinate_frame_id=metadata.coordinate_frame_id or "unknown",
                    coordinate_evidence=metadata.coordinate_system_evidence,
                    anatomical_identity=metadata.anatomical_identity or "unknown",
                    file_format=source_path.suffix.lower(),
                )
                self.current_analysis_record = record
                self.loaded_record = record.to_dict()
                self.save_button.setEnabled(True)
                self._refresh_right_panel()
                self.statusBar().showMessage("Mesh characteristics calculated using the selected analysis unit", 5000)
            except (AnalysisInputError, ValueError) as exc:
                QMessageBox.warning(self, "Analysis unavailable", str(exc))
            return
        if case is None or scan is None or validated is None or self.display_mode != "imported":
            QMessageBox.information(self, "No scan selected", "Select an imported scan before running analysis.")
            return
        self.statusBar().showMessage("Calculating geometric analysis…")
        QApplication.processEvents()
        try:
            if self.analysis_mode == "mesh_characteristics":
                analysis_unit = self._analysis_unit(f"case:{scan.scan_id}", scan.unit)
                record = analyze_mesh(
                    validated.mesh, case_id=case.case_id, scan_id=scan.scan_id,
                    source_sha256=scan.sha256, unit=analysis_unit, source_unit=scan.unit,
                    unit_evidence=scan.unit_evidence,
                    coordinate_system=scan.coordinate_system,
                    coordinate_frame_id=scan.coordinate_frame_id,
                    coordinate_evidence=scan.coordinate_system_evidence,
                    anatomical_identity=scan.anatomical_identity,
                    file_format=scan.file_format,
                )
                self.surface_distance_result = None
            else:
                if self.compare_scan_combo is None or self.compare_scan_combo.currentData() is None:
                    raise AnalysisPrerequisiteError("Import another scan into this case and select it for comparison.")
                if self.alignment_confirmation is None or not self.alignment_confirmation.isChecked():
                    raise AnalysisPrerequisiteError("Alignment has not been confirmed.")
                other = case.find_scan(self.compare_scan_combo.currentData())
                if other is None:
                    raise AnalysisPrerequisiteError("The second scan is no longer part of the active case.")
                other_mesh = self.case_store.load_scan_mesh(case, other)
                raw_thresholds = self.thresholds_input.text().split(",") if self.thresholds_input else []
                try:
                    thresholds = tuple(float(value.strip()) for value in raw_thresholds if value.strip())
                except ValueError as exc:
                    raise AnalysisInputError("Enter numeric, comma-separated thresholds in millimeters.") from exc
                sample_limit = int(self.sample_limit_combo.currentData()) if self.sample_limit_combo else 20000
                analysis_unit_a = self._analysis_unit(f"case:{scan.scan_id}", scan.unit)
                analysis_unit_b = self._analysis_unit(f"case:{other.scan_id}", other.unit)
                result = compare_surfaces(
                    validated.mesh, other_mesh.mesh, case_id=case.case_id,
                    scan_id_a=scan.scan_id, scan_id_b=other.scan_id,
                    source_sha256_a=scan.sha256, source_sha256_b=other.sha256,
                    unit_a=analysis_unit_a, unit_b=analysis_unit_b,
                    source_unit_a=scan.unit, source_unit_b=other.unit,
                    unit_evidence_a=scan.unit_evidence, unit_evidence_b=other.unit_evidence,
                    coordinate_system_a=scan.coordinate_system,
                    coordinate_system_b=other.coordinate_system,
                    coordinate_frame_id_a=scan.coordinate_frame_id,
                    coordinate_frame_id_b=other.coordinate_frame_id,
                    coordinate_evidence_a=scan.coordinate_system_evidence,
                    coordinate_evidence_b=other.coordinate_system_evidence,
                    anatomical_identity_a=scan.anatomical_identity,
                    anatomical_identity_b=other.anatomical_identity,
                    user_confirmed_aligned=True,
                    thresholds_mm=thresholds,
                    maximum_samples_per_direction=sample_limit,
                )
                record = result.record
                self.surface_distance_result = result
            self.current_analysis_record = record
            self.loaded_record = record.to_dict()
            self.save_button.setEnabled(True)
            self._refresh_right_panel()
            self.statusBar().showMessage("Analysis completed and ready to save", 5000)
        except (AnalysisInputError, AnalysisPrerequisiteError, CaseStoreError, ValueError) as exc:
            self.statusBar().clearMessage()
            QMessageBox.warning(self, "Analysis unavailable", str(exc))
        except Exception as exc:
            self.statusBar().clearMessage()
            QMessageBox.warning(self, "Analysis failed", f"No analysis result was saved.\n\n{exc}")

    def _show_empty_state(self) -> None:
        self.display_mode = "empty"
        self.imported_mesh = None
        self.display_meshes.clear()
        self.render_meshes.clear()
        self.quick_view_mode = False
        self.quick_view_meshes.clear()
        self.quick_view_paths.clear()
        self.display_pair_source_aligned = False
        self.current_analysis_record = None
        self.surface_distance_result = None
        self.loaded_record = None
        self._sync_popout_window()
        self.plotter.clear()
        configure_viewport_renderer(self.plotter, self.lighting_level)
        self.jaw_actors = {"upper": [], "lower": []}
        self.overlay_actors = []
        self.viewport_stack.setCurrentWidget(self.empty_state_page)
        self._update_empty_state_content()
        self._set_scan_controls_enabled(False)
        self.import_scan_button.setEnabled(True)
        self.demo_preview_button.setText("Illustrative Preview")
        if self.case_manager.viewport_state == "no_case":
            self.footer_text.setText("No case open · STL and PLY supported")
        elif self.case_manager.viewport_state == "empty_case":
            self.footer_text.setText("No scans in this case · STL and PLY supported")
        else:
            self.footer_text.setText("Select a scan from the active case")

    def _show_demo(self) -> None:
        """Explicitly display the procedural illustration for demo/development use."""
        self.display_mode = "demo"
        self.imported_mesh = None
        self.display_meshes.clear()
        self.render_meshes.clear()
        self.quick_view_mode = False
        self.quick_view_meshes.clear()
        self.quick_view_paths.clear()
        self.current_analysis_record = None
        self.surface_distance_result = None
        self.loaded_record = None
        self._sync_popout_window()
        self.plotter.clear()
        configure_viewport_renderer(self.plotter, self.lighting_level)
        self.jaw_actors = add_demo_arches(self.plotter)
        self.viewport_stack.setCurrentWidget(self.viewport_render_page)
        self.plotter.add_axes(line_width=1)
        self.plotter.reset_camera()
        self.plotter.camera.zoom(1.18)
        self.upper_button.setEnabled(True)
        self.lower_button.setEnabled(True)
        self.treatment_button.setEnabled(True)
        self.contact_button.setEnabled(True)
        self.deviation_button.setEnabled(True)
        self.demo_variant_combo.setEnabled(True)
        self.treatment_opacity_slider.setEnabled(True)
        self.save_button.setEnabled(False)
        self.reset_button.setEnabled(True)
        self.import_scan_button.setEnabled(True)
        self.demo_preview_button.setText("Hide Preview")
        self._apply_demo_visibility()
        self._set_demo_variant(self.demo_variant_combo.currentIndex())
        self._update_demo_overlays()
        self.footer_text.setText("Illustrative preview · illustrative geometry only")

    def _show_imported(self) -> None:
        if self.imported_mesh is None:
            return
        self.display_mode = "imported"
        self.plotter.clear()
        configure_viewport_renderer(self.plotter, self.lighting_level)
        self.viewport_stack.setCurrentWidget(self.viewport_render_page)
        self.jaw_actors = {"upper": [], "lower": []}
        self.overlay_actors = []
        if not self.display_meshes:
            self.display_meshes = {"single": self.imported_mesh.mesh}
        meshes_to_show = dict(self.display_meshes)
        if set(meshes_to_show) == {"upper", "lower"} and not self.display_pair_source_aligned:
            meshes_to_show["upper"], meshes_to_show["lower"] = align_arch_pair_for_display(
                meshes_to_show["upper"], meshes_to_show["lower"])
        self.render_meshes = meshes_to_show
        colors = {"upper": "#9fb6ca", "lower": "#c4b2c7"}
        for jaw, mesh in meshes_to_show.items():
            display_mesh = prepare_visualization_mesh(mesh)
            actor = self.plotter.add_mesh(
                display_mesh, color=colors.get(jaw, "#aebdcc"), smooth_shading=False,
                lighting=True, opacity=1.0, specular=.10, specular_power=20,
                ambient=.30, diffuse=.70, show_edges=False, culling=False,
            )
            actor.prop.SetInterpolationToPhong()
            actor.prop.SetBackfaceCulling(False)
            if jaw in self.jaw_actors:
                self.jaw_actors[jaw].append(actor)
        self.plotter.add_axes(line_width=1)
        self.plotter.reset_camera()
        self.plotter.camera.zoom(1.15)
        self.upper_button.setChecked(self.upper_visible)
        self.lower_button.setChecked(self.lower_visible)
        self.upper_button.setEnabled(bool(self.jaw_actors["upper"]))
        self.lower_button.setEnabled(bool(self.jaw_actors["lower"]))
        self._apply_scan_visibility()
        self.import_scan_button.setEnabled(True)
        self.treatment_button.setEnabled(False)
        self.contact_button.setEnabled(False)
        self.deviation_button.setEnabled(False)
        self.demo_variant_combo.setEnabled(False)
        self.treatment_opacity_slider.setEnabled(False)
        self.treatment_type.setEnabled(False)
        self.save_button.setEnabled(False)
        self.reset_button.setEnabled(True)
        self.demo_preview_button.setText("Illustrative Preview")
        scan = self.case_manager.scan
        if self.quick_view_mode:
            scan_label = ", ".join(path.name for path in self.quick_view_paths)
            self.footer_text.setText(f"Quick View · {scan_label} · not added to a case")
        else:
            scan_label = scan.label or scan.original_filename if scan else "Imported scan"
            self.footer_text.setText(f"{scan_label} · units and coordinate orientation are user supplied or unknown")
        self._sync_popout_window()
        self._refresh_right_panel()

    def _apply_scan_visibility(self) -> None:
        for actor in self.jaw_actors.get("upper", []):
            actor.SetVisibility(self.upper_visible)
        for actor in self.jaw_actors.get("lower", []):
            actor.SetVisibility(self.lower_visible)
        if self.display_mode == "imported":
            self.plotter.render()
            self._sync_popout_window()

    def _toggle_demo_preview(self) -> None:
        if self.display_mode == "demo":
            self._show_empty_state()
            self._refresh_right_panel()
        else:
            self._show_demo()
            self._refresh_right_panel()

    def _toggle_popout_window(self) -> None:
        if self.popout_window is not None:
            self.popout_window.close()
            return
        window = SimulationPopoutWindow(self)
        window.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        window.closed.connect(self._on_popout_window_closed)
        self.popout_window = window
        self._sync_popout_window()
        self.popout_button.setToolTip("Close the separate simulation window")
        window.show()

    def _on_popout_window_closed(self) -> None:
        self.popout_window = None
        self.popout_button.setToolTip("Open the current simulation in a larger, separate window")

    def _sync_popout_window(self) -> None:
        if self.popout_window is None:
            return
        scene = self._snapshot_render_scene()
        camera = self.plotter.renderer.GetActiveCamera()
        self.popout_window.set_simulation(self.display_mode, scene, camera)

    def _snapshot_render_scene(self) -> list[dict]:
        """Copy renderable surface actors while retaining their exact transforms."""
        scene = []
        try:
            actors = tuple(self.plotter.renderer.actors.values())
        except Exception:
            return scene
        for source in actors:
            try:
                mapper = source.GetMapper()
                dataset = mapper.GetInput() if mapper is not None else None
                if dataset is None or dataset.GetNumberOfPoints() == 0:
                    continue
                mesh = pv.wrap(dataset).copy(deep=True)
                prop = source.GetProperty()
                scene.append({
                    "mesh": mesh,
                    "color": tuple(prop.GetColor()),
                    "opacity": prop.GetOpacity(),
                    "ambient": prop.GetAmbient(),
                    "diffuse": prop.GetDiffuse(),
                    "specular": prop.GetSpecular(),
                    "specular_power": prop.GetSpecularPower(),
                    "show_edges": bool(prop.GetEdgeVisibility()),
                    "origin": source.GetOrigin(),
                    "position": source.GetPosition(),
                    "orientation": source.GetOrientation(),
                    "scale": source.GetScale(),
                    "visibility": bool(source.GetVisibility()),
                })
            except Exception:
                continue
        return scene

    def _render_popout_view(self, *_args) -> None:
        """Redraw both windows after either view changes the shared camera."""
        if self.popout_window is None:
            return
        try:
            self.plotter.render()
        except Exception:
            pass
        try:
            self.popout_window.plotter.render()
        except Exception:
            pass

    def _apply_demo_visibility(self) -> None:
        for actor in self.jaw_actors.get("upper", []):
            actor.SetVisibility(self.upper_visible)
        for actor in self.jaw_actors.get("lower", []):
            actor.SetVisibility(self.lower_visible)
        self.plotter.render()
        self._sync_popout_window()

    def _clear_overlays(self) -> None:
        for actor in self.overlay_actors:
            try:
                self.plotter.remove_actor(actor)
            except Exception:
                pass
        self.overlay_actors = []

    def _update_demo_overlays(self) -> None:
        self._clear_overlays()
        if self.display_mode != "demo":
            return
        if self.treatment_visible:
            center = (0.10 if self.alternative_design else 0.0, -1.5, .66)
            radius = .145 if self.alternative_design else .16
            mesh = pv.Sphere(radius=radius, center=center, theta_resolution=28, phi_resolution=20)
            self.overlay_actors.append(self.plotter.add_mesh(mesh, color="#8ca1ff", opacity=self.treatment_opacity,
                                                              smooth_shading=True, specular=.45))
        if self.contact_visible:
            for x, color in [(-1.23, "#ff6689"), (-.53, "#ffb65d"), (.17, "#ff6689"),
                             (.88, "#65c7b0"), (1.58, "#ffb65d")]:
                y = -1.5 + 1.38 * abs(x / 2.28) ** 1.65
                marker = pv.Sphere(radius=.12, center=(x, y, .86), theta_resolution=16, phi_resolution=12)
                self.overlay_actors.append(self.plotter.add_mesh(marker, color=color, opacity=.9,
                                                                  smooth_shading=True))
        if self.deviation_visible:
            deviation_x = .4
            deviation_y = -1.5 + 1.38 * abs(deviation_x / 2.28) ** 1.65
            marker = pv.Sphere(radius=.13, center=(deviation_x, deviation_y, .86), theta_resolution=20, phi_resolution=14)
            self.overlay_actors.append(self.plotter.add_mesh(marker, color="#b087f2", opacity=.88,
                                                              smooth_shading=True))
        self.plotter.render()
        self._sync_popout_window()

    def _set_upper_visible(self, visible: bool) -> None:
        self.upper_visible = visible
        if self.display_mode == "imported":
            self._apply_scan_visibility()
        else:
            self._apply_demo_visibility()

    def _set_lower_visible(self, visible: bool) -> None:
        self.lower_visible = visible
        if self.display_mode == "imported":
            self._apply_scan_visibility()
        else:
            self._apply_demo_visibility()

    def _toggle_treatment(self, visible: bool) -> None:
        self.treatment_visible = visible
        self._update_demo_overlays()

    def _set_treatment_opacity(self, value: int) -> None:
        self.treatment_opacity = value / 100
        self._update_demo_overlays()

    def _toggle_contacts(self, visible: bool) -> None:
        self.contact_visible = visible
        self._update_demo_overlays()

    def _toggle_alternative(self) -> None:
        self.alternative_design = not self.alternative_design
        self._update_demo_overlays()
        self.statusBar().showMessage("Alternative illustrative contour toggled", 2500)

    def _toggle_deviation(self, visible: bool) -> None:
        self.deviation_visible = visible
        self._update_demo_overlays()

    def _set_demo_variant(self, index: int) -> None:
        offset = .035 if index else 0.0
        for actors in self.jaw_actors.values():
            for actor in actors:
                actor.SetPosition((offset, 0, 0))
        self._update_demo_overlays()

    def _scan_selection_changed(self, index: int) -> None:
        scan_id = self.scan_combo.itemData(index)
        if scan_id is None:
            if self.case_manager.active_case:
                self.case_manager.select_scan(None)
            self.imported_mesh = None
            self._show_empty_state()
            self._refresh_case_controls()
            self._refresh_right_panel()
            return
        try:
            self._display_case_scan(scan_id)
        except CaseStoreError as exc:
            QMessageBox.warning(self, "Could not display scan", str(exc))
            self.case_manager.select_scan(None)
            self.scan_combo.blockSignals(True)
            self.scan_combo.setCurrentIndex(0)
            self.scan_combo.blockSignals(False)
            self._show_empty_state()
            self._refresh_case_controls()
            self._refresh_right_panel()

    def open_item(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Open", "",
            "Dental scans and analysis records (*.stl *.ply *.json)",
        )
        if not path:
            return
        source = Path(path)
        try:
            if source.suffix.lower() == ".json":
                self.loaded_record = load_record(source)
                self.current_analysis_record = None
                self.surface_distance_result = None
                self.save_button.setEnabled(False)
                self._refresh_right_panel()
                self.statusBar().showMessage("Analysis record loaded; displayed values are stored record data", 5000)
                return
        except ValueError as exc:
            QMessageBox.warning(self, "Unable to open item", str(exc))
            return
        self.import_scan(str(source))

    def save_analysis_record(self) -> None:
        record = self.current_analysis_record
        if record is None or record.status != "completed":
            QMessageBox.information(self, "No completed analysis", "Run an analysis before saving an analysis record.")
            return
        case = self.case_manager.active_case
        default_path = "Dental3D-analysis-record.json"
        if case is not None:
            analysis_dir = case.case_folder / "analysis"
            try:
                analysis_dir.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                QMessageBox.warning(
                    self, "Unable to prepare analysis folder",
                    f"The analysis record was not saved.\n\n{exc}",
                )
                return
            default_path = str(analysis_dir / f"{record.analysis_id}.json")
        path, _ = QFileDialog.getSaveFileName(
            self, "Save completed analysis record", default_path, "Analysis record (*.json)")
        if not path:
            return
        try:
            save_record(path, record)
        except OSError as exc:
            QMessageBox.warning(self, "Unable to save record", f"The record was not saved.\n\n{exc}")
            return
        self.loaded_record = record.to_dict()
        self._refresh_right_panel()
        self.statusBar().showMessage("Uncomputed analysis record saved with source provenance", 4500)

    def show_settings(self) -> None:
        dialog = QDialog(self)
        dialog.setObjectName("appModalDialog")
        dialog.setWindowTitle("Dental3D Studio settings")
        dialog.setMinimumWidth(390)
        layout = QVBoxLayout(dialog)
        layout.addWidget(make_label("Prototype information", "title"))
        layout.addWidget(make_label("Viewport lighting", "cardTitle"))
        layout.addWidget(make_label(
            "Adjust shared illumination for the main and pop-out 3D views.", "muted", True))
        lighting_row = QHBoxLayout()
        lighting_slider = QSlider(Qt.Horizontal, dialog)
        lighting_slider.setRange(LIGHTING_MIN, LIGHTING_MAX)
        lighting_slider.setValue(self.lighting_level)
        lighting_slider.setAccessibleName("Viewport lighting intensity")
        lighting_slider.setToolTip("The minimum remains at the existing low-light level")
        lighting_value = make_label(f"{self.lighting_level}%", "muted")
        lighting_slider.valueChanged.connect(self._set_lighting_intensity)
        lighting_slider.valueChanged.connect(lambda value: lighting_value.setText(f"{value}%"))
        self.settings_lighting_slider = lighting_slider
        lighting_row.addWidget(lighting_slider, 1)
        lighting_row.addWidget(lighting_value)
        layout.addLayout(lighting_row)
        layout.addWidget(make_label("Case storage folder", "cardTitle"))
        layout.addWidget(make_label(str(self.case_store.root), "muted", True))
        change_root = QPushButton("Change storage folder…")
        change_root.clicked.connect(lambda: (dialog.accept(), self._change_cases_root()))
        layout.addWidget(change_root)
        layout.addWidget(make_label(
            "Scan import currently supports STL and PLY surface meshes. The app does not infer units, coordinate orientation, scan compatibility, or anatomical identity.",
            "muted", True))
        layout.addWidget(make_label(
            "No cloud service is used. Case metadata records the original path and stores a managed scan copy. Use pseudonymous patient references.",
            "muted", True))
        close = QPushButton("Close")
        close.clicked.connect(dialog.accept)
        layout.addWidget(close, alignment=Qt.AlignRight)
        dialog.exec()
        self.settings_lighting_slider = None

    def reset_camera(self) -> None:
        self.plotter.view_isometric()
        self.plotter.reset_camera()
        self.plotter.camera.zoom(1.18 if self.display_mode == "demo" else 1.15)
        self.plotter.render()
        self._sync_popout_window()

    def _set_lighting_intensity(self, value: int) -> None:
        value = max(LIGHTING_MIN, min(LIGHTING_MAX, int(value)))
        if value == self.lighting_level:
            return
        self.lighting_level = value
        self.settings.setValue("lighting_intensity", value)
        slider = self.settings_lighting_slider
        if slider is not None and slider.value() != value:
            slider.blockSignals(True)
            slider.setValue(value)
            slider.blockSignals(False)
        apply_viewport_lighting(self.plotter, value)
        self.plotter.render()
        if self.popout_window is not None:
            apply_viewport_lighting(self.popout_window.plotter, value)
            self.popout_window.plotter.render()

    # ---- Retainer generation ----

    def _refresh_retainer_ui(self) -> None:
        """Update retainer controls based on current case/scan state."""
        self.retainer_source_combo.blockSignals(True)
        self.retainer_source_combo.clear()
        self.retainer_source_combo.addItem("No scan available", None)

        case = self.case_manager.active_case
        if case is not None and case.scans:
            for scan in case.scans:
                label = scan.label or scan.original_filename
                self.retainer_source_combo.addItem(label, scan.scan_id)

        self.retainer_generate_button.setEnabled(case is not None and len(case.scans) > 0)
        self.retainer_import_button.setEnabled(case is not None)
        self.retainer_save_button.setEnabled(self._generated_retainer is not None)

        # Refresh saved retainers list with visibility/opacity controls
        self._refresh_retainer_rows()

        # Refresh comparison combos
        self._refresh_compare_combos()

    def _refresh_retainer_rows(self) -> None:
        """Rebuild the retainer rows with visibility/opacity/remove controls."""
        # Clear existing rows
        while self.retainer_rows_layout.count():
            item = self.retainer_rows_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        case = self.case_manager.active_case
        if not case:
            return

        # Load retainer records
        retainer_ids = list_retainer_ids(case.case_folder)
        self.retainers = {}
        for rid in retainer_ids:
            record = load_retainer_record(case.case_folder, rid)
            if record:
                self.retainers[rid] = record
                if rid not in self.retainer_visible:
                    self.retainer_visible[rid] = True
                if rid not in self.retainer_opacity:
                    self.retainer_opacity[rid] = 0.7

        self.retainer_import_button.setEnabled(case is not None)

        for rid, record in self.retainers.items():
            row = QWidget()
            row_layout = QHBoxLayout(row)
            row_layout.setContentsMargins(0, 0, 0, 0)
            row_layout.setSpacing(8)

            gen_type = "Generated" if record.generation_method != "imported" else "Imported"
            name_label = make_label(f"{record.retainer_id[:12]}... ({gen_type})", "", True)
            name_label.setMinimumWidth(120)
            row_layout.addWidget(name_label)

            type_label = make_label(record.generation_method, "", True)
            row_layout.addWidget(type_label)

            jaw_label = make_label(record.jaw.title(), "", True)
            row_layout.addWidget(jaw_label)

            vis_cb = QCheckBox()
            vis_cb.setChecked(self.retainer_visible.get(rid, True))
            vis_cb.stateChanged.connect(lambda state, rid=rid: self._toggle_retainer_visibility(rid, state))
            row_layout.addWidget(vis_cb)

            opacity_slider = QSlider(Qt.Horizontal)
            opacity_slider.setRange(0, 100)
            opacity_slider.setValue(int(self.retainer_opacity.get(rid, 0.7) * 100))
            opacity_slider.setFixedWidth(100)
            opacity_slider.valueChanged.connect(lambda val, rid=rid: self._set_retainer_opacity(rid, val / 100.0))
            row_layout.addWidget(opacity_slider)

            remove_btn = QPushButton("Remove")
            remove_btn.setFixedWidth(70)
            remove_btn.clicked.connect(lambda checked, rid=rid: self._remove_retainer(rid))
            row_layout.addWidget(remove_btn)

            row_layout.addStretch(1)
            self.retainer_rows_layout.addWidget(row)

        self.retainer_rows_layout.addStretch(1)

    def _refresh_compare_combos(self) -> None:
        """Refresh the comparison combo boxes."""
        self.compare_retainer_combo.blockSignals(True)
        self.compare_scan_combo.blockSignals(True)

        self.compare_retainer_combo.clear()
        self.compare_retainer_combo.addItem("No retainers", None)

        self.compare_scan_combo.clear()
        self.compare_scan_combo.addItem("No scans", None)

        case = self.case_manager.active_case
        if case:
            for rid, record in self.retainers.items():
                self.compare_retainer_combo.addItem(f"{record.retainer_id[:12]}... ({record.jaw})", rid)
            for scan in case.scans:
                label = scan.label or scan.original_filename
                self.compare_scan_combo.addItem(label, scan.scan_id)

        self.compare_retainer_combo.blockSignals(False)
        self.compare_scan_combo.blockSignals(False)
        self._update_compare_button_state()

    def _toggle_retainer_visibility(self, retainer_id: str, state: int) -> None:
        """Toggle visibility of a retainer in the viewport."""
        visible = state == Qt.Checked
        self.retainer_visible[retainer_id] = visible
        record = self.retainers.get(retainer_id)
        if not record:
            return

        if retainer_id in self.retainer_actors:
            actor = self.retainer_actors[retainer_id]
            actor.SetVisibility(visible)
            self.plotter.render()
        elif record.mesh_path and record.mesh_path.is_file():
            try:
                mesh = pv.read(record.mesh_path)
                color = "#ff6b35" if record.generation_method != "imported" else "#4a90d9"
                actor = self.plotter.add_mesh(mesh, color=color, opacity=self.retainer_opacity.get(retainer_id, 0.7), name=f"retainer_{retainer_id}")
                actor.SetVisibility(visible)
                self.retainer_actors[retainer_id] = actor
                self.plotter.render()
            except Exception:
                pass

    def _set_retainer_opacity(self, retainer_id: str, opacity: float) -> None:
        """Set opacity of a retainer actor."""
        self.retainer_opacity[retainer_id] = opacity
        record = self.retainers.get(retainer_id)
        if not record:
            return
        if retainer_id in self.retainer_actors:
            actor = self.retainer_actors[retainer_id]
            actor.GetProperty().SetOpacity(opacity)
            self.plotter.render()

    def _remove_retainer(self, retainer_id: str) -> None:
        """Remove a retainer record with confirmation."""
        from PySide6.QtWidgets import QMessageBox
        record = self.retainers.get(retainer_id)
        if not record:
            return

        reply = QMessageBox.question(
            self,
            "Remove Retainer",
            f"Remove retainer {retainer_id} from this case?\n"
            f"The mesh file will be preserved in case storage.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply != QMessageBox.StandardButton.Yes:
            return

        case = self.case_manager.active_case
        if not case:
            return

        if retainer_id in self.retainer_actors:
            actor = self.retainer_actors.pop(retainer_id)
            try:
                self.plotter.remove_actor(actor)
            except Exception:
                pass
            self.plotter.render()

        remove_retainer_record(case.case_folder, retainer_id, delete_mesh=False)
        del self.retainers[retainer_id]
        self.retainer_visible.pop(retainer_id, None)
        self.retainer_opacity.pop(retainer_id, None)
        if self.selected_retainer_id == retainer_id:
            self.selected_retainer_id = None

        self._refresh_retainer_rows()
        self._refresh_compare_combos()

    def _compare_retainer_changed(self, index: int) -> None:
        """Handle retainer selection change for comparison."""
        self.compare_retainer_id = self.compare_retainer_combo.currentData()
        self._update_compare_button_state()

    def _compare_scan_changed(self, index: int) -> None:
        """Handle scan selection change for comparison."""
        self.compare_scan_id = self.compare_scan_combo.currentData()
        self._update_compare_button_state()

    def _update_compare_button_state(self) -> None:
        """Enable compare button only when both retainer and scan selected."""
        self.compare_button.setEnabled(
            self.compare_retainer_id is not None and self.compare_scan_id is not None
        )

    def _import_retainer(self) -> None:
        """Import an existing retainer STL/PLY file into the active case."""
        case = self.case_manager.active_case
        if not case:
            return

        file_dialog = QFileDialog(self)
        file_dialog.setWindowTitle("Import Retainer")
        file_dialog.setNameFilter("Retainer files (*.stl *.ply)")
        file_dialog.setFileMode(QFileDialog.FileMode.ExistingFile)
        if file_dialog.exec() != QDialog.DialogCode.Accepted:
            return

        selected = file_dialog.selectedFiles()
        if not selected:
            return
        source_path = Path(selected[0])

        # Show import dialog for metadata
        dialog = QDialog(self)
        dialog.setWindowTitle("Import Retainer")
        dialog.setMinimumWidth(430)
        layout = QVBoxLayout(dialog)

        layout.addWidget(make_label("Import Retainer Model", "title", True))
        layout.addWidget(make_label(f"Source file: {source_path.name}", "muted", True))

        form = QFormLayout()

        jaw_combo = QComboBox()
        jaw_combo.addItem("Upper", "upper")
        jaw_combo.addItem("Lower", "lower")
        form.addRow("Jaw", jaw_combo)

        unit_combo = QComboBox()
        unit_combo.addItem("Unknown", "unknown")
        unit_combo.addItem("Millimeters (mm)", "mm")
        unit_combo.addItem("Centimeters (cm)", "cm")
        unit_combo.addItem("Micrometers (µm)", "um")
        unit_combo.addItem("Inches (in)", "in")
        form.addRow("Coordinate Unit", unit_combo)

        coord_combo = QComboBox()
        coord_combo.addItem("Unknown", "unknown")
        coord_combo.addItem("RAS", "RAS")
        coord_combo.addItem("LPS", "LPS")
        coord_combo.addItem("Local frame", "local")
        form.addRow("Coordinate System", coord_combo)

        frame_field = QLineEdit()
        frame_field.setMaxLength(160)
        frame_field.setPlaceholderText("Shared frame ID, if documented")
        form.addRow("Frame identity", frame_field)
        evidence_field = QLineEdit()
        evidence_field.setMaxLength(500)
        evidence_field.setPlaceholderText("Source documenting convention and frame")
        form.addRow("Coordinate evidence", evidence_field)

        anatomy_combo = QComboBox()
        anatomy_combo.addItem("Unknown", "unknown")
        anatomy_combo.addItem("Upper arch", "upper_arch")
        anatomy_combo.addItem("Lower arch", "lower_arch")
        anatomy_combo.addItem("Whole dentition", "whole_dentition")
        form.addRow("Anatomical Region", anatomy_combo)

        layout.addLayout(form)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)

        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        jaw = jaw_combo.currentData()
        units = unit_combo.currentData()
        coord_system = coord_combo.currentData()
        anatomy = anatomy_combo.currentData()

        source_scan_id = self.retainer_source_combo.currentData()

        try:
            record = import_retainer_file(
                case_folder=case.case_folder,
                source_path=source_path,
                jaw=jaw,
                source_scan_id=source_scan_id,
                case_id=case.case_id,
                units=units,
                coordinate_system=coord_system,
                coordinate_frame_id=frame_field.text().strip() or "unknown",
                coordinate_system_evidence=evidence_field.text().strip(),
                anatomical_identity=anatomy,
            )
        except Exception as exc:
            self.retainer_status_label.setText(f"Import failed: {exc}")
            return

        self.retainers[record.retainer_id] = record
        self.retainer_visible[record.retainer_id] = True
        self.retainer_opacity[record.retainer_id] = 0.7

        self._refresh_retainer_rows()
        self._refresh_compare_combos()
        self.retainer_status_label.setText(f"Imported retainer {record.retainer_id[:12]}...")

    def _compare_retainer_to_scan(self) -> None:
        """Perform geometric comparison between selected retainer and scan."""
        case = self.case_manager.active_case
        if not case:
            return

        retainer_id = self.compare_retainer_id
        scan_id = self.compare_scan_id
        if not retainer_id or not scan_id:
            return

        retainer_record = self.retainers.get(retainer_id)
        scan_record = case.find_scan(scan_id)
        if not retainer_record or not scan_record:
            return

        alignment_confirmed = self.compare_alignment_checkbox.isChecked()

        compatible, warnings = check_compatibility(retainer_record, scan_record, alignment_confirmed)
        if not compatible:
            warning_text = "\n".join(f"• {w}" for w in warnings)
            self.compare_result_label.setText(f"Comparison blocked:\n{warning_text}")
            self.compare_result_label.setStyleSheet("color: #a3424a;")
            return

        try:
            retainer_mesh = pv.read(retainer_record.mesh_path) if retainer_record.mesh_path and retainer_record.mesh_path.is_file() else None
            if retainer_mesh is None:
                self.compare_result_label.setText("Retainer mesh file not found.")
                self.compare_result_label.setStyleSheet("color: #a3424a;")
                return

            validated_scan = self.case_store.load_scan_mesh(case, scan_record)
            scan_mesh = validated_scan.mesh
        except Exception as exc:
            self.compare_result_label.setText(f"Failed to load meshes: {exc}")
            self.compare_result_label.setStyleSheet("color: #a3424a;")
            return

        try:
            result = compare_retainer_to_scan(
                retainer_mesh=retainer_mesh,
                dental_scan_mesh=scan_mesh,
                retainer_record=retainer_record,
                dental_scan_record=scan_record,
                alignment_confirmed=alignment_confirmed,
            )
        except RetainerComparisonError as exc:
            self.compare_result_label.setText(str(exc))
            self.compare_result_label.setStyleSheet("color: #a3424a;")
            return

        metrics_text = " | ".join(
            f"{m['metric']}: {m['value']:.4f} mm" if 'distance' in m['metric'] or 'rms' in m['metric']
            else f"{m['metric']}: {m['value']}"
            for m in result.measurements
        )
        self.compare_result_label.setText(
            f"Comparison complete.\n{metrics_text}"
        )
        self.compare_result_label.setStyleSheet("color: #28313a;")

        # Save comparison record as analysis
        try:
            analysis_record = AnalysisRecord(
                schema_version=2,
                case_id=case.case_id,
                status="completed",
                source_kind="retainer_vs_scan",
                source_sha256=retainer_record.mesh_sha256,
                method_id="bidirectional_surface_distance",
                method_version=result.method_version,
                source_metadata={
                    "retainer_id": retainer_record.retainer_id,
                    "scan_id": scan_record.scan_id,
                    "comparison_type": "retainer_vs_scan",
                },
                parameters=result.parameters,
                measurements=result.measurements,
                warnings=list(result.warnings),
                created_at_utc=result.created_at_utc,
                analysis_id=result.comparison_id,
                analysis_type="retainer_vs_scan_comparison",
                source_scan_ids=[retainer_record.retainer_id, scan_record.scan_id],
                source_sha256s=[v for v in (retainer_record.mesh_sha256, scan_record.sha256) if v],
                units_assumptions=result.units_assumptions,
                coordinate_assumptions=result.coordinate_assumptions,
                alignment_status="user_confirmed" if alignment_confirmed else "unconfirmed",
                transformations=[],
                spatial_deviations=result.spatial_deviations,
            )
            analysis_path = case.case_folder / "analysis" / f"{result.comparison_id}.json"
            analysis_path.parent.mkdir(parents=True, exist_ok=True)
            save_record(analysis_path, analysis_record)
        except Exception as exc:
            self.compare_result_label.setText(
                f"Comparison calculated, but its record could not be saved: {exc}")
            self.compare_result_label.setStyleSheet("color: #a3424a;")

    def _clear_retainers_from_viewport(self) -> None:
        """Remove all retainer actors from the viewport."""
        for retainer_id, actor in list(self.retainer_actors.items()):
            try:
                self.plotter.remove_actor(actor)
            except Exception:
                pass
        self.retainer_actors.clear()

    def _generate_retainer(self) -> None:
        """Generate a preliminary retainer shell from the selected scan."""
        case = self.case_manager.active_case
        if case is None:
            self.retainer_status_label.setText("No active case.")
            return

        scan_id = self.retainer_source_combo.currentData()
        if scan_id is None:
            self.retainer_status_label.setText("No source scan selected.")
            return

        scan = case.find_scan(scan_id)
        if scan is None:
            self.retainer_status_label.setText("Source scan not found.")
            return

        try:
            validated = self.case_store.load_scan_mesh(case, scan)
        except Exception as exc:
            self.retainer_status_label.setText(f"Cannot load source mesh: {exc}")
            return

        jaw = "upper" if self.retainer_jaw_upper.isChecked() else "lower"
        thickness = self.retainer_thickness_spin.value()
        trim = self.retainer_trim_spin.value()

        if thickness <= 0:
            self.retainer_status_label.setText("Shell thickness must be positive.")
            return
        if trim < 0:
            self.retainer_status_label.setText("Coverage trim cannot be negative.")
            return

        try:
            shell = generate_retainer_surface(
                validated.mesh,
                jaw=jaw,
                max_distance=thickness,
                min_distance=thickness * 0.5,
                coverage_trim_mm=trim,
            )
        except RetainerGenerationError as exc:
            self.retainer_status_label.setText(f"Generation failed: {exc}")
            return

        valid, warnings = validate_generated_mesh(shell)
        self._generated_retainer = shell
        self._generated_retainer_valid = valid
        self._generated_retainer_warnings = warnings
        self._generated_retainer_params = {
            "jaw": jaw,
            "thickness": thickness,
            "trim_mm": trim,
        }
        self._generated_retainer_source_scan = scan

        case_folder = case.case_folder
        retainers_dir = case_folder / "retainers"
        retainers_dir.mkdir(parents=True, exist_ok=True)

        temp_mesh_path = retainers_dir / "pending_retainer.stl"
        shell.save(str(temp_mesh_path))

        self.retainer_save_button.setEnabled(True)

        warning_text = "; ".join(warnings) if warnings else "OK"
        status = f"Generated {jaw} retainer shell ({shell.n_points} pts, {shell.n_faces} faces). {warning_text}"
        self.retainer_status_label.setText(status)
        self.retainer_status_label.setStyleSheet("color: #68727c;")

        # Register as a pending retainer for immediate viewport display
        pending_id = "PENDING"
        self.retainers[pending_id] = type("obj", (object,), {
            "retainer_id": pending_id,
            "jaw": jaw,
            "generation_method": "thin_surface_shell_offset",
            "mesh_path": temp_mesh_path,
            "mesh_sha256": None,
            "source_metadata": {},
            "parameters": self._generated_retainer_params,
            "warnings": warnings,
        })()
        self.retainer_visible[pending_id] = True
        self.retainer_opacity[pending_id] = 0.6
        self.selected_retainer_id = pending_id

        try:
            actor = self.plotter.add_mesh(shell, color="#ff6b35", opacity=0.6, name="retainer_shell")
            self.retainer_actors[pending_id] = actor
            self.plotter.render()
        except Exception:
            pass

    def _save_retainer(self) -> None:
        """Save the generated retainer as a persistent record."""
        if not hasattr(self, "_generated_retainer") or self._generated_retainer is None:
            self.retainer_status_label.setText("No generated retainer to save.")
            return

        case = self.case_manager.active_case
        if case is None:
            return

        scan = self._generated_retainer_source_scan
        params = self._generated_retainer_params
        warnings = self._generated_retainer_warnings or []

        case_folder = case.case_folder
        retainers_dir = case_folder / "retainers"
        retainers_dir.mkdir(parents=True, exist_ok=True)

        mesh_path = retainers_dir / f"{scan.scan_id}_retainer.stl"
        self._generated_retainer.save(str(mesh_path))

        mesh_sha256 = sha256_file(mesh_path)
        file_size_bytes = mesh_path.stat().st_size
        point_count = int(self._generated_retainer.n_points)
        face_count = int(self._generated_retainer.n_faces)

        record = create_retainer_record(
            case=case,
            scan=scan,
            mesh_path=mesh_path,
            mesh_sha256=mesh_sha256,
            file_size_bytes=file_size_bytes,
            point_count=point_count,
            face_count=face_count,
            jaw=params["jaw"],
            parameters=params,
            warnings_list=warnings,
        )

        try:
            store_retainer_record(case_folder, record)
        except Exception as exc:
            self.retainer_status_label.setText(f"Save failed: {exc}")
            return

        self.retainer_save_button.setEnabled(False)
        self._refresh_retainer_rows()
        self._refresh_compare_combos()

        self.retainer_status_label.setText(f"Saved retainer {record.retainer_id}.")

    def _retainer_selection_changed(self) -> None:
        """Handle selection change in saved retainers list."""
        pass

    def closeEvent(self, event) -> None:
        if not self._confirm_unsaved_case_changes():
            event.ignore()
            return
        if self.popout_window is not None:
            self.popout_window.close()
        self.plotter.close()
        super().closeEvent(event)


def launch() -> None:
    app = QApplication.instance() or QApplication(sys.argv)
    app.setWindowIcon(QIcon(str(Path(__file__).resolve().parents[2] / "assets" / "dental3d_studio_icon.ico")))
    app.setStyle("Fusion")
    cursor_filter = ButtonCursorEventFilter(app)
    app.installEventFilter(cursor_filter)
    app.setStyleSheet(STYLE)
    window = DentalStudioWindow()
    window.show()
    app.exec()
