"""Versioned JSON persistence with conservative schema checks."""
import json
import re
from pathlib import Path
from typing import Any
from dental3d.analysis.geometric_analysis import AnalysisRecord


REQUIRED_FIELDS = {
    "schema_version", "case_id", "status", "source_kind", "source_sha256",
    "method_id", "method_version", "source_metadata", "parameters", "measurements", "warnings",
    "created_at_utc",
}


def save_record(path: str | Path, record: AnalysisRecord) -> None:
    destination = Path(path)
    with destination.open("w", encoding="utf-8") as stream:
        json.dump(record.to_dict(), stream, indent=2, ensure_ascii=False, allow_nan=False)


def _reject_nonfinite_constant(value: str) -> None:
    raise ValueError(f"Non-standard numeric value {value!r} is not allowed in an analysis record.")


def load_record(path: str | Path) -> dict[str, Any]:
    source = Path(path)
    try:
        with source.open("r", encoding="utf-8") as stream:
            data = json.load(stream, parse_constant=_reject_nonfinite_constant)
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        raise ValueError(f"Could not read the analysis record: {exc}") from exc
    if not isinstance(data, dict) or not REQUIRED_FIELDS.issubset(data):
        raise ValueError("This JSON file is not a supported Dental3D analysis record.")
    if data.get("schema_version") not in {1, 2}:
        raise ValueError(f"Unsupported analysis-record schema version: {data.get('schema_version')!r}.")
    if not isinstance(data.get("case_id"), str) or not data["case_id"].strip():
        raise ValueError("The analysis record has no valid case identifier.")
    if not isinstance(data.get("status"), str) or not isinstance(data.get("source_kind"), str):
        raise ValueError("The analysis record has invalid status or source fields.")
    if not isinstance(data.get("source_metadata"), dict) or not isinstance(data.get("parameters"), dict):
        raise ValueError("The analysis record has invalid metadata or parameter fields.")
    if (not isinstance(data.get("measurements"), list)
            or any(not isinstance(item, dict) for item in data["measurements"])):
        raise ValueError("The analysis record has an invalid measurements field.")
    if not isinstance(data.get("warnings"), list) or any(not isinstance(item, str) for item in data["warnings"]):
        raise ValueError("The analysis record has an invalid warnings field.")
    if data["schema_version"] == 2:
        extended = {
            "analysis_id", "analysis_type", "source_scan_ids", "source_sha256s",
            "units_assumptions", "coordinate_assumptions", "alignment_status", "transformations",
            "spatial_deviations",
        }
        if not extended.issubset(data):
            raise ValueError("The version 2 analysis record is incomplete.")
        if not isinstance(data["analysis_id"], str) or not data["analysis_id"].strip():
            raise ValueError("The analysis record has no valid analysis ID.")
        if not isinstance(data["analysis_type"], str) or not data["analysis_type"].strip():
            raise ValueError("The analysis record has no valid analysis type.")
        if any(not isinstance(data[key], list) or any(not isinstance(item, str) for item in data[key])
               for key in ("source_scan_ids", "source_sha256s")):
            raise ValueError("The analysis record has invalid source scan identifiers or hashes.")
        if any(not re.fullmatch(r"[0-9a-f]{64}", item) for item in data["source_sha256s"]):
            raise ValueError("The analysis record contains an invalid source scan hash.")
        if any(not isinstance(data[key], dict) for key in ("units_assumptions", "coordinate_assumptions")):
            raise ValueError("The analysis record has invalid unit or coordinate assumptions.")
        if not isinstance(data["alignment_status"], str):
            raise ValueError("The analysis record has an invalid alignment status.")
        if not isinstance(data["transformations"], list) or any(not isinstance(item, dict) for item in data["transformations"]):
            raise ValueError("The analysis record has invalid transformations.")
        if not isinstance(data["spatial_deviations"], dict):
            raise ValueError("The analysis record has invalid spatial deviation data.")
    digest = data.get("source_sha256")
    if digest is not None and (not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest)):
        raise ValueError("The analysis record has an invalid source checksum.")
    return data
