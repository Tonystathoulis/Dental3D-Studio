"""Persistence for preliminary retainer records.

Stores retainer records with the case metadata and the generated mesh as a
separate file. Multiple retainer versions are allowed; saving never
overwrites previous versions.
"""

import json
import logging
import re
import shutil
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from typing import Any, Optional

import pyvista as pv

from dental3d.domain.retainer_record import RetainerRecord

logger = logging.getLogger(__name__)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_filename(name: str) -> str:
    leaf = Path(name.replace("\\", "/")).name
    leaf = re.sub(r"[^A-Za-z0-9._ -]", "_", leaf).strip(" .")
    return leaf[:150] if leaf else "retainer"


def _retainer_key_path(case_folder: Path, retainer_id: str) -> Path:
    return case_folder / "retainers" / f"{retainer_id}.json"


def _mesh_path(case_folder: Path, retainer_id: str, extension: str) -> Path:
    return case_folder / "retainers" / f"{retainer_id}.{extension}"


def store_retainer_record(case_folder: Path, record: RetainerRecord) -> Path:
    """Write a retainer record JSON and copy the generated mesh file."""
    case_folder.mkdir(parents=True, exist_ok=True)
    retainers_dir = case_folder / "retainers"
    retainers_dir.mkdir(parents=True, exist_ok=True)

    record_path = _retainer_key_path(case_folder, record.retainer_id)
    extension = record.mesh_path.suffix.lower().lstrip(".") or "stl"
    mesh_dest = _mesh_path(case_folder, record.retainer_id, extension)

    try:
        mesh_dest.parent.mkdir(parents=True, exist_ok=True)
        if record.mesh_path.resolve() != mesh_dest.resolve():
            shutil.copy2(record.mesh_path, mesh_dest)
    except OSError as exc:
        logger.warning("Could not copy retainer mesh to case storage: %s", exc)

    payload = record.to_dict()
    if not mesh_dest.is_file():
        raise ValueError("Retainer mesh was not available for persistent storage.")
    payload["mesh_exists"] = True
    if mesh_dest.exists():
        payload["mesh_size_bytes"] = mesh_dest.stat().st_size
        payload["mesh_path"] = str(mesh_dest)

    try:
        with record_path.open("w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
    except OSError as exc:
        raise ValueError(f"Could not write retainer record: {exc}") from exc

    return record_path



def load_retainer_record(case_folder: Path, retainer_id: str) -> Optional[RetainerRecord]:
    """Load a retainer record from disk."""
    record_path = _retainer_key_path(case_folder, retainer_id)
    if not record_path.is_file():
        return None

    try:
        with record_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as exc:
        logger.warning("Could not read retainer record %s: %s", retainer_id, exc)
        return None

    try:
        mesh_path = Path(data["mesh_path"])
        if not mesh_path.is_absolute():
            mesh_path = (case_folder / "retainers" / mesh_path).resolve()
    except (KeyError, ValueError):
        # Legacy record without a mesh path; no mesh to load
        mesh_path = None

    try:
        return RetainerRecord(
            retainer_id=data["retainer_id"],
            case_id=data["case_id"],
            source_scan_id=data.get("source_scan_id"),
            origin=data.get("origin", "generated"),
            jaw=data["jaw"],
            generation_method=data["generation_method"],
            generation_method_version=data["generation_method_version"],
            source_metadata=data.get("source_metadata", {}),
            source_sha256=data.get("source_sha256"),
            parameters=data.get("parameters", {}),
            mesh_path=mesh_path,
            mesh_sha256=data.get("mesh_sha256"),
            file_size_bytes=data.get("file_size_bytes", 0),
            point_count=data.get("point_count", 0),
            face_count=data.get("face_count", 0),
            units=data.get("units", "unknown"),
            coordinate_system=data.get("coordinate_system", "unknown"),
            coordinate_frame_id=data.get("coordinate_frame_id", "unknown"),
            coordinate_system_evidence=data.get("coordinate_system_evidence", ""),
            anatomical_identity=data.get("anatomical_identity", "unknown"),
            created_at_utc=data.get("created_at_utc", ""),
            validated_status=data.get("validated_status", "not_validated"),
        )
    except (KeyError, TypeError, ValueError) as exc:
        logger.warning("Could not reconstruct retainer record %s: %s", retainer_id, exc)
        return None


def import_retainer_file(
    case_folder: Path,
    source_path: Path,
    jaw: str,
    units: str,
    coordinate_system: str,
    anatomical_identity: str,
    coordinate_frame_id: str = "unknown",
    coordinate_system_evidence: str = "",
    case_id: str = "",
    source_scan_id: Optional[str] = None,
    generation_method: str = "imported",
    generation_method_version: str = "0.1.0",
) -> RetainerRecord:
    """Import an external retainer STL/PLY file into a case.

    Copies the file into case storage, computes its hash, and creates a
    RetainerRecord. The original source file is never modified or deleted.
    """
    import numpy as np

    source = Path(source_path)
    if not source.is_file():
        raise ValueError(f"Retainer source file does not exist: {source}")
    if source.suffix.lower() not in {".stl", ".ply"}:
        raise ValueError(f"Unsupported retainer format: {source.suffix}. Choose STL or PLY.")

    # Validate mesh using existing pipeline
    from dental3d.validation.mesh_validation import load_and_validate_mesh
    try:
        validated = load_and_validate_mesh(source)
    except ValueError as exc:
        raise ValueError(f"Could not read the retainer file: {exc}") from exc
    mesh = validated.mesh

    mesh_dest_dir = case_folder / "retainers"
    mesh_dest_dir.mkdir(parents=True, exist_ok=True)

    mesh_sha256 = sha256_file(source)
    file_size_bytes = source.stat().st_size

    retainer_id = "RET-" + np.random.bytes(6).hex().upper()
    mesh_dest = mesh_dest_dir / f"{retainer_id}{source.suffix.lower()}"
    shutil.copy2(source, mesh_dest)

    record = RetainerRecord(
        retainer_id=retainer_id,
        case_id=case_id,
        source_scan_id=source_scan_id,
        jaw=jaw,
        origin="imported",
        generation_method=generation_method,
        generation_method_version=generation_method_version,
        source_metadata={
            "original_filename": source.name,
            "original_source_path": str(source.resolve()),
            "file_format": source.suffix.lower(),
            "imported_via": "external_file",
        },
        source_sha256=None,
        parameters={},
        mesh_path=mesh_dest,
        mesh_sha256=mesh_sha256,
        file_size_bytes=file_size_bytes,
        point_count=int(mesh.n_points),
        face_count=int(mesh.n_faces),
        units=units,
        coordinate_system=coordinate_system,
        coordinate_frame_id=coordinate_frame_id,
        coordinate_system_evidence=coordinate_system_evidence,
        anatomical_identity=anatomical_identity,
        warnings=["Imported retainer; mesh characteristics computed from loaded mesh"],
    )

    store_retainer_record(case_folder, record)
    return record


def remove_retainer_record(case_folder: Path, retainer_id: str, delete_mesh: bool = False) -> bool:
    """Remove a retainer record JSON. Optionally delete the mesh file.

    By default, the mesh file is preserved so the original source is not lost.
    """
    record_path = _retainer_key_path(case_folder, retainer_id)
    if not record_path.is_file():
        return False

    try:
        record_path.unlink()
    except OSError as exc:
        logger.warning("Could not delete retainer record %s: %s", retainer_id, exc)
        return False

    if delete_mesh:
        mesh_path = _mesh_path(case_folder, retainer_id, "stl")
        if mesh_path.is_file():
            try:
                mesh_path.unlink()
            except OSError as exc:
                logger.warning("Could not delete retainer mesh %s: %s", retainer_id, exc)

    return True
