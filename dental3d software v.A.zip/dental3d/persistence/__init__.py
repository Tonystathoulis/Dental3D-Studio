"""Local analysis-record persistence."""
