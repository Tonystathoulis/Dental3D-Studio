"""Local case-folder storage and transactional scan ingestion."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import uuid

from dental3d.domain.case_manager import DentalCase, ScanRecord, TreatmentStage, SUPPORTED_UNITS
from dental3d.domain.retainer_record import RetainerRecord
from dental3d.validation.mesh_validation import ValidatedMesh, SUPPORTED_SUFFIXES
from typing import Optional


SCHEMA_VERSION = 2
CASE_METADATA_FILENAME = "case.json"
_CASE_ID_PATTERN = re.compile(r"^[A-Za-z0-9_-]{3,64}$")
_SHA256_PATTERN = re.compile(r"^[a-f0-9]{64}$")


class CaseStoreError(ValueError):
    """A user-correctable case storage or metadata error."""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def default_cases_root() -> Path:
    local_app_data = os.environ.get("LOCALAPPDATA")
    base = Path(local_app_data) if local_app_data else Path.home() / ".local" / "share"
    return base / "Dental3DStudio" / "Cases"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_filename(name: str) -> str:
    leaf = Path(name.replace("\\", "/")).name
    leaf = re.sub(r"[^A-Za-z0-9._ -]", "_", leaf).strip(" .")
    if not leaf:
        leaf = "scan"
    return leaf[:150]


def _default_stages(created_at_utc: str) -> list[TreatmentStage]:
    """Create the mandatory endpoints without making assumptions about scans."""
    return [
        TreatmentStage(uuid.uuid4().hex, "Initial", "initial", "", None, 0, created_at_utc, created_at_utc),
        TreatmentStage(uuid.uuid4().hex, "Final", "final", "", None, 1, created_at_utc, created_at_utc),
    ]


class CaseStore:
    """Persists case metadata and managed, immutable-by-convention scan copies."""

    def __init__(self, root: str | Path):
        self.root = Path(root).expanduser()

    def create_case(self, patient_reference: str = "", description: str = "",
                    case_id: str | None = None) -> DentalCase:
        if not isinstance(patient_reference, str) or len(patient_reference) > 120:
            raise CaseStoreError("Patient references must be text and 120 characters or fewer.")
        if not isinstance(description, str) or len(description) > 2000:
            raise CaseStoreError("Case descriptions must be text and 2,000 characters or fewer.")
        self.root.mkdir(parents=True, exist_ok=True)
        if case_id is None:
            for _ in range(20):
                candidate = "CASE-" + datetime.now().strftime("%Y%m%d") + "-" + uuid.uuid4().hex[:8].upper()
                if not (self.root / candidate).exists():
                    case_id = candidate
                    break
            else:
                raise CaseStoreError("Could not allocate a unique case ID. Try again.")
        if not _CASE_ID_PATTERN.fullmatch(case_id):
            raise CaseStoreError("Case IDs may contain only letters, numbers, hyphens, and underscores (3–64 characters).")
        folder = self.root / case_id
        try:
            folder.mkdir(parents=False, exist_ok=False)
        except FileExistsError as exc:
            raise CaseStoreError(f"A case folder already exists for ID {case_id}; no files were overwritten.") from exc
        except OSError as exc:
            raise CaseStoreError(f"Could not create the case folder: {exc}") from exc
        try:
            (folder / "scans").mkdir()
            (folder / "analysis").mkdir()
            (folder / "reports").mkdir()
        except OSError as exc:
            for child in (folder / "scans", folder / "analysis", folder / "reports"):
                try:
                    child.rmdir()
                except OSError:
                    pass
            try:
                folder.rmdir()
            except OSError:
                pass
            raise CaseStoreError(f"Could not initialize the case folders: {exc}") from exc

        created = utc_now()
        case = DentalCase(case_id, patient_reference.strip(), description.strip(), created, created, folder,
                          stages=_default_stages(created))
        try:
            self._write_metadata(case)
        except Exception:
            # Only remove the directory created by this call, never an existing case.
            for child in (folder / "scans", folder / "analysis", folder / "reports"):
                try:
                    child.rmdir()
                except OSError:
                    pass
            try:
                (folder / CASE_METADATA_FILENAME).unlink(missing_ok=True)
                folder.rmdir()
            except OSError:
                pass
            raise
        return case

    def load_case(self, folder: str | Path) -> DentalCase:
        case_folder = Path(folder).expanduser()
        metadata_path = case_folder / CASE_METADATA_FILENAME
        if not case_folder.is_dir():
            raise CaseStoreError("The selected case folder does not exist or cannot be accessed.")
        if not metadata_path.is_file():
            raise CaseStoreError(f"Case metadata is missing: {metadata_path.name} was not found in this folder.")
        try:
            with metadata_path.open("r", encoding="utf-8") as stream:
                data = json.load(stream, parse_constant=lambda value: (_ for _ in ()).throw(
                    ValueError(f"Invalid numeric value {value} in case metadata.")))
        except (OSError, json.JSONDecodeError, ValueError) as exc:
            raise CaseStoreError(f"Could not read case metadata: {exc}") from exc
        return self._case_from_dict(case_folder, data)

    def save_case(self, case: DentalCase) -> None:
        if not _CASE_ID_PATTERN.fullmatch(case.case_id):
            raise CaseStoreError("The active case ID is invalid.")
        if not (case.case_folder / CASE_METADATA_FILENAME).is_file():
            raise CaseStoreError("This case no longer has a metadata file. Reopen or recreate it before saving.")
        previous_time = case.last_modified_utc
        case.last_modified_utc = utc_now()
        try:
            self._write_metadata(case)
        except OSError as exc:
            case.last_modified_utc = previous_time
            raise CaseStoreError(f"Could not save case metadata: {exc}") from exc

    def add_scan(self, case: DentalCase, validated: ValidatedMesh,
                 label: str = "", unit: str = "unknown",
                 anatomical_identity: str = "unknown", coordinate_system: str = "unknown",
                 coordinate_system_evidence: str = "", coordinate_frame_id: str = "unknown",
                 unit_evidence: str = "", stage_id: str | None = None) -> ScanRecord:
        if unit not in SUPPORTED_UNITS:
            raise CaseStoreError("Choose Unknown, mm, cm, µm, or in for the scan unit.")
        if len(label) > 120:
            raise CaseStoreError("Scan labels must be 120 characters or fewer.")
        if stage_id is not None and case.find_stage(stage_id) is None:
            raise CaseStoreError("Choose a treatment stage in the active case, or leave the scan unassigned.")
        if (not isinstance(anatomical_identity, str) or len(anatomical_identity) > 120
                or not isinstance(coordinate_system, str) or len(coordinate_system) > 120
                or not isinstance(coordinate_frame_id, str) or len(coordinate_frame_id) > 160
                or not isinstance(coordinate_system_evidence, str) or len(coordinate_system_evidence) > 500
                or not isinstance(unit_evidence, str) or len(unit_evidence) > 500):
            raise CaseStoreError("Anatomical and coordinate metadata must be text within the documented length limits.")
        source = validated.source_path
        if not source.is_file():
            raise CaseStoreError("The original scan is no longer available. Nothing was added to the case.")
        if source.stat().st_size != validated.file_size_bytes or sha256_file(source) != validated.sha256:
            raise CaseStoreError("The source file changed after validation. Re-import it so its metadata and checksum agree.")

        scans_folder = case.case_folder / "scans"
        if not scans_folder.is_dir():
            raise CaseStoreError("The case scans folder is missing. The case metadata was not changed.")
        scan_id = uuid.uuid4().hex
        safe_name = _safe_filename(source.name)
        managed_name = f"{scan_id[:10]}__{safe_name}"
        managed_path = scans_folder / managed_name
        try:
            # Exclusive creation prevents races or accidental replacement of a prior file.
            with source.open("rb") as input_stream, managed_path.open("xb") as output_stream:
                shutil.copyfileobj(input_stream, output_stream, length=1024 * 1024)
            shutil.copystat(source, managed_path)
            if managed_path.stat().st_size != validated.file_size_bytes or sha256_file(managed_path) != validated.sha256:
                raise CaseStoreError("The managed scan copy did not match its validated source; the import was rolled back.")
        except Exception as exc:
            managed_path.unlink(missing_ok=True)
            if isinstance(exc, CaseStoreError):
                raise
            raise CaseStoreError(f"Could not copy the scan into case storage: {exc}") from exc

        record = ScanRecord(
            scan_id=scan_id,
            label=label.strip(),
            original_filename=source.name,
            original_source_path=str(source.resolve()),
            managed_filename=managed_name,
            imported_at_utc=utc_now(),
            file_format=source.suffix.lower(),
            file_size_bytes=managed_path.stat().st_size,
            sha256=validated.sha256,
            point_count=validated.point_count,
            face_count=validated.face_count,
            cell_count=validated.cell_count,
            bounds=validated.bounds,
            dimensions=validated.dimensions,
            is_triangular_surface=validated.is_triangular_surface,
            unit=unit,
            unit_evidence=unit_evidence.strip(),
            validation_warnings=list(validated.warnings),
            anatomical_identity=anatomical_identity.strip() or "unknown",
            coordinate_system=coordinate_system.strip() or "unknown",
            coordinate_frame_id=coordinate_frame_id.strip() or "unknown",
            coordinate_system_evidence=coordinate_system_evidence.strip(),
            stage_id=stage_id,
        )
        previous_modified = case.last_modified_utc
        case.scans.append(record)
        case.last_modified_utc = utc_now()
        try:
            self._write_metadata(case)
        except Exception as exc:
            case.scans.remove(record)
            case.last_modified_utc = previous_modified
            managed_path.unlink(missing_ok=True)
            if isinstance(exc, CaseStoreError):
                raise
            raise CaseStoreError(f"Could not update case metadata; the scan import was rolled back: {exc}") from exc
        return record

    def create_stage(self, case: DentalCase, name: str = "Intermediate stage", description: str = "",
                     stage_date: str | None = None) -> TreatmentStage:
        if not isinstance(name, str) or not name.strip() or len(name) > 120:
            raise CaseStoreError("Stage names must be between 1 and 120 characters.")
        self._validate_stage_text(description, stage_date)
        now = utc_now()
        final = next((stage for stage in case.stages if stage.stage_type == "final"), None)
        if final is None:
            raise CaseStoreError("The case has no Final stage.")
        stage = TreatmentStage(uuid.uuid4().hex, name.strip(), "intermediate", description.strip(),
                               stage_date, final.display_order, now, now)
        for existing in case.stages:
            if existing.stage_type == "final":
                existing.display_order += 1
        case.stages.append(stage)
        self.save_case(case)
        return stage

    def update_stage(self, case: DentalCase, stage_id: str, *, name: str, description: str,
                     stage_date: str | None) -> None:
        stage = case.find_stage(stage_id)
        if stage is None:
            raise CaseStoreError("That treatment stage is not part of the active case.")
        if not isinstance(name, str) or not name.strip() or len(name) > 120:
            raise CaseStoreError("Stage names must be between 1 and 120 characters.")
        self._validate_stage_text(description, stage_date)
        stage.name, stage.description, stage.stage_date = name.strip(), description.strip(), stage_date
        stage.last_modified_utc = utc_now()
        self.save_case(case)

    def reorder_intermediate_stages(self, case: DentalCase, stage_ids: list[str]) -> None:
        intermediates = [stage for stage in case.ordered_stages() if stage.stage_type == "intermediate"]
        if set(stage_ids) != {stage.stage_id for stage in intermediates} or len(stage_ids) != len(intermediates):
            raise CaseStoreError("Provide every intermediate stage exactly once when reordering.")
        initial = next((stage for stage in case.stages if stage.stage_type == "initial"), None)
        final = next((stage for stage in case.stages if stage.stage_type == "final"), None)
        if initial is None or final is None:
            raise CaseStoreError("The case must retain Initial and Final stages.")
        initial.display_order = 0
        for order, stage_id in enumerate(stage_ids, 1):
            stage = case.find_stage(stage_id)
            stage.display_order, stage.last_modified_utc = order, utc_now()
        final.display_order = len(stage_ids) + 1
        self.save_case(case)

    def delete_stage(self, case: DentalCase, stage_id: str, *, unassign_scans: bool = False) -> None:
        stage = case.find_stage(stage_id)
        if stage is None:
            raise CaseStoreError("That treatment stage is not part of the active case.")
        if stage.stage_type != "intermediate":
            raise CaseStoreError("Initial and Final stages cannot be deleted.")
        assigned = [scan for scan in case.scans if scan.stage_id == stage_id]
        if assigned and not unassign_scans:
            raise CaseStoreError("This stage contains scans. Confirm moving them to Unassigned before deleting it.")
        for scan in assigned:
            scan.stage_id = None
        case.stages.remove(stage)
        self.reorder_intermediate_stages(case, [s.stage_id for s in case.ordered_stages()
                                                 if s.stage_type == "intermediate"])

    def assign_scan_to_stage(self, case: DentalCase, scan_id: str, stage_id: str | None) -> None:
        scan = case.find_scan(scan_id)
        if scan is None:
            raise CaseStoreError("That scan is not part of the active case.")
        if stage_id is not None and case.find_stage(stage_id) is None:
            raise CaseStoreError("That treatment stage is not part of the active case.")
        scan.stage_id = stage_id
        self.save_case(case)

    @staticmethod
    def _validate_stage_text(description: str, stage_date: str | None) -> None:
        if not isinstance(description, str) or len(description) > 2000:
            raise CaseStoreError("Stage descriptions must be 2,000 characters or fewer.")
        if stage_date is not None:
            if not isinstance(stage_date, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", stage_date):
                raise CaseStoreError("Stage dates must use YYYY-MM-DD, or be left empty.")
            try:
                datetime.fromisoformat(stage_date)
            except ValueError as exc:
                raise CaseStoreError("Stage dates must be valid calendar dates.") from exc

    def load_scan_mesh(self, case: DentalCase, scan: ScanRecord) -> ValidatedMesh:
        managed_path = case.case_folder / "scans" / scan.managed_filename
        if not managed_path.is_file():
            raise CaseStoreError("The managed scan copy is missing from case storage.")
        try:
            if managed_path.stat().st_size != scan.file_size_bytes or sha256_file(managed_path) != scan.sha256:
                raise CaseStoreError("The managed scan checksum no longer matches case metadata. The file was not displayed.")
        except OSError as exc:
            raise CaseStoreError(f"The managed scan copy cannot be read: {exc}") from exc
        try:
            validated = self._validate_scan_path(managed_path)
        except (OSError, ValueError) as exc:
            raise CaseStoreError(f"The managed scan copy is missing or invalid: {exc}") from exc
        if validated.sha256 != scan.sha256 or validated.file_size_bytes != scan.file_size_bytes:
            raise CaseStoreError("The managed scan checksum no longer matches case metadata. The file was not displayed.")
        return validated

    def remove_scan(self, case: DentalCase, scan_id: str) -> None:
        scan = case.find_scan(scan_id)
        if scan is None:
            raise CaseStoreError("That scan is not listed in the active case.")
        managed_path = case.case_folder / "scans" / scan.managed_filename
        previous_modified = case.last_modified_utc
        case.scans.remove(scan)
        case.last_modified_utc = utc_now()
        try:
            self._write_metadata(case)
        except Exception as exc:
            case.scans.append(scan)
            case.last_modified_utc = previous_modified
            raise CaseStoreError(f"Could not update the case; the scan was not removed: {exc}") from exc
        try:
            managed_path.unlink(missing_ok=True)
        except OSError as exc:
            raise CaseStoreError(f"The scan was removed from the case, but its managed copy could not be deleted: {exc}") from exc

    def update_scan_unit(self, case: DentalCase, scan_id: str, unit: str, save: bool = True) -> None:
        if unit not in SUPPORTED_UNITS:
            raise CaseStoreError("Select a supported unit or Unknown.")
        scan = case.find_scan(scan_id)
        if scan is None:
            raise CaseStoreError("That scan is not listed in the active case.")
        previous, previous_modified = scan.unit, case.last_modified_utc
        scan.unit = unit
        if save:
            case.last_modified_utc = utc_now()
            try:
                self._write_metadata(case)
            except Exception as exc:
                scan.unit, case.last_modified_utc = previous, previous_modified
                raise CaseStoreError(f"Could not save the unit selection: {exc}") from exc

    def update_scan_coordinate_metadata(
        self, case: DentalCase, scan_id: str, *, coordinate_system: str,
        coordinate_frame_id: str, coordinate_system_evidence: str, save: bool = True,
    ) -> None:
        raw_values = {
            "coordinate_system": (coordinate_system, 120),
            "coordinate_frame_id": (coordinate_frame_id, 160),
            "coordinate_system_evidence": (coordinate_system_evidence, 500),
        }
        if any(not isinstance(value, str) or len(value) > maximum
               for value, maximum in raw_values.values()):
            raise CaseStoreError("Coordinate metadata exceeds the supported text length.")
        values = {
            "coordinate_system": (coordinate_system.strip() or "unknown", 120),
            "coordinate_frame_id": (coordinate_frame_id.strip() or "unknown", 160),
            "coordinate_system_evidence": (coordinate_system_evidence.strip(), 500),
        }
        scan = case.find_scan(scan_id)
        if scan is None:
            raise CaseStoreError("That scan is not listed in the active case.")
        previous = {name: getattr(scan, name) for name in values}
        previous_modified = case.last_modified_utc
        for name, (value, _maximum) in values.items():
            setattr(scan, name, value)
        if save:
            case.last_modified_utc = utc_now()
            try:
                self._write_metadata(case)
            except Exception as exc:
                for name, value in previous.items():
                    setattr(scan, name, value)
                case.last_modified_utc = previous_modified
                raise CaseStoreError(f"Could not save coordinate metadata: {exc}") from exc

    def _write_metadata(self, case: DentalCase) -> None:
        case.case_folder.mkdir(parents=True, exist_ok=True)
        temp = case.case_folder / f".{CASE_METADATA_FILENAME}.{uuid.uuid4().hex}.tmp"
        data = {
            "schema_version": SCHEMA_VERSION,
            "case_id": case.case_id,
            "patient_reference": case.patient_reference,
            "description": case.description,
            "created_at_utc": case.created_at_utc,
            "last_modified_utc": case.last_modified_utc,
            "scans": [self._scan_to_dict(scan) for scan in case.scans],
            "stages": [self._stage_to_dict(stage) for stage in case.ordered_stages()],
        }
        try:
            with temp.open("x", encoding="utf-8") as stream:
                json.dump(data, stream, indent=2, ensure_ascii=False, allow_nan=False)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, case.case_folder / CASE_METADATA_FILENAME)
        finally:
            temp.unlink(missing_ok=True)

    def _case_from_dict(self, folder: Path, data: object) -> DentalCase:
        if not isinstance(data, dict):
            raise CaseStoreError("Case metadata must contain a JSON object.")
        required = {"schema_version", "case_id", "patient_reference", "description",
                    "created_at_utc", "last_modified_utc", "scans"}
        if not required.issubset(data):
            missing = ", ".join(sorted(required - set(data)))
            raise CaseStoreError(f"Case metadata is incomplete. Missing fields: {missing}.")
        if data["schema_version"] not in {1, SCHEMA_VERSION}:
            raise CaseStoreError(f"Unsupported case metadata schema version: {data['schema_version']!r}.")
        case_id = data["case_id"]
        if not isinstance(case_id, str) or not _CASE_ID_PATTERN.fullmatch(case_id):
            raise CaseStoreError("Case metadata contains an invalid case ID.")
        if folder.name != case_id:
            raise CaseStoreError(f"This folder is named {folder.name!r}, but its metadata identifies case {case_id!r}.")
        for field_name in ("patient_reference", "description", "created_at_utc", "last_modified_utc"):
            if not isinstance(data[field_name], str):
                raise CaseStoreError(f"Case metadata field {field_name!r} must be text.")
        if len(data["patient_reference"]) > 120 or len(data["description"]) > 2000:
            raise CaseStoreError("Case metadata contains an overlong patient reference or description.")
        try:
            created = datetime.fromisoformat(data["created_at_utc"])
            modified = datetime.fromisoformat(data["last_modified_utc"])
        except ValueError as exc:
            raise CaseStoreError("Case metadata contains an invalid creation or modification timestamp.") from exc
        if created.tzinfo is None or modified.tzinfo is None or modified < created:
            raise CaseStoreError("Case metadata timestamps must be ordered and include a timezone.")
        if not isinstance(data["scans"], list):
            raise CaseStoreError("Case metadata field 'scans' must be a list.")
        scans = [self._scan_from_dict(raw) for raw in data["scans"]]
        if len({scan.scan_id for scan in scans}) != len(scans):
            raise CaseStoreError("Case metadata contains duplicate scan IDs.")
        if len({scan.managed_filename for scan in scans}) != len(scans):
            raise CaseStoreError("Case metadata points multiple scans at the same managed file.")
        # Schema 1 deliberately had no stage semantics.  Preserve every scan unassigned;
        # saving this case migrates it to schema 2 with the mandatory endpoints.
        raw_stages = data.get("stages") if data["schema_version"] == SCHEMA_VERSION else None
        stages = _default_stages(data["created_at_utc"]) if raw_stages is None else [self._stage_from_dict(raw) for raw in raw_stages]
        if len({stage.stage_id for stage in stages}) != len(stages):
            raise CaseStoreError("Case metadata contains duplicate treatment-stage IDs.")
        if sum(stage.stage_type == "initial" for stage in stages) != 1 or sum(stage.stage_type == "final" for stage in stages) != 1:
            raise CaseStoreError("Case metadata must contain exactly one Initial and one Final stage.")
        ordered = sorted(stages, key=lambda stage: stage.display_order)
        if ordered[0].stage_type != "initial" or ordered[-1].stage_type != "final":
            raise CaseStoreError("Initial must be first and Final must be last in the treatment sequence.")
        stage_ids = {stage.stage_id for stage in stages}
        for scan in scans:
            if scan.stage_id is not None and scan.stage_id not in stage_ids:
                raise CaseStoreError("Case metadata assigns a scan to an unknown treatment stage.")
        return DentalCase(case_id, data["patient_reference"], data["description"],
                          data["created_at_utc"], data["last_modified_utc"], folder, scans, stages)

    @staticmethod
    def _scan_to_dict(scan: ScanRecord) -> dict:
        return {
            "scan_id": scan.scan_id,
            "label": scan.label,
            "original_filename": scan.original_filename,
            "original_source_path": scan.original_source_path,
            "managed_filename": scan.managed_filename,
            "imported_at_utc": scan.imported_at_utc,
            "file_format": scan.file_format,
            "file_size_bytes": scan.file_size_bytes,
            "sha256": scan.sha256,
            "point_count": scan.point_count,
            "face_count": scan.face_count,
            "cell_count": scan.cell_count,
            "bounds": list(scan.bounds),
            "dimensions": list(scan.dimensions),
            "is_triangular_surface": scan.is_triangular_surface,
            "unit": scan.unit,
            "unit_evidence": scan.unit_evidence,
            "validation_status": scan.validation_status,
            "validation_warnings": scan.validation_warnings,
            "anatomical_identity": scan.anatomical_identity,
            "coordinate_system": scan.coordinate_system,
            "coordinate_frame_id": scan.coordinate_frame_id,
            "coordinate_system_evidence": scan.coordinate_system_evidence,
            "stage_id": scan.stage_id,
        }

    @staticmethod
    def _stage_to_dict(stage: TreatmentStage) -> dict:
        return {"stage_id": stage.stage_id, "name": stage.name, "stage_type": stage.stage_type,
                "description": stage.description, "stage_date": stage.stage_date,
                "display_order": stage.display_order, "created_at_utc": stage.created_at_utc,
                "last_modified_utc": stage.last_modified_utc}

    @staticmethod
    def _stage_from_dict(data: object) -> TreatmentStage:
        fields = {"stage_id", "name", "stage_type", "description", "stage_date", "display_order",
                  "created_at_utc", "last_modified_utc"}
        if not isinstance(data, dict) or not fields.issubset(data):
            raise CaseStoreError("Case metadata contains an incomplete treatment-stage entry.")
        if (not isinstance(data["stage_id"], str) or not re.fullmatch(r"[0-9a-f]{32}", data["stage_id"])
                or not isinstance(data["name"], str) or not data["name"].strip() or len(data["name"]) > 120
                or data["stage_type"] not in {"initial", "intermediate", "final"}
                or not isinstance(data["description"], str) or len(data["description"]) > 2000
                or type(data["display_order"]) is not int or data["display_order"] < 0):
            raise CaseStoreError("Case metadata contains an invalid treatment-stage entry.")
        CaseStore._validate_stage_text(data["description"], data["stage_date"])
        try:
            created, modified = (datetime.fromisoformat(data[key]) for key in ("created_at_utc", "last_modified_utc"))
        except (TypeError, ValueError) as exc:
            raise CaseStoreError("Case metadata contains invalid treatment-stage timestamps.") from exc
        if created.tzinfo is None or modified.tzinfo is None or modified < created:
            raise CaseStoreError("Treatment-stage timestamps must be ordered and include a timezone.")
        return TreatmentStage(**{key: data[key] for key in fields})

    @staticmethod
    def _scan_from_dict(data: object) -> ScanRecord:
        fields = {"scan_id", "label", "original_filename", "original_source_path", "managed_filename",
                  "imported_at_utc", "file_format", "file_size_bytes", "sha256", "point_count",
                  "face_count", "cell_count", "bounds", "dimensions", "is_triangular_surface",
                  "unit", "validation_status", "validation_warnings"}
        if not isinstance(data, dict) or not fields.issubset(data):
            raise CaseStoreError("Case metadata contains an incomplete scan entry.")
        if any(not isinstance(data[key], str) for key in ("scan_id", "label", "original_filename",
              "original_source_path", "managed_filename", "imported_at_utc", "file_format", "unit", "validation_status")):
            raise CaseStoreError("Case metadata contains a scan entry with invalid text fields.")
        optional_text = {
            "anatomical_identity": (120, "unknown"),
            "coordinate_system": (120, "unknown"),
            "coordinate_frame_id": (160, "unknown"),
            "coordinate_system_evidence": (500, ""),
            "unit_evidence": (500, ""),
        }
        for key, (maximum, _default) in optional_text.items():
            value = data.get(key, _default)
            if not isinstance(value, str) or len(value) > maximum:
                raise CaseStoreError(f"Case metadata scan field {key!r} must be bounded text.")
        stage_id = data.get("stage_id")
        if stage_id is not None and (not isinstance(stage_id, str) or not re.fullmatch(r"[0-9a-f]{32}", stage_id)):
            raise CaseStoreError("Case metadata contains an invalid scan treatment-stage ID.")
        managed_filename = data["managed_filename"]
        if (Path(managed_filename).name != managed_filename or "\\" in managed_filename
                or "/" in managed_filename or not re.fullmatch(r"[A-Za-z0-9._ -]+", managed_filename)):
            raise CaseStoreError("Case metadata contains an unsafe managed scan filename.")
        if data["file_format"] not in SUPPORTED_SUFFIXES or data["unit"] not in SUPPORTED_UNITS:
            raise CaseStoreError("Case metadata contains an unsupported scan format or unit.")
        if Path(managed_filename).suffix.lower() != data["file_format"]:
            raise CaseStoreError("Case metadata scan format does not match its managed filename.")
        if not re.fullmatch(r"[a-f0-9]{32}", data["scan_id"]):
            raise CaseStoreError("Case metadata contains an invalid scan ID.")
        try:
            imported = datetime.fromisoformat(data["imported_at_utc"])
        except ValueError as exc:
            raise CaseStoreError("Case metadata contains an invalid scan import timestamp.") from exc
        if imported.tzinfo is None:
            raise CaseStoreError("Case scan import timestamp must include a timezone.")
        if not isinstance(data["sha256"], str) or not _SHA256_PATTERN.fullmatch(data["sha256"]):
            raise CaseStoreError("Case metadata contains an invalid scan checksum.")
        numeric_fields = ("file_size_bytes", "point_count", "face_count", "cell_count")
        if any(type(data[key]) is not int or data[key] < 0 for key in numeric_fields):
            raise CaseStoreError("Case metadata contains invalid scan counts.")
        if data["file_size_bytes"] == 0 or data["point_count"] < 3 or data["face_count"] == 0:
            raise CaseStoreError("Case metadata describes an empty or unusable scan.")
        bounds, dimensions = data["bounds"], data["dimensions"]
        if (not isinstance(bounds, list) or len(bounds) != 6
                or not isinstance(dimensions, list) or len(dimensions) != 3):
            raise CaseStoreError("Case metadata contains invalid scan bounds or dimensions.")
        try:
            bounds_tuple = tuple(float(value) for value in bounds)
            dimensions_tuple = tuple(float(value) for value in dimensions)
        except (TypeError, ValueError) as exc:
            raise CaseStoreError("Case metadata contains non-numeric scan bounds or dimensions.") from exc
        import math
        if not all(math.isfinite(v) for v in bounds_tuple + dimensions_tuple):
            raise CaseStoreError("Case metadata contains non-finite scan bounds or dimensions.")
        if any(value <= 0 for value in dimensions_tuple):
            raise CaseStoreError("Case metadata contains zero-size scan dimensions.")
        expected_dimensions = (bounds_tuple[1] - bounds_tuple[0], bounds_tuple[3] - bounds_tuple[2],
                               bounds_tuple[5] - bounds_tuple[4])
        if any(abs(a - b) > max(1e-9, abs(b) * 1e-9) for a, b in zip(dimensions_tuple, expected_dimensions)):
            raise CaseStoreError("Case metadata scan dimensions do not match its coordinate bounds.")
        if type(data["is_triangular_surface"]) is not bool:
            raise CaseStoreError("Case metadata contains an invalid triangular-surface flag.")
        if not isinstance(data["validation_warnings"], list) or any(not isinstance(w, str) for w in data["validation_warnings"]):
            raise CaseStoreError("Case metadata contains invalid validation warnings.")
        return ScanRecord(
            scan_id=data["scan_id"], label=data["label"], original_filename=data["original_filename"],
            original_source_path=data["original_source_path"], managed_filename=managed_filename,
            imported_at_utc=data["imported_at_utc"], file_format=data["file_format"],
            file_size_bytes=data["file_size_bytes"], sha256=data["sha256"],
            point_count=data["point_count"], face_count=data["face_count"], cell_count=data["cell_count"],
            bounds=bounds_tuple, dimensions=dimensions_tuple,
            is_triangular_surface=data["is_triangular_surface"], unit=data["unit"],
            unit_evidence=data.get("unit_evidence", ""),
            validation_status=data["validation_status"], validation_warnings=list(data["validation_warnings"]),
            anatomical_identity=data.get("anatomical_identity", "unknown"),
            coordinate_system=data.get("coordinate_system", "unknown"),
            coordinate_frame_id=data.get("coordinate_frame_id", "unknown"),
            coordinate_system_evidence=data.get("coordinate_system_evidence", ""),
            stage_id=stage_id,
        )

    @staticmethod
    def _validate_scan_path(path: Path) -> ValidatedMesh:
        # Local import avoids making the domain model depend on the validation implementation.
        from dental3d.validation.mesh_validation import load_and_validate_mesh
        return load_and_validate_mesh(path)


def list_retainer_ids(case_folder: Path) -> list[str]:
    """Return the sorted retainer IDs inside a case folder."""
    retainers_dir = case_folder / "retainers"
    if not retainers_dir.is_dir():
        return []
    return sorted(p.stem for p in retainers_dir.glob("*.json") if p.is_file())


def load_retainer_record(case_folder: Path, retainer_id: str) -> Optional[RetainerRecord]:
    from dental3d.persistence.retainer_store import load_retainer_record as _load
    return _load(case_folder, retainer_id)
