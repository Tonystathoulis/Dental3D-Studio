"""Resolve metadata only for meshes verified against the local dataset manifest."""
import json
from functools import lru_cache
from pathlib import Path

from dental3d.domain.case_manager import ScanMetadata


DEFAULT_MANIFEST = Path(__file__).resolve().parents[2] / "data" / "bits2bites_sample" / "manifest.json"


@lru_cache(maxsize=4)
def _read_manifest(path: str) -> dict | None:
    try:
        with Path(path).open("r", encoding="utf-8") as stream:
            manifest = json.load(stream)
    except (OSError, json.JSONDecodeError):
        return None
    return manifest if isinstance(manifest, dict) else None


def bits2bites_metadata_for_hash(
    sha256: str, *, manifest_path: str | Path = DEFAULT_MANIFEST,
) -> ScanMetadata | None:
    """Return documented values only when a file hash matches a manifest entry.

    The bundled sample manifest maps exact scan hashes to a Bits2Bites pair and
    arch. Arbitrary STL files and unlisted dataset pairs remain unknown.
    """
    manifest = _read_manifest(str(Path(manifest_path)))
    if manifest is None:
        return None
    dataset = manifest.get("dataset", {})
    if not isinstance(dataset, dict):
        return None
    page = dataset.get("official_page", "")
    units = dataset.get("official_documented_units")
    coordinate_system = dataset.get("official_documented_coordinate_frame")
    if units != "mm" or not isinstance(coordinate_system, str) or not coordinate_system.startswith("RAS"):
        return None
    for pair in manifest.get("pairs", []):
        if not isinstance(pair, dict):
            continue
        pair_id = str(pair.get("dataset_pair_id", "")).strip()
        if not pair_id:
            continue
        for item in pair.get("files", []):
            if not isinstance(item, dict) or sha256 not in {
                item.get("sample_sha256"), item.get("source_sha256")
            }:
                continue
            arch = item.get("arch")
            if arch not in {"upper", "lower"}:
                return None
            evidence = (
                f"SHA-256 matched to the local Bits2Bites manifest, pair {pair_id}; "
                f"dataset documentation: {page}"
            )
            return ScanMetadata(
                file_format=Path(str(item.get("sample_relative_path", "scan.stl"))).suffix.lower(),
                declared_units="mm",
                coordinate_system="RAS",
                coordinate_frame_id=f"Bits2Bites:{pair_id}:shared-RAS",
                anatomical_identity=f"{arch}_arch",
                units_evidence=evidence,
                coordinate_system_evidence=evidence,
                metadata_fields_read=True,
            )
    return None
