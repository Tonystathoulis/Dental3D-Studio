"""Input validation helpers."""
