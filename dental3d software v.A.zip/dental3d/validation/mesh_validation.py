"""Conservative structural checks for imported surface meshes."""
from dataclasses import dataclass
import hashlib
import logging
from pathlib import Path
import warnings as python_warnings
import numpy as np
import pyvista as pv
from dental3d.domain.case_manager import ScanMetadata


SUPPORTED_SUFFIXES = {".stl", ".ply"}


@dataclass(frozen=True)
class ValidatedMesh:
    mesh: pv.PolyData
    source_path: Path
    sha256: str
    file_size_bytes: int
    point_count: int
    face_count: int
    cell_count: int
    bounds: tuple[float, float, float, float, float, float]
    dimensions: tuple[float, float, float]
    is_triangular_surface: bool
    warnings: tuple[str, ...]
    metadata: ScanMetadata


def load_and_validate_mesh(path: str | Path) -> ValidatedMesh:
    """Load STL/PLY and validate basic surface integrity; never guesses units."""
    source = Path(path)
    if source.suffix.lower() not in SUPPORTED_SUFFIXES:
        raise ValueError("Unsupported scan format. Choose an STL or PLY surface mesh.")
    if not source.is_file():
        raise ValueError("The selected scan file does not exist or cannot be read.")
    try:
        file_size_bytes = source.stat().st_size
        if file_size_bytes == 0:
            raise ValueError("The selected scan file is empty.")
    except OSError as exc:
        raise ValueError(f"The selected scan file cannot be accessed: {exc}") from exc
    try:
        previous_logging_disable = logging.root.manager.disable
        with python_warnings.catch_warnings():
            python_warnings.simplefilter("ignore")
            logging.disable(logging.WARNING)
            try:
                mesh = pv.read(source)
            finally:
                logging.disable(previous_logging_disable)
    except Exception as exc:
        raise ValueError(f"Could not read the scan file: {exc}") from exc
    if not isinstance(mesh, pv.PolyData):
        raise ValueError("The selected file did not load as a surface mesh.")
    if mesh.n_points < 3 or mesh.n_cells < 1 or mesh.faces.size == 0:
        raise ValueError("The file contains no usable polygon surface.")
    points = np.asarray(mesh.points)
    if not np.isfinite(points).all():
        raise ValueError("The mesh contains non-finite coordinates and cannot be displayed safely.")
    bounds = tuple(float(x) for x in mesh.bounds)
    if len(bounds) != 6 or not np.isfinite(bounds).all():
        raise ValueError("The mesh bounds are invalid.")
    if any(bounds[i + 1] <= bounds[i] for i in (0, 2, 4)):
        raise ValueError("The mesh has a zero-size or invalid spatial dimension.")
    dimensions = (bounds[1] - bounds[0], bounds[3] - bounds[2], bounds[5] - bounds[4])
    face_count = int(mesh.n_faces)
    is_triangular = bool(mesh.is_all_triangles)
    hasher = hashlib.sha256()
    try:
        with source.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                hasher.update(chunk)
    except OSError as exc:
        raise ValueError(f"The selected scan file could not be read for its checksum: {exc}") from exc
    digest = hasher.hexdigest()
    warnings = [
        "Physical-unit metadata is not parsed; displayed dimensions remain in source coordinates.",
        "Coordinate system, scan orientation, and anatomical identity have not been verified.",
        "Checks cover basic surface presence and finite coordinates; manifoldness and clinical scan quality are not assessed.",
    ]
    if not is_triangular:
        warnings.append("The surface includes non-triangular faces; the mesh is displayed without automatic triangulation.")
    metadata = ScanMetadata(file_format=source.suffix.lower())
    return ValidatedMesh(
        mesh=mesh,
        source_path=source,
        sha256=digest,
        file_size_bytes=file_size_bytes,
        point_count=int(mesh.n_points),
        face_count=face_count,
        cell_count=int(mesh.n_cells),
        bounds=bounds,
        dimensions=dimensions,
        is_triangular_surface=is_triangular,
        warnings=tuple(warnings),
        metadata=metadata,
    )
