"""Retainer-to-dental-scan geometric comparison.

Provides basic bidirectional surface-distance analysis between a preliminary
retainer model and a dental scan. This is a geometric comparison only — it does
not establish clinical fit, retention, comfort, or clearance.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone

import numpy as np
import pyvista as pv

from dental3d.analysis.geometric_analysis import (
    ALGORITHM_VERSION,
    SurfaceDistanceResult,
    compare_surfaces,
)
from dental3d.domain.case_manager import ScanRecord


class RetainerComparisonError(ValueError):
    """A retainer comparison cannot be performed safely."""


@dataclass(frozen=True)
class RetainerComparisonRecord:
    comparison_id: str
    case_id: str
    retainer_id: str
    retainer_sha256: str
    scan_id: str
    scan_sha256: str
    jaw: str
    method_id: str
    method_version: str
    parameters: dict
    measurements: list[dict]
    units_assumptions: dict
    coordinate_assumptions: dict
    alignment_confirmed: bool
    warnings: list[str]
    spatial_deviations: dict
    created_at_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        return {
            "comparison_id": self.comparison_id,
            "case_id": self.case_id,
            "retainer_id": self.retainer_id,
            "retainer_sha256": self.retainer_sha256,
            "scan_id": self.scan_id,
            "scan_sha256": self.scan_sha256,
            "jaw": self.jaw,
            "method_id": self.method_id,
            "method_version": self.method_version,
            "parameters": self.parameters,
            "measurements": self.measurements,
            "units_assumptions": self.units_assumptions,
            "coordinate_assumptions": self.coordinate_assumptions,
            "alignment_confirmed": self.alignment_confirmed,
            "warnings": self.warnings,
            "spatial_deviations": self.spatial_deviations,
            "created_at_utc": self.created_at_utc,
        }


def check_compatibility(
    retainer_scan: object,
    dental_scan: ScanRecord,
    alignment_confirmed: bool,
) -> tuple[bool, list[str]]:
    warnings: list[str] = []

    if retainer_scan.anatomical_identity != dental_scan.anatomical_identity:
        warnings.append(
            f"Anatomical identity mismatch: retainer is {retainer_scan.anatomical_identity}, "
            f"scan is {dental_scan.anatomical_identity}"
        )

    retainer_unit = getattr(retainer_scan, "units", "unknown")
    scan_unit = dental_scan.unit
    if retainer_unit == "unknown":
        warnings.append("Retainer unit is unknown; unit compatibility cannot be verified.")
    if scan_unit == "unknown":
        warnings.append("Dental scan unit is unknown; unit compatibility cannot be verified.")
    supported_units = {"mm", "cm", "um", "in"}
    if retainer_unit not in {"unknown", *supported_units} or scan_unit not in {"unknown", *supported_units}:
        warnings.append("Retainer and scan units are not both supported for conversion.")

    if retainer_scan.coordinate_system == "unknown":
        warnings.append("Retainer coordinate system is unknown.")
    if dental_scan.coordinate_system == "unknown":
        warnings.append("Dental scan coordinate system is unknown.")
    if (
        retainer_scan.coordinate_system != "unknown"
        and dental_scan.coordinate_system != "unknown"
        and retainer_scan.coordinate_system != dental_scan.coordinate_system
    ):
        warnings.append(
            f"Coordinate system mismatch: retainer is {retainer_scan.coordinate_system}, "
            f"scan is {dental_scan.coordinate_system}"
        )
    if not getattr(retainer_scan, "coordinate_system_evidence", "").strip():
        warnings.append("Retainer coordinate-system/frame provenance is missing.")
    if not dental_scan.coordinate_system_evidence.strip():
        warnings.append("Dental scan coordinate-system/frame provenance is missing.")

    if retainer_scan.coordinate_frame_id == "unknown":
        warnings.append("Retainer coordinate frame ID is unknown.")
    if dental_scan.coordinate_frame_id == "unknown":
        warnings.append("Dental scan coordinate frame ID is unknown.")
    if (
        retainer_scan.coordinate_frame_id != "unknown"
        and dental_scan.coordinate_frame_id != "unknown"
        and retainer_scan.coordinate_frame_id != dental_scan.coordinate_frame_id
    ):
        warnings.append(
            f"Coordinate frame mismatch: retainer frame is {retainer_scan.coordinate_frame_id}, "
            f"scan frame is {dental_scan.coordinate_frame_id}. "
            "Objects belonging to the same case are not assumed aligned."
        )

    if not alignment_confirmed:
        warnings.append(
            "Alignment has not been explicitly confirmed. "
            "Do not assume objects are aligned merely because they share a case."
        )

    compatible = len(warnings) == 0
    return compatible, warnings


def compare_retainer_to_scan(
    retainer_mesh: pv.PolyData,
    dental_scan_mesh: pv.PolyData,
    retainer_record: object,
    dental_scan_record: ScanRecord,
    alignment_confirmed: bool,
) -> RetainerComparisonRecord:
    import uuid

    compatible, warnings = check_compatibility(
        retainer_record, dental_scan_record, alignment_confirmed
    )
    if not compatible:
        raise RetainerComparisonError(
            "Retainer-to-scan comparison blocked: " + "; ".join(warnings)
        )

    try:
        result: SurfaceDistanceResult = compare_surfaces(
        mesh_a=retainer_mesh,
        mesh_b=dental_scan_mesh,
        case_id=getattr(retainer_record, "case_id", "unknown"),
        scan_id_a=retainer_record.retainer_id,
        scan_id_b=dental_scan_record.scan_id,
        source_sha256_a=getattr(retainer_record, "mesh_sha256", None),
        source_sha256_b=dental_scan_record.sha256,
        unit_a=getattr(retainer_record, "units", "unknown"),
        unit_b=dental_scan_record.unit,
        coordinate_system_a=getattr(retainer_record, "coordinate_system", "unknown"),
        coordinate_system_b=dental_scan_record.coordinate_system,
        coordinate_frame_id_a=getattr(retainer_record, "coordinate_frame_id", "unknown"),
        coordinate_frame_id_b=dental_scan_record.coordinate_frame_id,
        coordinate_evidence_a=getattr(retainer_record, "coordinate_system_evidence", ""),
        coordinate_evidence_b=dental_scan_record.coordinate_system_evidence,
        source_unit_a=getattr(retainer_record, "units", "unknown"),
        source_unit_b=dental_scan_record.unit,
        anatomical_identity_a=getattr(retainer_record, "anatomical_identity", "unknown"),
        anatomical_identity_b=dental_scan_record.anatomical_identity,
        user_confirmed_aligned=alignment_confirmed,
        )
    except Exception as exc:
        raise RetainerComparisonError(f"Retainer-to-scan comparison blocked: {exc}") from exc

    spatial = result.record.spatial_deviations or {}
    a_to_b = np.asarray(spatial.get("scan_a_to_b_distances_mm", []), dtype=np.float64)
    b_to_a = np.asarray(spatial.get("scan_b_to_a_distances_mm", []), dtype=np.float64)

    all_distances = np.concatenate([a_to_b, b_to_a]) if len(a_to_b) and len(b_to_a) else np.array([])

    measurements = []
    if len(all_distances) > 0:
        measurements.append({"metric": "mean_distance_mm", "value": float(np.mean(all_distances))})
        measurements.append({"metric": "median_distance_mm", "value": float(np.median(all_distances))})
        measurements.append({"metric": "rms_distance_mm", "value": float(np.sqrt(np.mean(all_distances**2)))})
        measurements.append({"metric": "p95_distance_mm", "value": float(np.percentile(all_distances, 95))})
        measurements.append({"metric": "max_distance_mm", "value": float(np.max(all_distances))})
        measurements.append({"metric": "sample_count", "value": int(len(all_distances))})

    return RetainerComparisonRecord(
        comparison_id=str(uuid.uuid4()),
        case_id=getattr(retainer_record, "case_id", "unknown"),
        retainer_id=retainer_record.retainer_id,
        retainer_sha256=getattr(retainer_record, "mesh_sha256", "unknown"),
        scan_id=dental_scan_record.scan_id,
        scan_sha256=dental_scan_record.sha256,
        jaw=dental_scan_record.anatomical_identity,
        method_id="dental3d.retainer_to_scan_bidirectional_surface_distance",
        method_version=ALGORITHM_VERSION,
        parameters={
            **result.record.parameters,
            "registration": "none; no source vertices were transformed",
            "alignment_confirmed": alignment_confirmed,
        },
        measurements=measurements,
        units_assumptions={
            **result.record.units_assumptions,
        },
        coordinate_assumptions={
            **result.record.coordinate_assumptions,
            "retainer_id": retainer_record.retainer_id,
            "retainer_origin": getattr(retainer_record, "origin", "unknown"),
        },
        alignment_confirmed=alignment_confirmed,
        warnings=[
            "Geometric comparison only — not a clinical fit assessment.",
            *(["Experimental offset-generated retainer; result is an experimental geometric comparison."]
              if getattr(retainer_record, "origin", "") == "generated" else []),
            *result.record.warnings,
        ],
        spatial_deviations=result.record.spatial_deviations,
    )
