"""In-memory case objects and active-case selection state."""
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


SUPPORTED_UNITS = {"unknown", "mm", "cm", "um", "in"}


@dataclass(frozen=True)
class ScanMetadata:
    """File-derived metadata; unavailable values are left unknown."""
    file_format: str
    declared_units: str | None = None
    coordinate_system: str | None = None
    coordinate_frame_id: str | None = None
    anatomical_identity: str | None = None
    units_evidence: str = ""
    coordinate_system_evidence: str = ""
    metadata_fields_read: bool = False


@dataclass
class ScanRecord:
    scan_id: str
    label: str
    original_filename: str
    original_source_path: str
    managed_filename: str
    imported_at_utc: str
    file_format: str
    file_size_bytes: int
    sha256: str
    point_count: int
    face_count: int
    cell_count: int
    bounds: tuple[float, float, float, float, float, float]
    dimensions: tuple[float, float, float]
    is_triangular_surface: bool
    unit: str = "unknown"
    unit_evidence: str = ""
    validation_status: str = "basic_checks_passed"
    validation_warnings: list[str] = field(default_factory=list)
    anatomical_identity: str = "unknown"
    coordinate_system: str = "unknown"
    coordinate_frame_id: str = "unknown"
    coordinate_system_evidence: str = ""
    stage_id: str | None = None


@dataclass
class TreatmentStage:
    """A lightweight persistent point in a case's treatment sequence."""
    stage_id: str
    name: str
    stage_type: str  # initial, intermediate, or final
    description: str
    stage_date: str | None
    display_order: int
    created_at_utc: str
    last_modified_utc: str


@dataclass
class DentalCase:
    case_id: str
    patient_reference: str
    description: str
    created_at_utc: str
    last_modified_utc: str
    case_folder: Path
    scans: list[ScanRecord] = field(default_factory=list)
    stages: list[TreatmentStage] = field(default_factory=list)

    def find_scan(self, scan_id: str) -> ScanRecord | None:
        return next((scan for scan in self.scans if scan.scan_id == scan_id), None)

    def find_stage(self, stage_id: str) -> TreatmentStage | None:
        return next((stage for stage in self.stages if stage.stage_id == stage_id), None)

    def ordered_stages(self) -> list[TreatmentStage]:
        return sorted(self.stages, key=lambda stage: stage.display_order)


class CaseManager:
    """Tracks the selected case without requiring patient names or a database."""

    def __init__(self) -> None:
        self.active_case: Optional[DentalCase] = None
        self.selected_scan_id: str | None = None

    @property
    def case_id(self) -> str | None:
        return self.active_case.case_id if self.active_case else None

    @property
    def has_active_case(self) -> bool:
        return self.active_case is not None

    @property
    def scan(self) -> ScanRecord | None:
        if self.active_case is None or self.selected_scan_id is None:
            return None
        return self.active_case.find_scan(self.selected_scan_id)

    @property
    def has_imported_scan(self) -> bool:
        return self.scan is not None

    @property
    def viewport_state(self) -> str:
        """Return the guidance or display state for the central viewport."""
        if self.active_case is None:
            return "no_case"
        if not self.active_case.scans:
            return "empty_case"
        if self.scan is None:
            return "scan_unselected"
        return "scan_loaded"

    def open_case(self, case: DentalCase) -> None:
        self.active_case = case
        self.selected_scan_id = None

    def close_case(self) -> None:
        self.active_case = None
        self.selected_scan_id = None

    def select_scan(self, scan_id: str | None) -> None:
        if scan_id is not None and (self.active_case is None or self.active_case.find_scan(scan_id) is None):
            raise ValueError("The selected scan is not part of the active case.")
        self.selected_scan_id = scan_id
