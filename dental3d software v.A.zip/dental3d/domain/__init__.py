"""Application domain state."""
