"""Thin-shell retainer record for preliminary Essix-style retainer design.

This module defines the retainer record model. It is deliberately conservative:
the generated geometry is a structural, unvalidated shell and must never be
described as a clinically validated or manufacturing-ready appliance.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import numpy as np

from dental3d.domain.case_manager import DentalCase, ScanRecord


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class RetainerRecord:
    """A preliminary clear Essix retainer design generated from a dental scan.

    Key boundaries:
    - The record describes what was generated, not what it is clinically.
    - Every record carries a disclaimer that it is not clinically validated.
    - Multiple retainer versions can coexist; saving never overwrites history.
    """

    retainer_id: str
    case_id: str
    source_scan_id: Optional[str]
    jaw: str  # "upper" or "lower"
    generation_method: str
    generation_method_version: str
    source_metadata: dict
    source_sha256: Optional[str]
    parameters: dict
    mesh_path: Path
    mesh_sha256: Optional[str]
    file_size_bytes: int
    point_count: int
    face_count: int
    units: str
    coordinate_system: str
    anatomical_identity: str
    coordinate_frame_id: str = "unknown"
    coordinate_system_evidence: str = ""
    created_at_utc: str = field(default_factory=utc_now)
    validated_status: str = "not_validated"
    warnings: list[str] = field(default_factory=list)
    origin: str = "generated"  # "generated" or "imported"

    def to_dict(self) -> dict:
        return {
            "retainer_id": self.retainer_id,
            "case_id": self.case_id,
            "source_scan_id": self.source_scan_id,
            "origin": self.origin,
            "jaw": self.jaw,
            "generation_method": self.generation_method,
            "generation_method_version": self.generation_method_version,
            "source_metadata": self.source_metadata,
            "source_sha256": self.source_sha256,
            "parameters": self.parameters,
            "mesh_path": str(self.mesh_path),
            "mesh_sha256": self.mesh_sha256,
            "file_size_bytes": self.file_size_bytes,
            "point_count": self.point_count,
            "face_count": self.face_count,
            "units": self.units,
            "coordinate_system": self.coordinate_system,
            "coordinate_frame_id": self.coordinate_frame_id,
            "coordinate_system_evidence": self.coordinate_system_evidence,
            "anatomical_identity": self.anatomical_identity,
            "created_at_utc": self.created_at_utc,
            "validated_status": self.validated_status,
            "warnings": self.warnings,
        }
