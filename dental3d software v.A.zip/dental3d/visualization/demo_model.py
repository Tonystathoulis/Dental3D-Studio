"""Procedural illustrative two-arch scene. Values are display geometry, not anatomy."""
import math
import numpy as np
import pyvista as pv


def _add_tooth(plotter, actors, jaw, idx, x, y, z, slope):
    frontness = abs(idx - 6.5)
    if frontness < 0.6: width, depth = 0.155, 0.20
    elif frontness < 1.6: width, depth = 0.16, 0.21
    elif frontness < 2.6: width, depth = 0.175, 0.23
    elif frontness < 4.4: width, depth = 0.19, 0.245
    else: width, depth = 0.21, 0.26
    crown_center = z + (0.08 if jaw == "upper" else -0.08)
    sphere = pv.Sphere(theta_resolution=36, phi_resolution=28, radius=1.0)
    points = sphere.points.copy()
    zshape = np.sign(points[:, 2]) * np.abs(points[:, 2]) ** 0.78
    points[:, 0] *= width
    points[:, 1] *= depth
    points[:, 2] = zshape * 0.29
    if frontness >= 2.6:
        xx, yy = points[:, 0] / width, points[:, 1] / depth
        cusp_relief = np.zeros(len(points))
        for cx, cy in [(-.42, -.35), (.42, -.35), (-.42, .35), (.42, .35)]:
            cusp_relief += .025 * np.exp(-((xx-cx)**2 + (yy-cy)**2) / .045)
        points[:, 2] += cusp_relief * np.maximum(points[:, 2] / .29, 0) ** 2
    radial = np.sqrt(points[:, 0]**2 + points[:, 1]**2)
    points[:, 2] *= .96 + .04 * np.cos(radial * math.pi)
    crown = pv.PolyData(points, sphere.faces)
    crown.translate((x, y, crown_center), inplace=True)
    crown.rotate_z(math.degrees(math.atan(slope)), point=(x, y, crown_center), inplace=True)
    # Mid-tone enamel stays distinct against the application's solid white viewport.
    color = "#b4c1cf" if jaw == "upper" else "#a5b4c4"
    actors[jaw].append(plotter.add_mesh(crown, color=color, smooth_shading=True,
        specular=.3, specular_power=22, ambient=.24, diffuse=.76, show_edges=False))


def add_demo_arches(plotter):
    """Add a clearly illustrative 28-crown demo scene and return jaw actor groups."""
    actors = {"upper": [], "lower": []}
    for jaw, z in [("upper", .55), ("lower", -.55)]:
        for i in range(14):
            u = (i - 6.5) / 6.5
            x = u * 2.28
            y = -1.5 + 1.38 * abs(u)**1.65 + .06 * math.cos(i * .65)
            slope = 1.38 * 1.65 * abs(u)**.65 * (1 if u >= 0 else -1) / 2.28
            _add_tooth(plotter, actors, jaw, i, x, y, z, slope)
    for z, color in [(.48, "#c47c86"), (-.48, "#b986b8")]:
        t = np.linspace(-2.28, 2.28, 100)
        u = t / 2.28
        y = -1.5 + 1.38 * np.abs(u)**1.65 + .25
        gum = pv.Spline(np.c_[t, y, np.full_like(t, z)], 150).tube(radius=.14, n_sides=24)
        jaw = "upper" if z > 0 else "lower"
        actors[jaw].append(plotter.add_mesh(gum, color=color, smooth_shading=True,
            opacity=.95, specular=.2))
    return actors
