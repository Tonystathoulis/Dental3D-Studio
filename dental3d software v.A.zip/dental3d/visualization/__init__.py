"""3D scene construction and display helpers."""
