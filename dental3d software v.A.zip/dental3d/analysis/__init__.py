"""Analysis contracts and future geometric methods."""
