"""Reproducible mesh-characteristic and guarded surface-distance analysis."""
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
import math
from typing import Any, Optional
import uuid

import numpy as np
import pyvista as pv

from dental3d.domain.case_manager import SUPPORTED_UNITS


ANALYSIS_SCHEMA_VERSION = 2
ALGORITHM_VERSION = "0.1.0"
_UNIT_TO_MM = {"mm": 1.0, "cm": 10.0, "um": 0.001, "in": 25.4}


class AnalysisInputError(ValueError):
    """A mesh cannot support the requested calculation."""


class AnalysisPrerequisiteError(ValueError):
    """A comparison lacks required unit, identity, or coordinate evidence."""


@dataclass(frozen=True)
class AnalysisRecord:
    schema_version: int
    case_id: str
    status: str
    source_kind: str
    source_sha256: Optional[str]
    method_id: Optional[str]
    method_version: Optional[str]
    source_metadata: dict[str, Any] = field(default_factory=dict)
    parameters: dict[str, Any] = field(default_factory=dict)
    measurements: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    created_at_utc: str = ""
    analysis_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    analysis_type: str = ""
    source_scan_ids: list[str] = field(default_factory=list)
    source_sha256s: list[str] = field(default_factory=list)
    units_assumptions: dict[str, Any] = field(default_factory=dict)
    coordinate_assumptions: dict[str, Any] = field(default_factory=dict)
    alignment_status: str = "not_applicable"
    transformations: list[dict[str, Any]] = field(default_factory=list)
    spatial_deviations: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class SurfaceDistanceResult:
    record: AnalysisRecord
    scan_a_points_mm: np.ndarray
    scan_a_to_b_mm: np.ndarray
    scan_b_points_mm: np.ndarray
    scan_b_to_a_mm: np.ndarray


def create_uncomputed_record(case_id: str, source_kind: str,
                             source_sha256: Optional[str] = None,
                             warnings: Optional[list[str]] = None,
                             source_metadata: Optional[dict[str, Any]] = None) -> AnalysisRecord:
    """Create a traceable not-run record without filling it with illustrative values."""
    return AnalysisRecord(
        schema_version=ANALYSIS_SCHEMA_VERSION,
        case_id=case_id,
        status="not_calculated",
        source_kind=source_kind,
        source_sha256=source_sha256,
        method_id=None,
        method_version=None,
        analysis_type="not_calculated",
        source_metadata=dict(source_metadata or {}),
        warnings=list(warnings or []),
        created_at_utc=datetime.now(timezone.utc).isoformat(),
    )


def _unit_label(unit: str) -> str:
    return unit if unit in _UNIT_TO_MM else "source_coordinate_units (physical unit unknown)"


def _validate_surface(mesh: pv.PolyData, name: str = "Mesh") -> pv.PolyData:
    if not isinstance(mesh, pv.PolyData):
        raise AnalysisInputError(f"{name} must be a PyVista PolyData surface.")
    if mesh.n_points < 3 or mesh.n_cells < 1 or mesh.n_faces < 1:
        raise AnalysisInputError(f"{name} has no usable polygon surface.")
    points = np.asarray(mesh.points)
    if not np.isfinite(points).all():
        raise AnalysisInputError(f"{name} contains non-finite coordinates.")
    result = mesh.triangulate()
    if result.n_faces < 1 or not result.is_all_triangles:
        raise AnalysisInputError(f"{name} could not be represented as triangular surface geometry.")
    return result


def _triangle_areas(mesh: pv.PolyData) -> np.ndarray:
    faces = np.asarray(mesh.faces)
    if not faces.size or faces.size % 4:
        raise AnalysisInputError("Triangular faces could not be decoded safely.")
    cells = faces.reshape((-1, 4))
    if not np.all(cells[:, 0] == 3):
        raise AnalysisInputError("The analysis requires triangular surface faces.")
    triangle_points = np.asarray(mesh.points)[cells[:, 1:]]
    cross = np.cross(triangle_points[:, 1] - triangle_points[:, 0],
                     triangle_points[:, 2] - triangle_points[:, 0])
    return np.linalg.norm(cross, axis=1) * 0.5


def _component_count(mesh: pv.PolyData) -> int:
    connected = mesh.connectivity()
    regions = np.asarray(connected.cell_data.get("RegionId", []))
    return int(np.unique(regions).size) if regions.size else 0


def _watertight_volume(mesh: pv.PolyData) -> tuple[float | None, str]:
    # Merge only exactly coincident STL vertices in this analysis copy. Original input stays untouched.
    topology = mesh.copy(deep=True).clean(tolerance=0.0).triangulate()
    faces = np.asarray(topology.faces)
    if not faces.size or faces.size % 4:
        return None, "Not reported because the surface topology could not be checked."
    cells = faces.reshape((-1, 4))
    triangles = cells[:, 1:]
    edges = np.concatenate((triangles[:, [0, 1]], triangles[:, [1, 2]], triangles[:, [2, 0]]))
    edges.sort(axis=1)
    _, counts = np.unique(edges, axis=0, return_counts=True)
    if not np.all(counts == 2) or not bool(topology.is_manifold):
        return None, "Not reported because the surface is open or not a closed two-manifold."
    try:
        volume = abs(float(topology.volume))
    except Exception:
        return None, "Not reported because VTK could not calculate volume for this topology."
    if not math.isfinite(volume) or volume <= 0:
        return None, "Not reported because the enclosed volume was non-positive or non-finite."
    return volume, "Reported only for a closed two-manifold; assumes no self-intersections and coherent orientation."


def analyze_mesh(mesh: pv.PolyData, *, case_id: str, scan_id: str,
                 source_sha256: str | None, unit: str = "unknown",
                 source_unit: str | None = None, unit_evidence: str = "",
                 coordinate_system: str = "unknown", coordinate_evidence: str = "",
                 coordinate_frame_id: str = "unknown",
                 anatomical_identity: str = "unknown", file_format: str = "") -> AnalysisRecord:
    """Calculate reproducible structural characteristics for one surface mesh."""
    if unit not in SUPPORTED_UNITS:
        raise AnalysisInputError(f"Unsupported scan unit: {unit!r}.")
    surface = _validate_surface(mesh)
    points = np.asarray(surface.points)
    bounds = [float(value) for value in surface.bounds]
    dimensions = [bounds[i + 1] - bounds[i] for i in (0, 2, 4)]
    if not np.isfinite(bounds).all() or any(value <= 0 for value in dimensions):
        raise AnalysisInputError("Mesh bounds are non-finite or have a zero-size extent.")
    areas = _triangle_areas(surface)
    scale = max(float(max(dimensions)), 1.0)
    degenerate_count = int(np.count_nonzero(areas <= scale * scale * 1e-12))
    surface_area = float(np.sum(areas))
    if not math.isfinite(surface_area) or surface_area <= 0:
        raise AnalysisInputError("Surface area could not be calculated as a positive finite value.")
    component_count = _component_count(surface)
    volume, volume_note = _watertight_volume(surface)
    triangular_input = bool(mesh.is_all_triangles)
    unit_name = _unit_label(unit)
    area_unit = f"{unit}^2" if unit != "unknown" else "source_coordinate_units^2"
    volume_unit = f"{unit}^3" if unit != "unknown" else "source_coordinate_units^3"
    warnings = []
    if degenerate_count:
        warnings.append(f"{degenerate_count} near-zero-area triangles at a scale-relative 1e-12 area threshold.")
    if not triangular_input:
        warnings.append("Input polygons were triangulated in memory for analysis; source geometry was not modified.")
    if volume is None:
        warnings.append(volume_note)
    else:
        warnings.append("Volume is a geometric mesh property, not a clinical measurement; check surface orientation and self-intersections.")
    if unit == "unknown":
        warnings.append("Units are unknown; dimensions, area, and any volume remain in source-coordinate units.")
    measurements = [{
        "type": "mesh_characteristics",
        "values": {
            "point_count": int(mesh.n_points),
            "face_count": int(mesh.n_faces),
            "cell_count": int(mesh.n_cells),
            "triangulated_face_count": int(surface.n_faces),
            "bounds": bounds,
            "dimensions": dimensions,
            "dimension_unit": unit_name,
            "surface_area": surface_area,
            "surface_area_unit": area_unit,
            "enclosed_volume": volume,
            "volume_unit": volume_unit if volume is not None else None,
            "connected_component_count": component_count,
            "degenerate_triangle_count": degenerate_count,
            "input_is_triangular": triangular_input,
            "has_usable_triangular_surface": bool(surface.n_faces > 0 and surface.is_all_triangles),
        },
    }]
    return AnalysisRecord(
        schema_version=ANALYSIS_SCHEMA_VERSION,
        analysis_id=str(uuid.uuid4()),
        analysis_type="mesh_characteristics",
        case_id=case_id,
        status="completed",
        source_kind="imported_mesh",
        source_sha256=source_sha256,
        source_scan_ids=[scan_id] if scan_id else [],
        source_sha256s=[source_sha256] if source_sha256 else [],
        method_id="dental3d.mesh_characteristics",
        method_version=ALGORITHM_VERSION,
        source_metadata={
            "format": file_format,
            "point_count": int(mesh.n_points),
            "face_count": int(mesh.n_faces),
            "cell_count": int(mesh.n_cells),
            "bounds_source_coordinates": bounds,
            "dimensions_source_coordinates": dimensions,
            "is_triangular_surface": triangular_input,
        },
        parameters={
            "triangulation": "in-memory only; source mesh remains unchanged",
            "degenerate_area_tolerance": "triangle area <= max(mesh_extent,1)^2 * 1e-12",
            "volume_rule": "only calculate when exactly welded triangle edges each have incidence 2 and VTK reports a manifold",
        },
        measurements=measurements,
        warnings=warnings,
        created_at_utc=datetime.now(timezone.utc).isoformat(),
        units_assumptions={
            "input_unit": unit,
            "source_unit": source_unit if source_unit is not None else unit,
            "analysis_unit_override": source_unit is not None and source_unit != unit,
            "source_unit_evidence": unit_evidence,
            "analysis_unit_evidence": (
                "Explicit Scan & Analysis override; source geometry unchanged."
                if source_unit is not None and source_unit != unit
                else unit_evidence or ("unknown" if unit == "unknown" else "provided for this analysis")
            ),
            "distance_unit": unit_name,
        },
        coordinate_assumptions={
            "coordinate_system": coordinate_system or "unknown",
            "coordinate_frame_id": coordinate_frame_id or "unknown",
            "evidence": coordinate_evidence,
            "anatomical_identity": anatomical_identity or "unknown",
        },
        alignment_status="not_applicable_single_mesh",
        transformations=[],
    )


def _validate_comparison_metadata(*, unit_a: str, unit_b: str,
                                  coordinate_system_a: str, coordinate_system_b: str,
                                  coordinate_frame_id_a: str, coordinate_frame_id_b: str,
                                  coordinate_evidence_a: str, coordinate_evidence_b: str,
                                  anatomical_identity_a: str, anatomical_identity_b: str,
                                  user_confirmed_aligned: bool) -> tuple[float, float]:
    if unit_a not in _UNIT_TO_MM:
        raise AnalysisPrerequisiteError("Units are missing or unknown for Scan A.")
    if unit_b not in _UNIT_TO_MM:
        raise AnalysisPrerequisiteError("Units are missing or unknown for Scan B.")
    if (coordinate_system_a or "unknown").strip().casefold() in {"", "unknown"}:
        raise AnalysisPrerequisiteError("Coordinate-system convention is missing for Scan A.")
    if (coordinate_system_b or "unknown").strip().casefold() in {"", "unknown"}:
        raise AnalysisPrerequisiteError("Coordinate-system convention is missing for Scan B.")
    if not (coordinate_evidence_a or "").strip():
        raise AnalysisPrerequisiteError("Documented coordinate-system/frame provenance is missing for Scan A.")
    if not (coordinate_evidence_b or "").strip():
        raise AnalysisPrerequisiteError("Documented coordinate-system/frame provenance is missing for Scan B.")
    if (coordinate_frame_id_a or "unknown").strip().casefold() in {"", "unknown"}:
        raise AnalysisPrerequisiteError("Coordinate-frame identity is missing for Scan A.")
    if (coordinate_frame_id_b or "unknown").strip().casefold() in {"", "unknown"}:
        raise AnalysisPrerequisiteError("Coordinate-frame identity is missing for Scan B.")
    if coordinate_system_a.strip().casefold() != coordinate_system_b.strip().casefold():
        raise AnalysisPrerequisiteError("The scans use different coordinate-system conventions.")
    if coordinate_frame_id_a.strip().casefold() != coordinate_frame_id_b.strip().casefold():
        raise AnalysisPrerequisiteError("The scans have different or unverified coordinate frames.")
    if (anatomical_identity_a or "unknown").strip().casefold() in {"", "unknown"} or (anatomical_identity_b or "unknown").strip().casefold() in {"", "unknown"}:
        raise AnalysisPrerequisiteError("Specify the anatomical region for both meshes before comparing them.")
    if anatomical_identity_a.strip().casefold() != anatomical_identity_b.strip().casefold():
        raise AnalysisPrerequisiteError("The meshes identify different anatomy (for example upper versus lower arch); comparison is blocked.")
    if not user_confirmed_aligned:
        raise AnalysisPrerequisiteError("Alignment has not been confirmed.")
    return _UNIT_TO_MM[unit_a], _UNIT_TO_MM[unit_b]


def _sample_vertices(points: np.ndarray, maximum: int) -> np.ndarray:
    count = min(len(points), maximum)
    indices = np.linspace(0, len(points) - 1, num=count, dtype=np.int64)
    return np.asarray(points[indices], dtype=np.float64)


def _nearest_surface_distances(source_points: np.ndarray, target: pv.PolyData) -> np.ndarray:
    try:
        _, closest = target.find_closest_cell(source_points, return_closest_point=True)
    except Exception as exc:
        raise AnalysisInputError(f"Nearest-surface query failed: {exc}") from exc
    distances = np.linalg.norm(source_points - np.asarray(closest), axis=1)
    if not np.isfinite(distances).all():
        raise AnalysisInputError("Nearest-surface query produced non-finite distances.")
    return distances


def _distance_summary(distances: np.ndarray, thresholds_mm: tuple[float, ...]) -> dict[str, Any]:
    return {
        "evaluated_point_count": int(distances.size),
        "mean_mm": float(np.mean(distances)),
        "median_mm": float(np.median(distances)),
        "root_mean_square_mm": float(np.sqrt(np.mean(np.square(distances)))),
        "percentile_95_mm": float(np.percentile(distances, 95)),
        "maximum_mm": float(np.max(distances)),
        "percent_within_thresholds": {
            str(threshold): float(np.mean(distances <= threshold) * 100.0)
            for threshold in thresholds_mm
        },
    }


def compare_surfaces(mesh_a: pv.PolyData, mesh_b: pv.PolyData, *, case_id: str,
                     scan_id_a: str, scan_id_b: str,
                     source_sha256_a: str | None, source_sha256_b: str | None,
                     unit_a: str, unit_b: str,
                     coordinate_system_a: str, coordinate_system_b: str,
                     coordinate_frame_id_a: str = "unknown", coordinate_frame_id_b: str = "unknown",
                     coordinate_evidence_a: str = "", coordinate_evidence_b: str = "",
                     source_unit_a: str | None = None, source_unit_b: str | None = None,
                     unit_evidence_a: str = "", unit_evidence_b: str = "",
                     anatomical_identity_a: str, anatomical_identity_b: str,
                     user_confirmed_aligned: bool,
                     thresholds_mm: tuple[float, ...] = (0.1, 0.2, 0.5, 1.0),
                     maximum_samples_per_direction: int = 20000) -> SurfaceDistanceResult:
    """Compare same-region meshes in an explicitly shared, user-confirmed frame.

    Samples are deterministic, evenly spaced input vertices (not area-weighted samples).
    VTK finds the closest point on each target triangle. Symmetric summaries pool both
    directions' evaluated samples and therefore weight each direction by its sample count.
    """
    unit_factor_a, unit_factor_b = _validate_comparison_metadata(
        unit_a=unit_a, unit_b=unit_b,
        coordinate_system_a=coordinate_system_a, coordinate_system_b=coordinate_system_b,
        coordinate_frame_id_a=coordinate_frame_id_a, coordinate_frame_id_b=coordinate_frame_id_b,
        coordinate_evidence_a=coordinate_evidence_a, coordinate_evidence_b=coordinate_evidence_b,
        anatomical_identity_a=anatomical_identity_a, anatomical_identity_b=anatomical_identity_b,
        user_confirmed_aligned=user_confirmed_aligned,
    )
    if type(maximum_samples_per_direction) is not int or not 1 <= maximum_samples_per_direction <= 100000:
        raise AnalysisInputError("Sample limit must be an integer between 1 and 100,000 per direction.")
    if not thresholds_mm or any(not math.isfinite(float(value)) or float(value) < 0 for value in thresholds_mm):
        raise AnalysisInputError("Distance thresholds must be finite, non-negative millimeter values.")
    thresholds = tuple(sorted({float(value) for value in thresholds_mm}))
    a_surface = _validate_surface(mesh_a, "Scan A").copy(deep=True)
    b_surface = _validate_surface(mesh_b, "Scan B").copy(deep=True)
    a_surface.points = np.asarray(a_surface.points, dtype=np.float64) * unit_factor_a
    b_surface.points = np.asarray(b_surface.points, dtype=np.float64) * unit_factor_b
    if not np.isfinite(a_surface.points).all() or not np.isfinite(b_surface.points).all():
        raise AnalysisInputError("Unit conversion produced non-finite coordinates.")
    a_points = _sample_vertices(np.asarray(a_surface.points), maximum_samples_per_direction)
    b_points = _sample_vertices(np.asarray(b_surface.points), maximum_samples_per_direction)
    a_to_b = _nearest_surface_distances(a_points, b_surface)
    b_to_a = _nearest_surface_distances(b_points, a_surface)
    combined = np.concatenate((a_to_b, b_to_a))
    directional_a = _distance_summary(a_to_b, thresholds)
    directional_b = _distance_summary(b_to_a, thresholds)
    symmetric = _distance_summary(combined, thresholds)
    measurements = [{
        "type": "bidirectional_surface_distance",
        "scan_a_to_scan_b": directional_a,
        "scan_b_to_scan_a": directional_b,
        "symmetric_point_weighted": symmetric,
    }]
    warnings = [
        "This is geometric mesh-to-mesh distance, not a clinical clearance, contact, or treatment-fit measurement.",
        "Alignment is user-confirmed; the application did not register or transform either source mesh.",
        "Sampling uses evenly spaced mesh vertices, not area-weighted surface samples; directional point counts may differ.",
        "The symmetric summary concatenates both directional samples and is point-weighted by their evaluated counts.",
    ]
    record = AnalysisRecord(
        schema_version=ANALYSIS_SCHEMA_VERSION,
        case_id=case_id,
        status="completed",
        source_kind="paired_imported_meshes",
        source_sha256=source_sha256_a,
        method_id="dental3d.bidirectional_surface_distance",
        method_version=ALGORITHM_VERSION,
        source_metadata={
            "scan_a": {"scan_id": scan_id_a, "sha256": source_sha256_a},
            "scan_b": {"scan_id": scan_id_b, "sha256": source_sha256_b},
        },
        parameters={
            "sampling_strategy": "deterministic evenly spaced mesh vertices, capped per direction",
            "maximum_samples_per_direction": maximum_samples_per_direction,
            "actual_samples_scan_a": int(len(a_points)),
            "actual_samples_scan_b": int(len(b_points)),
            "distance_thresholds_mm": list(thresholds),
            "distance_definition": "Euclidean distance from each sampled source vertex to the closest point on a target triangle cell",
            "symmetric_combination": "concatenate scan A to B and scan B to A samples; point-weighted summaries",
            "registration": "none; no source vertices were transformed",
        },
        measurements=measurements,
        warnings=warnings,
        created_at_utc=datetime.now(timezone.utc).isoformat(),
        analysis_id=str(uuid.uuid4()),
        analysis_type="bidirectional_surface_distance",
        source_scan_ids=[scan_id_a, scan_id_b],
        source_sha256s=[v for v in (source_sha256_a, source_sha256_b) if v],
        units_assumptions={
            "scan_a_source_unit": source_unit_a if source_unit_a is not None else unit_a,
            "scan_b_source_unit": source_unit_b if source_unit_b is not None else unit_b,
            "scan_a_analysis_unit": unit_a,
            "scan_b_analysis_unit": unit_b,
            "scan_a_unit_override": source_unit_a is not None and source_unit_a != unit_a,
            "scan_b_unit_override": source_unit_b is not None and source_unit_b != unit_b,
            "scan_a_source_unit_evidence": unit_evidence_a,
            "scan_b_source_unit_evidence": unit_evidence_b,
            "scan_a_analysis_unit_evidence": (
                "Explicit Scan & Analysis override; source geometry unchanged."
                if source_unit_a is not None and source_unit_a != unit_a else unit_evidence_a
            ),
            "scan_b_analysis_unit_evidence": (
                "Explicit Scan & Analysis override; source geometry unchanged."
                if source_unit_b is not None and source_unit_b != unit_b else unit_evidence_b
            ),
            "comparison_distance_unit": "mm",
            "conversion": {"scan_a_to_mm": unit_factor_a, "scan_b_to_mm": unit_factor_b},
        },
        coordinate_assumptions={
            "scan_a_coordinate_system": coordinate_system_a,
            "scan_b_coordinate_system": coordinate_system_b,
            "scan_a_coordinate_frame_id": coordinate_frame_id_a,
            "scan_b_coordinate_frame_id": coordinate_frame_id_b,
            "scan_a_coordinate_evidence": coordinate_evidence_a,
            "scan_b_coordinate_evidence": coordinate_evidence_b,
            "scan_a_anatomical_identity": anatomical_identity_a,
            "scan_b_anatomical_identity": anatomical_identity_b,
            "alignment_evidence": "user explicitly confirmed same anatomical region and already-aligned shared coordinate frame",
        },
        alignment_status="user_confirmed_shared_frame; no registration performed",
        transformations=[],
        spatial_deviations={
            "coordinate_unit": "mm",
            "scan_a_sample_points_mm": a_points.tolist(),
            "scan_a_to_b_distances_mm": a_to_b.tolist(),
            "scan_b_sample_points_mm": b_points.tolist(),
            "scan_b_to_a_distances_mm": b_to_a.tolist(),
        },
    )
    return SurfaceDistanceResult(record, a_points, a_to_b, b_points, b_to_a)


def geometric_analysis_available() -> bool:
    """The first geometric-analysis capabilities are implemented."""
    return True
