"""Verify the compact Bits2Bites sample using only its destination directory."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from dental3d.analysis.geometric_analysis import (
    AnalysisPrerequisiteError, analyze_mesh, compare_surfaces,
)
from dental3d.validation.mesh_validation import load_and_validate_mesh


def digest(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def verify(sample_root: Path) -> None:
    manifest_path = sample_root / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("sample_case_count") != 10 or len(manifest.get("pairs", [])) != 10:
        raise ValueError("The sample manifest does not contain exactly 10 pairs.")
    seen = set()
    for pair in manifest["pairs"]:
        if pair["dataset_pair_id"] in seen:
            raise ValueError("The manifest contains a duplicate dataset pair identifier.")
        seen.add(pair["dataset_pair_id"])
        arches = set()
        pair_meshes = {}
        for record in pair["files"]:
            arches.add(record["arch"])
            mesh_path = sample_root / record["sample_relative_path"]
            if not mesh_path.is_file():
                raise FileNotFoundError(f"Missing sample scan: {mesh_path}")
            if digest(mesh_path) != record["source_sha256"] or digest(mesh_path) != record["sample_sha256"]:
                raise ValueError(f"Sample scan hash does not match manifest: {mesh_path}")
            mesh = load_and_validate_mesh(mesh_path)
            if mesh.point_count != record["point_count"] or mesh.face_count != record["face_count"]:
                raise ValueError(f"Mesh characteristics differ from manifest: {mesh_path}")
            if mesh.file_size_bytes != record["size_bytes"]:
                raise ValueError(f"File size differs from manifest: {mesh_path}")
            analysis = analyze_mesh(
                mesh.mesh, case_id=pair["sample_case_id"], scan_id=f"{pair['dataset_pair_id']}:{record['arch']}",
                source_sha256=record["sample_sha256"], unit="mm", coordinate_system="RAS",
                coordinate_evidence="Bits2Bites official dataset documentation (dataset-level convention)",
                anatomical_identity=record["arch"] + "_arch", file_format=".stl",
            )
            if analysis.status != "completed":
                raise ValueError(f"Mesh characteristics did not complete: {mesh_path}")
            pair_meshes[record["arch"]] = mesh.mesh
        if arches != {"upper", "lower"} or not pair.get("annotations"):
            raise ValueError(f"Pair {pair['dataset_pair_id']} has incomplete jaw or annotation metadata.")
        try:
            compare_surfaces(
                pair_meshes["upper"],
                pair_meshes["lower"],
                case_id=pair["sample_case_id"], scan_id_a=f"{pair['dataset_pair_id']}:upper",
                scan_id_b=f"{pair['dataset_pair_id']}:lower", source_sha256_a=None,
                source_sha256_b=None, unit_a="mm", unit_b="mm",
                coordinate_system_a="RAS", coordinate_system_b="RAS",
                coordinate_evidence_a="Bits2Bites official dataset documentation",
                coordinate_evidence_b="Bits2Bites official dataset documentation",
                anatomical_identity_a="upper_arch", anatomical_identity_b="lower_arch",
                user_confirmed_aligned=True,
            )
        except AnalysisPrerequisiteError:
            pass
        else:
            raise AssertionError("An upper/lower arch pair was incorrectly allowed as a same-anatomy comparison.")
    print(f"Verified {len(seen)} pairs / {len(seen) * 2} meshes and mesh-characteristics calculations.")
    print(f"Blocked {len(seen)} upper/lower comparisons because the arches are different anatomical regions.")
    print("The verification reads only the compact sample, not the original dataset.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("sample_root", type=Path)
    args = parser.parse_args()
    verify(args.sample_root.resolve())


if __name__ == "__main__":
    main()
