"""Copy a fixed, audited local Bits2Bites sample without touching its source."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil

from dental3d.validation.mesh_validation import load_and_validate_mesh
from tools.audit_bits2bites import sha256_file


SELECTED_CASES = {
    "200": "Smallest pair in the held-out validation split; useful low-complexity baseline.",
    "41": "Small, typical mesh pair that expands the low-complexity range.",
    "100": "Near-median size pair with common Normal/Normal bite annotations.",
    "20": "Larger asymmetric sagittal annotations and an Open Bite label.",
    "112": "Higher-complexity pair with asymmetric sagittal labels and Deep Bite annotation.",
    "91": "Mid-to-large pair with 23 near-zero-area triangles in its upper mesh; retained as a quality-warning fixture.",
    "141": "Large meshes and a mixed Cross Bite/Scissor Bite annotation.",
    "175": "Second-largest pair by combined file size; useful high-complexity case.",
    "27": "Largest pair by combined size, with an Inverted Bite and extensive transverse annotation.",
    "167": "Technically challenging lower arch with a broad 75.37 source-unit extent and one near-zero-area triangle.",
}


def build(dataset_root: Path, audit_path: Path, output_root: Path) -> dict:
    existing = {path.name for path in output_root.iterdir()} if output_root.exists() else set()
    if existing - {"README.md", "manifest.json", "cases"}:
        raise FileExistsError(f"Sample destination is not empty; refusing to overwrite: {output_root}")
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    audit_summary = audit["audit_summary"]
    if (audit["pair_count"] != 200 or audit["file_count"] != 400
            or audit_summary["complete_pair_count"] != 200
            or audit_summary["files_loaded_successfully"] != 400
            or audit_summary["duplicate_sha256_groups"]):
        raise ValueError("The completed audit does not describe exactly 200 pairs and 400 scan files.")
    pairs_by_id = {pair["pair_id"]: pair for pair in audit["pairs"]}
    missing = set(SELECTED_CASES) - set(pairs_by_id)
    if missing:
        raise ValueError("Selected case IDs are missing from the audit: " + ", ".join(sorted(missing)))
    output_root.mkdir(parents=True, exist_ok=True)
    cases_root = output_root / "cases"
    cases_root.mkdir(exist_ok=True)
    expected_case_dirs = {f"case_{int(case_id):03d}" for case_id in SELECTED_CASES}
    extra_case_dirs = {path.name for path in cases_root.iterdir()} - expected_case_dirs
    if extra_case_dirs:
        raise FileExistsError("Unexpected directories exist in the sample cases folder: " + ", ".join(sorted(extra_case_dirs)))
    results = []
    for pair_id, rationale in SELECTED_CASES.items():
        audited_pair = pairs_by_id[pair_id]
        if len(audited_pair["files"]) != 2 or not audited_pair["annotation_present"]:
            raise ValueError(f"Pair {pair_id} is incomplete or lacks annotations.")
        case_dir = cases_root / f"case_{int(pair_id):03d}"
        case_dir.mkdir(exist_ok=True)
        files = []
        for audited_file in audited_pair["files"]:
            source = dataset_root / Path(audited_file["relative_path"])
            destination = case_dir / f"{audited_file['arch']}.stl"
            if audited_file.get("load_status") != "loaded" or audited_file.get("warning"):
                raise ValueError(f"Source scan failed audit: {source}")
            if sha256_file(source) != audited_file["sha256"]:
                raise ValueError(f"Source scan changed since audit: {source}")
            if destination.exists():
                if sha256_file(destination) != audited_file["sha256"]:
                    raise FileExistsError(f"Existing sample file differs; refusing to overwrite: {destination}")
            else:
                shutil.copy2(source, destination)
            copied_hash = sha256_file(destination)
            if copied_hash != audited_file["sha256"]:
                raise IOError(f"Copied scan checksum differs from source: {destination}")
            validated = load_and_validate_mesh(destination)
            if (validated.point_count != audited_file["point_count"]
                    or validated.face_count != audited_file["face_count"]):
                raise ValueError(f"Copied mesh metrics differ from the audited source: {destination}")
            files.append({
                "arch": audited_file["arch"],
                "source_relative_path": audited_file["relative_path"],
                "sample_relative_path": destination.relative_to(output_root).as_posix(),
                "source_sha256": audited_file["sha256"],
                "sample_sha256": copied_hash,
                "size_bytes": destination.stat().st_size,
                "point_count": validated.point_count,
                "face_count": validated.face_count,
                "cell_count": validated.cell_count,
                "bounds_source_coordinates": list(validated.bounds),
                "dimensions_source_coordinates": list(validated.dimensions),
                "surface_area_source_units_squared": audited_file.get("surface_area"),
                "volume": None,
                "volume_note": "Not computed: these intra-oral arch scans are open surfaces; enclosed volume is not meaningful.",
                "triangular_surface": validated.is_triangular_surface,
                "degenerate_triangle_count_at_audit_tolerance": audited_file.get("degenerate_triangle_count"),
                "quality_warnings": list(audited_file.get("quality_warnings", [])),
                "application_validation_warnings": list(validated.warnings),
                "validation_status": "loaded_and_basic_validation_passed",
            })
        results.append({
            "sample_case_id": case_dir.name,
            "dataset_pair_id": pair_id,
            "dataset_split": audited_pair["split"],
            "source_pair_relative_path": f"data/{audited_pair['split']}/{pair_id}",
            "selection_rationale": rationale,
            "annotations": audited_pair["annotations"],
            "files": files,
        })

    manifest = {
        "manifest_schema_version": 1,
        "dataset": {
            "name": "Bits2Bites: Intra-oral Scans Occlusal Classification",
            "official_page": "https://ditto.ing.unimore.it/bits2bites/",
            "source_directory_at_audit": str(dataset_root.resolve()),
            "audit_date": datetime.now(timezone.utc).date().isoformat(),
            "full_dataset_pairs": audit["pair_count"],
            "full_dataset_scans": audit["file_count"],
            "official_documented_units": "mm",
            "official_documented_coordinate_frame": "RAS (Right-Anterior-Superior)",
            "scanner_brands_reported_dataset_wide": ["Carestream", "3Shape TRIOS"],
            "per_case_scanner_source": None,
            "annotation_method": "Official page reports annotation by one orthodontic specialist with five years of experience.",
            "ethics_approval_reported_by_source": "Comitato Etico di Ateneo di Ferrara, Approval No. 262/2025/Oss/UniFe",
            "license_status": "No explicit license for the scan files was found in the local download or official dataset page. The upstream GitHub MIT license appears to cover code and is not assumed to cover the scans. This local sample is excluded from version control; use only under the access terms accepted for the original download.",
            "annotations_csv_headers": audit["annotation_columns"],
            "transform_matrices": "None found in the local extracted dataset; STL headers are empty/zero-filled and carry no per-case transforms.",
        },
        "audit_summary": {
            "case_directories": 200,
            "annotation_rows": audit["annotation_rows"],
            "scan_files": audit["file_count"],
            "total_scan_bytes": audit["total_scan_bytes"],
            **audit_summary,
        },
        "sample_case_count": len(results),
        "sample_scan_count": sum(len(pair["files"]) for pair in results),
        "pairs": results,
    }
    (output_root / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset_root", type=Path)
    parser.add_argument("audit_json", type=Path)
    parser.add_argument("output_root", type=Path)
    args = parser.parse_args()
    manifest = build(args.dataset_root.resolve(), args.audit_json.resolve(), args.output_root.resolve())
    size = sum(f["size_bytes"] for p in manifest["pairs"] for f in p["files"])
    print(f"Copied {manifest['sample_case_count']} pairs / {manifest['sample_scan_count']} scans ({size:,} bytes)")
    print(f"Destination: {args.output_root.resolve()}")


if __name__ == "__main__":
    main()
