"""Audit a local Bits2Bites download without keeping more than one mesh loaded."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
import statistics
import warnings

import numpy as np
import pyvista as pv


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def mesh_summary(path: Path) -> dict:
    result = {"load_status": "failed"}
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            mesh = pv.read(path)
        if not isinstance(mesh, pv.PolyData):
            result["warning"] = f"Loaded {type(mesh).__name__}, not PolyData."
            return result
        result.update({
            "load_status": "loaded",
            "point_count": int(mesh.n_points),
            "face_count": int(mesh.n_faces),
            "cell_count": int(mesh.n_cells),
            "bounds": [float(v) for v in mesh.bounds],
            "dimensions": [float(v) for v in mesh.bounds_size],
            "surface_area": float(mesh.area) if mesh.n_faces else None,
            "triangular": bool(mesh.is_all_triangles),
        })
        points = np.asarray(mesh.points)
        if not np.isfinite(points).all():
            result["quality_warnings"] = ["Non-finite point coordinates."]
            return result
        quality = []
        faces = np.asarray(mesh.faces)
        if faces.size and mesh.is_all_triangles:
            cells = faces.reshape((-1, 4))
            tri = points[cells[:, 1:]]
            cross = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
            area = np.linalg.norm(cross, axis=1) * .5
            scale = max(float(np.max(np.asarray(mesh.bounds_size))), 1.0)
            degenerate = int(np.count_nonzero(area <= scale * scale * 1e-12))
            result["degenerate_triangle_count"] = degenerate
            if degenerate:
                quality.append(f"{degenerate} triangles have near-zero area at dataset scale.")
        else:
            result["degenerate_triangle_count"] = None
            quality.append("Non-triangle cells prevent the lightweight triangle-degeneracy check.")
        if mesh.n_points < 3 or mesh.n_cells < 1 or not faces.size:
            quality.append("No usable polygon surface.")
        if any(not np.isfinite(v) for v in result["dimensions"]) or any(v <= 0 for v in result["dimensions"]):
            quality.append("Zero-size or non-finite extent.")
        result["quality_warnings"] = quality
        # Scanner meshes are expected to be open surfaces; volume is intentionally omitted.
    except Exception as exc:  # audit must keep going if a file fails
        result["warning"] = f"{type(exc).__name__}: {exc}"
    return result


def audit(dataset_root: Path) -> dict:
    data_root = dataset_root / "data"
    annotation_path = data_root / "Annotations.csv"
    if not annotation_path.is_file():
        raise FileNotFoundError(f"Missing annotations CSV: {annotation_path}")
    with annotation_path.open("r", encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    annotations = {row.get("Patient", "").strip(): row for row in rows}
    pairs = []
    inventory = []
    for split in ("train", "val"):
        split_root = data_root / split
        for folder in sorted((p for p in split_root.iterdir() if p.is_dir()), key=lambda p: int(p.name)):
            case_id = folder.name
            case_files = sorted(p for p in folder.iterdir() if p.is_file())
            entry = {
                "pair_id": case_id,
                "split": split,
                "annotations": annotations.get(case_id),
                "annotation_present": case_id in annotations,
                "files": [],
                "pair_warnings": [],
            }
            names = {p.name.lower(): p for p in case_files}
            for label in ("upper", "lower"):
                path = names.get(label + ".stl")
                if path is None:
                    entry["pair_warnings"].append(f"Missing {label}.stl")
                    continue
                file_entry = {
                    "arch": label,
                    "relative_path": path.relative_to(dataset_root).as_posix(),
                    "size_bytes": path.stat().st_size,
                    "sha256": sha256_file(path),
                    "stl_header_hex": path.open("rb").read(80).hex(),
                }
                file_entry.update(mesh_summary(path))
                entry["files"].append(file_entry)
                inventory.append(file_entry)
            if not entry["annotation_present"]:
                entry["pair_warnings"].append("No matching annotation row.")
            unexpected = [p.name for p in case_files if p.name.lower() not in {"upper.stl", "lower.stl"}]
            if unexpected:
                entry["pair_warnings"].append("Unexpected files: " + ", ".join(unexpected))
            pairs.append(entry)
    hashes = {}
    for file in inventory:
        hashes.setdefault(file["sha256"], []).append(file["relative_path"])
    unknown_label_counts = {
        field: sum(str(row.get(field, "")).strip().casefold() == "unknown" for row in rows)
        for field in (list(rows[0]) if rows else []) if field != "Patient"
    }
    loaded_files = [file for file in inventory if file.get("load_status") == "loaded"]
    summary = {
        "complete_pair_count": sum(len(pair["files"]) == 2 for pair in pairs),
        "pairs_missing_annotation": sum(not pair["annotation_present"] for pair in pairs),
        "pairs_with_warnings": sum(bool(pair["pair_warnings"]) for pair in pairs),
        "files_loaded_successfully": len(loaded_files),
        "files_failed_to_load": len(inventory) - len(loaded_files),
        "files_with_quality_warnings": sum(bool(file.get("quality_warnings")) for file in inventory),
        "near_zero_area_triangle_count": sum(file.get("degenerate_triangle_count") or 0 for file in inventory),
        "duplicate_sha256_groups": [paths for paths in hashes.values() if len(paths) > 1],
        "stl_header_variant_count": len({file["stl_header_hex"] for file in inventory}),
        "nonzero_stl_header_count": sum(any(bytes.fromhex(file["stl_header_hex"])) for file in inventory),
        "file_size_bytes_min_median_max": [
            min(file["size_bytes"] for file in inventory),
            statistics.median(file["size_bytes"] for file in inventory),
            max(file["size_bytes"] for file in inventory),
        ],
        "point_count_min_median_max": [
            min(file["point_count"] for file in loaded_files),
            statistics.median(file["point_count"] for file in loaded_files),
            max(file["point_count"] for file in loaded_files),
        ],
        "annotation_unknown_label_counts": unknown_label_counts,
    }
    return {
        "dataset_root": str(dataset_root.resolve()),
        "annotation_columns": list(rows[0]) if rows else [],
        "annotation_rows": len(rows),
        "pair_count": len(pairs),
        "file_count": len(inventory),
        "total_scan_bytes": sum(f["size_bytes"] for f in inventory),
        "extension_counts": {".stl": len(inventory)},
        "audit_summary": summary,
        "pairs": pairs,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset_root", type=Path)
    parser.add_argument("--output", type=Path, required=True, help="Write the audit JSON outside the source dataset.")
    args = parser.parse_args()
    report = audit(args.dataset_root.resolve())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
    loaded = sum(f.get("load_status") == "loaded" for p in report["pairs"] for f in p["files"])
    failed = report["file_count"] - loaded
    print(f"Pairs: {report['pair_count']}; STL files: {report['file_count']}; loaded: {loaded}; failed: {failed}")
    print(f"Scan bytes: {report['total_scan_bytes']:,}; annotations: {report['annotation_rows']}")
    print(f"Audit written to: {args.output}")


if __name__ == "__main__":
    main()
