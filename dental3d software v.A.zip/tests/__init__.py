"""Automated tests for local data-ingestion and storage services."""
