import json
import tempfile
import unittest
from pathlib import Path

from dental3d.validation.dataset_metadata import bits2bites_metadata_for_hash


class DatasetMetadataTests(unittest.TestCase):
    def test_exact_manifest_hash_supplies_documented_pair_metadata(self):
        digest = "a" * 64
        manifest = {
            "dataset": {
                "official_page": "https://example.invalid/dataset",
                "official_documented_units": "mm",
                "official_documented_coordinate_frame": "RAS (Right-Anterior-Superior)",
            },
            "pairs": [{
                "dataset_pair_id": "fixture-22",
                "files": [{"arch": "upper", "sample_sha256": digest, "sample_relative_path": "upper.stl"}],
            }],
        }
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "manifest.json"
            path.write_text(json.dumps(manifest), encoding="utf-8")
            metadata = bits2bites_metadata_for_hash(digest, manifest_path=path)
            unknown = bits2bites_metadata_for_hash("b" * 64, manifest_path=path)
        self.assertEqual(metadata.declared_units, "mm")
        self.assertEqual(metadata.coordinate_system, "RAS")
        self.assertEqual(metadata.coordinate_frame_id, "Bits2Bites:fixture-22:shared-RAS")
        self.assertEqual(metadata.anatomical_identity, "upper_arch")
        self.assertIn("SHA-256 matched", metadata.units_evidence)
        self.assertIsNone(unknown)

    def test_incomplete_documentation_does_not_infer_metadata(self):
        digest = "c" * 64
        manifest = {
            "dataset": {"official_documented_units": "mm"},
            "pairs": [{"dataset_pair_id": "fixture", "files": [{"arch": "lower", "sample_sha256": digest}]}],
        }
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "manifest.json"
            path.write_text(json.dumps(manifest), encoding="utf-8")
            metadata = bits2bites_metadata_for_hash(digest, manifest_path=path)
        self.assertIsNone(metadata)


if __name__ == "__main__":
    unittest.main()
