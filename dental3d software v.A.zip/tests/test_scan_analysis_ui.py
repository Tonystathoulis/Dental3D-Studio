import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pyvista as pv
from PySide6.QtWidgets import QApplication, QMessageBox

from dental3d.ui import main_window as main_window_module
from dental3d.ui.main_window import DentalStudioWindow


class ScanAnalysisUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.window = DentalStudioWindow()
        self.window.case_store.root = self.root / "cases"
        self.window.case_store.root.mkdir()
        self.case = self.window.case_store.create_case(case_id="CASE-UI-METADATA")
        source_a = self.root / "upper_scan.stl"
        source_b = self.root / "upper_scan_b.stl"
        pv.Sphere(theta_resolution=12, phi_resolution=10).triangulate().save(source_a)
        mesh_b = pv.Sphere(theta_resolution=12, phi_resolution=10).triangulate()
        mesh_b.translate((0.1, 0, 0), inplace=True)
        mesh_b.save(source_b)
        self.scan_a = self.window.case_store.add_scan(
            self.case, main_window_module.load_and_validate_mesh(source_a), label="Scan A", unit="mm",
            unit_evidence="Import dialog selection", anatomical_identity="upper_arch",
            coordinate_system="RAS", coordinate_frame_id="pair-17-shared",
            coordinate_system_evidence="Documented fixture metadata",
        )
        self.scan_b = self.window.case_store.add_scan(
            self.case, main_window_module.load_and_validate_mesh(source_b), label="Scan B", unit="cm",
            unit_evidence="Import dialog selection", anatomical_identity="upper_arch",
            coordinate_system="RAS", coordinate_frame_id="pair-17-shared",
            coordinate_system_evidence="Documented fixture metadata",
        )
        self.window.case_manager.open_case(self.case)
        self.window.case_manager.select_scan(self.scan_a.scan_id)
        self.window._display_case_scan(self.scan_a.scan_id)
        self.window.analysis_mode = "surface_distance"
        self.window._refresh_right_panel()
        # Splitter geometry updates only after Qt has laid out a visible window.
        self.window.show()
        self.app.processEvents()

    def tearDown(self):
        self.window.close()
        self.window.plotter.close()
        self.temp.cleanup()
        self.app.processEvents()

    def test_analysis_panel_shows_source_units_and_override_control_resizes(self):
        labels = [label.text() for label in self.window.right_panel.findChildren(main_window_module.QLabel)]
        self.assertTrue(any("Imported unit: mm" in text for text in labels))
        self.assertTrue(any("Scan B imported unit: cm" in text for text in labels))
        self.assertIsNotNone(self.window.unit_combo)
        self.assertIsNotNone(self.window.comparison_unit_combo)
        initial_width = self.window.unit_combo.width()
        self.window.resize(1280, 850)
        self.window.splitter.setSizes([185, 800, 215])
        self.app.processEvents()
        narrow_width = self.window.unit_combo.width()
        self.window.splitter.setSizes([245, 690, 400])
        self.app.processEvents()
        wide_width = self.window.unit_combo.width()
        self.assertGreaterEqual(narrow_width, 80)
        self.assertGreater(wide_width, narrow_width)
        self.assertGreaterEqual(initial_width, 0)
        self.assertEqual(self.window.unit_combo.currentData(), "mm")

    def test_compare_receives_the_same_metadata_shown_for_both_scans(self):
        self.window.alignment_confirmation.setChecked(True)
        self.window.comparison_unit_combo.setCurrentIndex(self.window.comparison_unit_combo.findData("cm"))
        self.window.unit_combo.setCurrentIndex(self.window.unit_combo.findData("mm"))
        original_mesh_points = self.window.imported_mesh.mesh.points.copy()
        real_compare = main_window_module.compare_surfaces
        received = {}

        def capture(*args, **kwargs):
            received.update(kwargs)
            return real_compare(*args, **kwargs)

        with patch.object(main_window_module, "compare_surfaces", side_effect=capture):
            self.window.run_selected_analysis()

        self.assertEqual(received["unit_a"], "mm")
        self.assertEqual(received["unit_b"], "cm")
        self.assertEqual(received["source_unit_a"], self.scan_a.unit)
        self.assertEqual(received["source_unit_b"], self.scan_b.unit)
        self.assertEqual(received["coordinate_system_a"], self.scan_a.coordinate_system)
        self.assertEqual(received["coordinate_frame_id_a"], self.scan_a.coordinate_frame_id)
        self.assertEqual(received["coordinate_frame_id_b"], self.scan_b.coordinate_frame_id)
        self.assertEqual(received["coordinate_evidence_b"], self.scan_b.coordinate_system_evidence)
        self.assertTrue(self.window.current_analysis_record)
        units = self.window.current_analysis_record.units_assumptions
        self.assertEqual(units["scan_a_analysis_unit"], "mm")
        self.assertEqual(units["scan_b_analysis_unit"], "cm")
        self.assertEqual(units["scan_b_source_unit"], "cm")
        self.assertEqual(self.scan_a.unit, "mm")
        self.assertEqual(self.scan_b.unit, "cm")
        import numpy as np
        np.testing.assert_array_equal(self.window.imported_mesh.mesh.points, original_mesh_points)

    def test_missing_coordinate_information_is_explained_without_guessing(self):
        self.scan_b.coordinate_system = "unknown"
        self.window._refresh_right_panel()
        self.window.alignment_confirmation.setChecked(True)
        captured = {}
        with patch.object(QMessageBox, "warning", side_effect=lambda _parent, _title, text: captured.setdefault("text", text)):
            self.window.run_selected_analysis()
        self.assertIn("Coordinate-system convention is missing for Scan B", captured["text"])
        self.assertEqual(self.scan_b.coordinate_system, "unknown")

    def test_comparison_selector_keeps_scan_ids_and_shows_stage_context(self):
        stage = self.window.case_store.create_stage(self.case, "Progress review")
        self.window.case_store.assign_scan_to_stage(self.case, self.scan_b.scan_id, stage.stage_id)
        self.window._refresh_right_panel()
        self.assertEqual(self.window.compare_scan_combo.currentData(), self.scan_b.scan_id)
        self.assertIn("Progress review", self.window.compare_scan_combo.currentText())


if __name__ == "__main__":
    unittest.main()
