import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import tempfile
import unittest
from pathlib import Path

import numpy as np
import pyvista as pv
from PySide6.QtWidgets import QApplication

from dental3d.domain.case_manager import DentalCase, ScanRecord
from dental3d.domain.retainer_record import RetainerRecord
from dental3d.persistence.retainer_store import store_retainer_record, load_retainer_record
from dental3d.retainer import (
    generate_retainer_surface,
    validate_generated_mesh,
    create_retainer_record,
    RetainerGenerationError,
)


class RetainerGenerationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.case_folder = self.root / "CASE-RETAINER"
        self.case_folder.mkdir(parents=True)
        self.case = DentalCase(
            case_id="CASE-RETAINER",
            patient_reference="P001",
            description="Test case",
            created_at_utc="2026-01-01T00:00:00+00:00",
            last_modified_utc="2026-01-01T00:00:00+00:00",
            case_folder=self.case_folder,
        )
        self.mesh_path = self.root / "upper.stl"
        pv.Sphere(theta_resolution=16, phi_resolution=12, radius=10.0).save(self.mesh_path)

    def tearDown(self):
        self.temp.cleanup()

    def test_generate_retainer_from_valid_mesh(self):
        validated = pv.read(self.mesh_path)
        shell = generate_retainer_surface(
            validated,
            jaw="upper",
            max_distance=0.8,
            min_distance=0.4,
            coverage_trim_mm=1.0,
        )
        self.assertIsNotNone(shell)
        self.assertGreater(shell.n_points, 0)
        self.assertGreater(shell.n_faces, 0)

    def test_generate_retainer_upper_and_lower(self):
        validated = pv.read(self.mesh_path)
        shell_upper = generate_retainer_surface(
            validated, jaw="upper", max_distance=0.8, min_distance=0.4, coverage_trim_mm=1.0
        )
        shell_lower = generate_retainer_surface(
            validated, jaw="lower", max_distance=0.8, min_distance=0.4, coverage_trim_mm=1.0
        )
        self.assertIsNotNone(shell_upper)
        self.assertIsNotNone(shell_lower)

    def test_invalid_jaw_raises_error(self):
        validated = pv.read(self.mesh_path)
        with self.assertRaises(RetainerGenerationError):
            generate_retainer_surface(
                validated, jaw="invalid", max_distance=0.8, min_distance=0.4, coverage_trim_mm=1.0
            )

    def test_invalid_thickness_raises_error(self):
        validated = pv.read(self.mesh_path)
        with self.assertRaises(RetainerGenerationError):
            generate_retainer_surface(
                validated, jaw="upper", max_distance=0.0, min_distance=0.0, coverage_trim_mm=1.0
            )

    def test_min_distance_greater_than_max_raises_error(self):
        validated = pv.read(self.mesh_path)
        with self.assertRaises(RetainerGenerationError):
            generate_retainer_surface(
                validated, jaw="upper", max_distance=0.1, min_distance=0.5, coverage_trim_mm=1.0
            )

    def test_generated_mesh_validity_check(self):
        validated = pv.read(self.mesh_path)
        shell = generate_retainer_surface(
            validated,
            jaw="upper",
            max_distance=0.8,
            min_distance=0.4,
            coverage_trim_mm=1.0,
        )
        valid, warnings = validate_generated_mesh(shell)
        self.assertTrue(valid)
        self.assertIsInstance(warnings, list)

    def test_create_retainer_record(self):
        validated = pv.read(self.mesh_path)
        shell = generate_retainer_surface(
            validated,
            jaw="upper",
            max_distance=0.8,
            min_distance=0.4,
            coverage_trim_mm=1.0,
        )

        scan = ScanRecord(
            scan_id="SCAN-001",
            label="Upper scan",
            original_filename="upper.stl",
            original_source_path=str(self.mesh_path),
            managed_filename="upper.stl",
            imported_at_utc="2026-01-01T00:00:00+00:00",
            file_format="stl",
            file_size_bytes=self.mesh_path.stat().st_size,
            sha256="abc123",
            point_count=shell.n_points,
            face_count=shell.n_faces,
            cell_count=shell.n_faces,
            bounds=shell.bounds,
            dimensions=(shell.bounds[1] - shell.bounds[0], shell.bounds[3] - shell.bounds[2], shell.bounds[5] - shell.bounds[4]),
            is_triangular_surface=True,
            unit="mm",
            anatomical_identity="upper_arch",
        )

        record = create_retainer_record(
            case=self.case,
            scan=scan,
            mesh_path=self.mesh_path,
            mesh_sha256="abc123",
            file_size_bytes=self.mesh_path.stat().st_size,
            point_count=shell.n_points,
            face_count=shell.n_faces,
            jaw="upper",
            parameters={"thickness": 0.8, "trim_mm": 1.0},
            warnings_list=[],
        )

        self.assertEqual(record.case_id, "CASE-RETAINER")
        self.assertEqual(record.source_scan_id, "SCAN-001")
        self.assertEqual(record.jaw, "upper")
        self.assertEqual(record.generation_method, "thin_surface_shell_offset")
        self.assertEqual(record.units, "mm")
        self.assertEqual(record.anatomical_identity, "upper_arch")

    def test_store_and_load_retainer_record(self):
        validated = pv.read(self.mesh_path)
        shell = generate_retainer_surface(
            validated,
            jaw="upper",
            max_distance=0.8,
            min_distance=0.4,
            coverage_trim_mm=1.0,
        )

        scan = ScanRecord(
            scan_id="SCAN-002",
            label="Lower scan",
            original_filename="lower.stl",
            original_source_path=str(self.mesh_path),
            managed_filename="lower.stl",
            imported_at_utc="2026-01-01T00:00:00+00:00",
            file_format="stl",
            file_size_bytes=self.mesh_path.stat().st_size,
            sha256="def456",
            point_count=shell.n_points,
            face_count=shell.n_faces,
            cell_count=shell.n_faces,
            bounds=shell.bounds,
            dimensions=(shell.bounds[1] - shell.bounds[0], shell.bounds[3] - shell.bounds[2], shell.bounds[5] - shell.bounds[4]),
            is_triangular_surface=True,
            unit="mm",
            anatomical_identity="lower_arch",
        )

        record = create_retainer_record(
            case=self.case,
            scan=scan,
            mesh_path=self.mesh_path,
            mesh_sha256="def456",
            file_size_bytes=self.mesh_path.stat().st_size,
            point_count=shell.n_points,
            face_count=shell.n_faces,
            jaw="lower",
            parameters={"thickness": 0.8, "trim_mm": 1.0},
            warnings_list=[],
        )

        saved_path = store_retainer_record(self.case_folder, record)
        self.assertTrue(saved_path.is_file())

        loaded = load_retainer_record(self.case_folder, record.retainer_id)
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded.retainer_id, record.retainer_id)
        self.assertEqual(loaded.jaw, "lower")
        self.assertEqual(loaded.source_scan_id, "SCAN-002")

    def test_multiple_retainer_versions(self):
        validated = pv.read(self.mesh_path)
        shell = generate_retainer_surface(
            validated,
            jaw="upper",
            max_distance=0.8,
            min_distance=0.4,
            coverage_trim_mm=1.0,
        )

        scan = ScanRecord(
            scan_id="SCAN-003",
            label="Upper scan",
            original_filename="upper.stl",
            original_source_path=str(self.mesh_path),
            managed_filename="upper.stl",
            imported_at_utc="2026-01-01T00:00:00+00:00",
            file_format="stl",
            file_size_bytes=self.mesh_path.stat().st_size,
            sha256="ghi789",
            point_count=shell.n_points,
            face_count=shell.n_faces,
            cell_count=shell.n_faces,
            bounds=shell.bounds,
            dimensions=(shell.bounds[1] - shell.bounds[0], shell.bounds[3] - shell.bounds[2], shell.bounds[5] - shell.bounds[4]),
            is_triangular_surface=True,
            unit="mm",
            anatomical_identity="upper_arch",
        )

        record1 = create_retainer_record(
            case=self.case,
            scan=scan,
            mesh_path=self.mesh_path,
            mesh_sha256="ghi789",
            file_size_bytes=self.mesh_path.stat().st_size,
            point_count=shell.n_points,
            face_count=shell.n_faces,
            jaw="upper",
            parameters={"thickness": 0.8, "trim_mm": 1.0},
            warnings_list=[],
        )
        record2 = create_retainer_record(
            case=self.case,
            scan=scan,
            mesh_path=self.mesh_path,
            mesh_sha256="ghi789",
            file_size_bytes=self.mesh_path.stat().st_size,
            point_count=shell.n_points,
            face_count=shell.n_faces,
            jaw="lower",
            parameters={"thickness": 0.6, "trim_mm": 0.5},
            warnings_list=[],
        )

        store_retainer_record(self.case_folder, record1)
        store_retainer_record(self.case_folder, record2)

        ids = list(Path(self.case_folder / "retainers").glob("*.json"))
        self.assertEqual(len(ids), 2)


if __name__ == "__main__":
    unittest.main()

