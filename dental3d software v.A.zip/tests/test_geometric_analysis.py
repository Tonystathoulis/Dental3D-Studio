import tempfile
import unittest
from pathlib import Path

import numpy as np
import pyvista as pv

from dental3d.analysis.geometric_analysis import (
    AnalysisInputError,
    AnalysisPrerequisiteError,
    analyze_mesh,
    compare_surfaces,
)
from dental3d.persistence.analysis_records import load_record, save_record


class GeometricAnalysisTests(unittest.TestCase):
    def compare(self, a, b, **overrides):
        parameters = {
            "case_id": "CASE-GEOMETRY",
            "scan_id_a": "a" * 32,
            "scan_id_b": "b" * 32,
            "source_sha256_a": "a" * 64,
            "source_sha256_b": "b" * 64,
            "unit_a": "mm",
            "unit_b": "mm",
            "coordinate_system_a": "RAS",
            "coordinate_system_b": "RAS",
            "coordinate_frame_id_a": "fixture-shared-frame",
            "coordinate_frame_id_b": "fixture-shared-frame",
            "coordinate_evidence_a": "Synthetic fixture convention",
            "coordinate_evidence_b": "Synthetic fixture convention",
            "anatomical_identity_a": "upper_arch",
            "anatomical_identity_b": "upper_arch",
            "user_confirmed_aligned": True,
            "thresholds_mm": (0.1, 0.2, 0.25),
            "maximum_samples_per_direction": 100,
        }
        parameters.update(overrides)
        return compare_surfaces(a, b, **parameters)

    def test_cube_characteristics_and_volume_have_known_values(self):
        result = analyze_mesh(
            pv.Cube(), case_id="CASE-CUBE", scan_id="c" * 32,
            source_sha256="c" * 64, unit="mm", coordinate_system="RAS",
        )
        values = result.measurements[0]["values"]
        self.assertEqual(result.status, "completed")
        self.assertEqual(values["dimensions"], [1.0, 1.0, 1.0])
        self.assertAlmostEqual(values["surface_area"], 6.0)
        self.assertAlmostEqual(values["enclosed_volume"], 1.0)
        self.assertEqual(values["connected_component_count"], 1)

    def test_scaled_cube_characteristics_scale_area_and_volume(self):
        cube = pv.Cube().scale((2, 2, 2), inplace=False)
        result = analyze_mesh(
            cube, case_id="CASE-SCALE", scan_id="d" * 32,
            source_sha256="d" * 64, unit="mm",
        )
        values = result.measurements[0]["values"]
        self.assertEqual(values["dimensions"], [2.0, 2.0, 2.0])
        self.assertAlmostEqual(values["surface_area"], 24.0)
        self.assertAlmostEqual(values["enclosed_volume"], 8.0)

    def test_open_surface_reports_area_but_no_enclosed_volume(self):
        open_sphere = pv.Sphere(theta_resolution=16, phi_resolution=12).clip(normal=(1, 0, 0))
        result = analyze_mesh(
            open_sphere, case_id="CASE-OPEN", scan_id="e" * 32,
            source_sha256=None, unit="unknown",
        )
        values = result.measurements[0]["values"]
        self.assertGreater(values["surface_area"], 0)
        self.assertIsNone(values["enclosed_volume"])
        self.assertEqual(values["dimension_unit"], "source_coordinate_units (physical unit unknown)")
        self.assertTrue(any("Units are unknown" in warning for warning in result.warnings))

    def test_degenerate_triangle_is_reported_without_mutating_source(self):
        base = pv.Tetrahedron()
        points = np.vstack((base.points, base.points[0]))
        faces = np.concatenate((base.faces, np.array([3, 0, 0, len(points) - 1])))
        mesh = pv.PolyData(points, faces)
        original = mesh.points.copy()
        result = analyze_mesh(mesh, case_id="CASE-DEGEN", scan_id="f" * 32, source_sha256=None)
        values = result.measurements[0]["values"]
        self.assertGreaterEqual(values["degenerate_triangle_count"], 1)
        np.testing.assert_array_equal(mesh.points, original)

    def test_empty_and_nonfinite_meshes_are_rejected(self):
        with self.assertRaises(AnalysisInputError):
            analyze_mesh(pv.PolyData(), case_id="CASE-EMPTY", scan_id="x", source_sha256=None)
        mesh = pv.Cube()
        points = mesh.points.copy()
        points[0, 0] = np.nan
        mesh.points = points
        with self.assertRaisesRegex(AnalysisInputError, "non-finite"):
            analyze_mesh(mesh, case_id="CASE-NAN", scan_id="x", source_sha256=None)

    def test_identical_surfaces_have_zero_bidirectional_distance(self):
        plane = pv.Plane(i_resolution=3, j_resolution=3).triangulate()
        result = self.compare(plane, plane.copy())
        measurement = result.record.measurements[0]
        self.assertAlmostEqual(measurement["symmetric_point_weighted"]["mean_mm"], 0.0)
        self.assertAlmostEqual(measurement["symmetric_point_weighted"]["maximum_mm"], 0.0)
        self.assertEqual(result.record.source_scan_ids, ["a" * 32, "b" * 32])
        self.assertEqual(result.record.alignment_status, "user_confirmed_shared_frame; no registration performed")
        self.assertEqual(len(result.record.spatial_deviations["scan_a_to_b_distances_mm"]), 16)

    def test_known_translation_and_threshold_percentages(self):
        plane_a = pv.Plane(i_resolution=3, j_resolution=3).triangulate()
        plane_b = plane_a.copy()
        plane_b.translate((0, 0, 0.25), inplace=True)
        result = self.compare(plane_a, plane_b)
        summary = result.record.measurements[0]["symmetric_point_weighted"]
        self.assertAlmostEqual(summary["mean_mm"], 0.25, places=7)
        self.assertAlmostEqual(summary["percentile_95_mm"], 0.25, places=7)
        self.assertAlmostEqual(summary["maximum_mm"], 0.25, places=7)
        self.assertEqual(summary["percent_within_thresholds"]["0.2"], 0.0)
        self.assertEqual(summary["percent_within_thresholds"]["0.25"], 100.0)

    def test_compatible_units_are_converted_to_millimeters(self):
        plane_mm = pv.Plane(i_resolution=2, j_resolution=2).triangulate()
        plane_cm = plane_mm.copy()
        plane_cm.points *= 0.1
        result = self.compare(plane_mm, plane_cm, unit_b="cm")
        self.assertAlmostEqual(result.record.measurements[0]["symmetric_point_weighted"]["maximum_mm"], 0.0)
        self.assertEqual(result.record.units_assumptions["comparison_distance_unit"], "mm")

    def test_unknown_units_different_regions_or_frames_and_unconfirmed_alignment_block(self):
        plane = pv.Plane(i_resolution=2, j_resolution=2).triangulate()
        invalid = [
            {"unit_a": "unknown"},
            {"coordinate_system_b": "LPS"},
            {"coordinate_evidence_b": ""},
            {"coordinate_frame_id_a": "unknown"},
            {"coordinate_frame_id_b": "fixture-other-frame"},
            {"anatomical_identity_b": "lower_arch"},
            {"user_confirmed_aligned": False},
        ]
        for override in invalid:
            with self.subTest(override=override), self.assertRaises(AnalysisPrerequisiteError):
                self.compare(plane, plane.copy(), **override)

    def test_missing_coordinate_convention_has_scan_specific_explanation(self):
        plane = pv.Plane(i_resolution=2, j_resolution=2).triangulate()
        with self.assertRaisesRegex(AnalysisPrerequisiteError, "Coordinate-system convention is missing for Scan B"):
            self.compare(plane, plane.copy(), coordinate_system_b="unknown")

    def test_analysis_unit_override_preserves_source_unit_and_records_both(self):
        original = pv.Cube()
        points = original.points.copy()
        record = analyze_mesh(
            original, case_id="CASE-OVERRIDE", scan_id="override",
            source_sha256="d" * 64, unit="cm", source_unit="mm",
            unit_evidence="Imported as documented millimeters",
        )
        np.testing.assert_array_equal(original.points, points)
        self.assertEqual(record.units_assumptions["source_unit"], "mm")
        self.assertEqual(record.units_assumptions["input_unit"], "cm")
        self.assertTrue(record.units_assumptions["analysis_unit_override"])

    def test_distance_record_saves_and_reopens_with_provenance_and_spatial_data(self):
        plane = pv.Plane(i_resolution=2, j_resolution=2).triangulate()
        record = self.compare(plane, plane.copy()).record
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "analysis.json"
            save_record(path, record)
            reopened = load_record(path)
        self.assertEqual(reopened["analysis_id"], record.analysis_id)
        self.assertEqual(reopened["status"], "completed")
        self.assertEqual(reopened["source_scan_ids"], record.source_scan_ids)
        self.assertEqual(reopened["source_sha256s"], ["a" * 64, "b" * 64])
        self.assertEqual(reopened["spatial_deviations"], record.spatial_deviations)


if __name__ == "__main__":
    unittest.main()
