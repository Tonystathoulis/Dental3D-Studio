import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import tempfile
import unittest
from pathlib import Path

import numpy as np
import pyvista as pv

from dental3d.domain.case_manager import DentalCase, ScanRecord
from dental3d.domain.retainer_comparison import (
    check_compatibility,
    compare_retainer_to_scan,
    RetainerComparisonError,
)
from dental3d.domain.retainer_record import RetainerRecord


class RetainerCompatibilityTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.mesh_a = pv.Sphere(theta_resolution=16, phi_resolution=12, radius=10.0)
        self.mesh_b = pv.Sphere(theta_resolution=16, phi_resolution=12, radius=10.0)
        self.mesh_b.translate((0.1, 0, 0), inplace=True)

        self.retainer_record = RetainerRecord(
            retainer_id="RET-001",
            case_id="CASE-001",
            source_scan_id=None,
            jaw="upper",
            origin="imported",
            generation_method="imported",
            generation_method_version="0.1.0",
            source_metadata={},
            source_sha256=None,
            parameters={},
            mesh_path=self.root / "retainer.stl",
            mesh_sha256="abc123",
            file_size_bytes=1000,
            point_count=self.mesh_a.n_points,
            face_count=self.mesh_a.n_faces,
            units="mm",
            coordinate_system="RAS",
            coordinate_frame_id="Case-001:shared-RAS",
            coordinate_system_evidence="Synthetic fixture documentation",
            anatomical_identity="upper_arch",
            created_at_utc="2026-01-01T00:00:00+00:00",
            validated_status="not_validated",
            warnings=[],
        )

        self.scan_record = ScanRecord(
            scan_id="SCAN-001",
            label="Upper scan",
            original_filename="upper.stl",
            original_source_path=str(self.root / "upper.stl"),
            managed_filename="upper.stl",
            imported_at_utc="2026-01-01T00:00:00+00:00",
            file_format="stl",
            file_size_bytes=1000,
            sha256="def456",
            point_count=self.mesh_b.n_points,
            face_count=self.mesh_b.n_faces,
            cell_count=self.mesh_b.n_faces,
            bounds=self.mesh_b.bounds,
            dimensions=(
                self.mesh_b.bounds[1] - self.mesh_b.bounds[0],
                self.mesh_b.bounds[3] - self.mesh_b.bounds[2],
                self.mesh_b.bounds[5] - self.mesh_b.bounds[4],
            ),
            is_triangular_surface=True,
            unit="mm",
            coordinate_system="RAS",
            coordinate_frame_id="Case-001:shared-RAS",
            coordinate_system_evidence="Synthetic fixture documentation",
            anatomical_identity="upper_arch",
        )

    def tearDown(self):
        self.temp.cleanup()

    def test_compatible_retainer_and_scan(self):
        compatible, warnings = check_compatibility(
            self.retainer_record, self.scan_record, alignment_confirmed=True
        )
        self.assertTrue(compatible)
        self.assertEqual(len(warnings), 0)

    def test_different_anatomy_blocked(self):
        scan = ScanRecord(**{**vars(self.scan_record), "anatomical_identity": "lower_arch"})
        compatible, warnings = check_compatibility(
            self.retainer_record, scan, alignment_confirmed=True
        )
        self.assertFalse(compatible)
        self.assertTrue(any("Anatomical identity mismatch" in w for w in warnings))

    def test_unknown_units_blocked(self):
        scan = ScanRecord(**{**vars(self.scan_record), "unit": "unknown"})
        compatible, warnings = check_compatibility(
            self.retainer_record, scan, alignment_confirmed=True
        )
        self.assertFalse(compatible)
        self.assertTrue(any("unknown" in w.lower() for w in warnings))

    def test_incompatible_units_blocked(self):
        scan = ScanRecord(**{**vars(self.scan_record), "unit": "unsupported"})
        compatible, warnings = check_compatibility(
            self.retainer_record, scan, alignment_confirmed=True
        )
        self.assertFalse(compatible)
        self.assertTrue(any("unit" in w.lower() for w in warnings))

    def test_different_coordinate_system_blocked(self):
        scan = ScanRecord(**{**vars(self.scan_record), "coordinate_system": "LPS"})
        compatible, warnings = check_compatibility(
            self.retainer_record, scan, alignment_confirmed=True
        )
        self.assertFalse(compatible)
        self.assertTrue(any("Coordinate system mismatch" in w for w in warnings))

    def test_different_frame_blocked(self):
        scan = ScanRecord(**{**vars(self.scan_record), "coordinate_frame_id": "frame-b"})
        compatible, warnings = check_compatibility(
            self.retainer_record, scan, alignment_confirmed=True
        )
        self.assertFalse(compatible)
        self.assertTrue(any("Coordinate frame mismatch" in w for w in warnings))

    def test_unconfirmed_alignment_blocked(self):
        compatible, warnings = check_compatibility(
            self.retainer_record, self.scan_record, alignment_confirmed=False
        )
        self.assertFalse(compatible)
        self.assertTrue(any("Alignment" in w for w in warnings))

    def test_compare_raises_when_incompatible(self):
        scan = ScanRecord(**{**vars(self.scan_record), "anatomical_identity": "lower_arch"})
        with self.assertRaises(RetainerComparisonError):
            compare_retainer_to_scan(
                retainer_mesh=self.mesh_a,
                dental_scan_mesh=self.mesh_b,
                retainer_record=self.retainer_record,
                dental_scan_record=scan,
                alignment_confirmed=True,
            )


class RetainerComparisonTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.mesh_a = pv.Sphere(theta_resolution=16, phi_resolution=12, radius=10.0)
        self.mesh_b = pv.Sphere(theta_resolution=16, phi_resolution=12, radius=10.0)
        self.mesh_b.translate((0.05, 0, 0), inplace=True)

        self.retainer_record = RetainerRecord(
            retainer_id="RET-001",
            case_id="CASE-001",
            source_scan_id=None,
            jaw="upper",
            origin="imported",
            generation_method="imported",
            generation_method_version="0.1.0",
            source_metadata={},
            source_sha256="abc123",
            parameters={},
            mesh_path=self.root / "retainer.stl",
            mesh_sha256="abc123",
            file_size_bytes=1000,
            point_count=self.mesh_a.n_points,
            face_count=self.mesh_a.n_faces,
            units="mm",
            coordinate_system="RAS",
            coordinate_frame_id="Case-001:shared-RAS",
            coordinate_system_evidence="Synthetic fixture documentation",
            anatomical_identity="upper_arch",
            created_at_utc="2026-01-01T00:00:00+00:00",
            validated_status="not_validated",
            warnings=[],
        )

        self.scan_record = ScanRecord(
            scan_id="SCAN-001",
            label="Upper scan",
            original_filename="upper.stl",
            original_source_path=str(self.root / "upper.stl"),
            managed_filename="upper.stl",
            imported_at_utc="2026-01-01T00:00:00+00:00",
            file_format="stl",
            file_size_bytes=1000,
            sha256="def456",
            point_count=self.mesh_b.n_points,
            face_count=self.mesh_b.n_faces,
            cell_count=self.mesh_b.n_faces,
            bounds=self.mesh_b.bounds,
            dimensions=(
                self.mesh_b.bounds[1] - self.mesh_b.bounds[0],
                self.mesh_b.bounds[3] - self.mesh_b.bounds[2],
                self.mesh_b.bounds[5] - self.mesh_b.bounds[4],
            ),
            is_triangular_surface=True,
            unit="mm",
            coordinate_system="RAS",
            coordinate_frame_id="Case-001:shared-RAS",
            coordinate_system_evidence="Synthetic fixture documentation",
            anatomical_identity="upper_arch",
        )

    def tearDown(self):
        self.temp.cleanup()

    def test_successful_comparison(self):
        result = compare_retainer_to_scan(
            retainer_mesh=self.mesh_a,
            dental_scan_mesh=self.mesh_b,
            retainer_record=self.retainer_record,
            dental_scan_record=self.scan_record,
            alignment_confirmed=True,
        )
        self.assertIsNotNone(result.comparison_id)
        self.assertEqual(result.case_id, "CASE-001")
        self.assertEqual(result.retainer_id, "RET-001")
        self.assertEqual(result.scan_id, "SCAN-001")
        self.assertEqual(result.jaw, "upper_arch")
        self.assertTrue(result.alignment_confirmed)
        self.assertGreater(len(result.measurements), 0)

    def test_comparison_has_mean_median_rms(self):
        result = compare_retainer_to_scan(
            retainer_mesh=self.mesh_a,
            dental_scan_mesh=self.mesh_b,
            retainer_record=self.retainer_record,
            dental_scan_record=self.scan_record,
            alignment_confirmed=True,
        )
        metric_names = {m["metric"] for m in result.measurements}
        self.assertIn("mean_distance_mm", metric_names)
        self.assertIn("median_distance_mm", metric_names)
        self.assertIn("rms_distance_mm", metric_names)

    def test_comparison_to_dict(self):
        result = compare_retainer_to_scan(
            retainer_mesh=self.mesh_a,
            dental_scan_mesh=self.mesh_b,
            retainer_record=self.retainer_record,
            dental_scan_record=self.scan_record,
            alignment_confirmed=True,
        )
        d = result.to_dict()
        self.assertIn("comparison_id", d)
        self.assertIn("retainer_sha256", d)
        self.assertIn("scan_sha256", d)
        self.assertIn("measurements", d)
        self.assertIn("units_assumptions", d)
        self.assertIn("coordinate_assumptions", d)
        self.assertIn("warnings", d)


if __name__ == "__main__":
    unittest.main()
