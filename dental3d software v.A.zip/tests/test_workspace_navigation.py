import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import tempfile
import unittest
from pathlib import Path

import pyvista as pv
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from dental3d.ui import main_window as ui
from dental3d.ui.main_window import DentalStudioWindow, STYLE


class WorkspaceNavigationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setStyleSheet(STYLE)

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.window = DentalStudioWindow()
        self.window.case_store.root = Path(self.temp.name) / "cases"
        self.window.case_store.root.mkdir()
        self.case = self.window.case_store.create_case(case_id="CASE-NAVIGATION")
        self.window.case_manager.open_case(self.case)
        self.window._refresh_case_controls()

    def tearDown(self):
        self.window.close()
        self.window.plotter.close()
        self.temp.cleanup()

    def test_workspaces_are_named_and_contain_the_existing_widgets(self):
        self.assertEqual([self.window.workspace_tabs.tabText(i) for i in range(2)],
                         ["Scan Simulation", "Cases & Treatment"])
        self.assertIs(self.window.workspaces.widget(0), self.window.splitter)
        self.assertIs(self.window.workspaces.widget(1), self.window.left_panel)
        self.assertIs(self.window.viewport_panel.parent(), self.window.splitter)
        self.assertIn(self.window.stages_card, self.window.left_panel.findChildren(ui.QFrame))

    def test_switching_tabs_preserves_active_case_stage_and_scan_metadata(self):
        stage = self.window.case_store.create_stage(self.case, "Progress")
        source = Path(self.temp.name) / "upper.stl"
        pv.Sphere(theta_resolution=10, phi_resolution=8).triangulate().save(source)
        scan = self.window.case_store.add_scan(
            self.case, ui.load_and_validate_mesh(source), unit="mm", anatomical_identity="upper_arch",
            coordinate_system="RAS", coordinate_frame_id="fixture", coordinate_system_evidence="fixture", stage_id=stage.stage_id)
        self.window.case_manager.select_scan(scan.scan_id)
        self.window.selected_stage_id = stage.stage_id
        original_hash, original_unit = scan.sha256, scan.unit
        self.window.workspace_tabs.setCurrentIndex(1)
        self.window.workspace_tabs.setCurrentIndex(0)
        self.assertIs(self.window.case_manager.active_case, self.case)
        self.assertEqual(self.window.case_manager.selected_scan_id, scan.scan_id)
        self.assertEqual(self.window.selected_stage_id, stage.stage_id)
        self.assertEqual(scan.stage_id, stage.stage_id)
        self.assertEqual((scan.sha256, scan.unit), (original_hash, original_unit))

    def test_logo_assets_exist_and_window_icon_loads(self):
        assets = Path(ui.__file__).resolve().parents[2] / "assets"
        for name in ("dental3d_studio_logo.svg", "dental3d_studio_logo.png", "dental3d_studio_icon.ico"):
            self.assertTrue((assets / name).is_file(), name)
        self.assertFalse(QIcon(str(assets / "dental3d_studio_icon.ico")).isNull())
        self.assertFalse(self.window.windowIcon().isNull())

    def test_popout_survives_workspace_switch(self):
        self.window._toggle_popout_window()
        popout = self.window.popout_window
        self.assertIsNotNone(popout)
        self.window.workspace_tabs.setCurrentIndex(1)
        self.window.workspace_tabs.setCurrentIndex(0)
        self.assertIs(self.window.popout_window, popout)
        popout.close()
        self.app.processEvents()

    # ---- New UI refinement tests ----

    def test_header_has_white_background(self):
        """The top header ribbon must have a white background."""
        app_style = self.app.styleSheet()
        self.assertIn("QFrame#headerBar", app_style)
        self.assertIn("background: #ffffff", app_style)

    def test_active_tab_has_white_background(self):
        """Active workspace tab must have white background matching workspace."""
        app_style = self.app.styleSheet()
        self.assertIn("workspaceTab:checked", app_style)
        self.assertIn("#ffffff", app_style)

    def test_inactive_tab_has_neutral_background(self):
        """Inactive workspace tab must have subtle neutral background."""
        app_style = self.app.styleSheet()
        self.assertIn("QPushButton#workspaceTab {", app_style)
        self.assertIn("#dce3eb", app_style)

    def test_tab_colors_swap_when_switching(self):
        """Switching tabs must swap active/inactive styling."""
        self.window.workspace_tabs.setCurrentIndex(0)
        self.assertTrue(self.window.sim_tab_button.isChecked())
        self.assertFalse(self.window.cases_tab_button.isChecked())

        self.window.workspace_tabs.setCurrentIndex(1)
        self.assertFalse(self.window.sim_tab_button.isChecked())
        self.assertTrue(self.window.cases_tab_button.isChecked())

    def test_scan_simulation_has_scan_import_and_management(self):
        """Scan & Simulation must contain scan import and scan selection controls."""
        self.assertIsNotNone(self.window.scan_combo)
        self.assertIsNotNone(self.window.import_scan_button)

    def test_scan_simulation_has_compact_case_card(self):
        """Scan & Simulation compact current-case card must exist."""
        self.assertIsNotNone(self.window.case_sim_card)
        self.assertIsNotNone(self.window.open_case_sim_button)
        self.assertIsNotNone(self.window.save_case_sim_button)
        self.assertIsNotNone(self.window.close_case_sim_button)

    def test_cases_treatment_has_case_info_and_stages_side_by_side(self):
        """Cases & Treatment must contain Case Information and Treatment Stages side by side."""
        self.assertIsNotNone(self.window.case_info_card)
        self.assertIsNotNone(self.window.stages_card)
        case_panel = self.window.case_info_card.parent()
        stages_panel = self.window.stages_card.parent()
        self.assertIsNotNone(case_panel)
        self.assertIsNotNone(stages_panel)
        self.assertIsNot(case_panel, stages_panel)

    def test_case_sim_card_only_has_three_buttons(self):
        """Compact case card in Scan & Simulation must have exactly 3 action buttons."""
        buttons = self.window.case_sim_card.findChildren(ui.QPushButton)
        button_texts = {b.text() for b in buttons}
        self.assertEqual(button_texts, {"Open Case", "Save Case", "Close Case"})

    def test_no_blue_line_across_tab_boundary(self):
        """No blue horizontal line should appear across the tab/page boundary."""
        app_style = self.app.styleSheet()
        self.assertNotIn("#4a90d9", app_style)
        self.assertNotIn("#0000ff", app_style)
        self.assertNotIn("blue", app_style.lower())

    def test_logo_svg_is_minimalist_wireframe(self):
        """Logo SVG must be minimalist wireframe (no fill, no decorative dots)."""
        assets = Path(ui.__file__).resolve().parents[2] / "assets"
        svg_content = (assets / "dental3d_studio_logo.svg").read_text(encoding="utf-8")
        self.assertIn('fill="none"', svg_content)
        self.assertNotIn('<circle', svg_content)
        self.assertIn('<path', svg_content)
        self.assertIn('stroke=', svg_content)


if __name__ == "__main__":
    unittest.main()
