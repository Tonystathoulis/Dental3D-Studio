import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import tempfile
import unittest
from pathlib import Path

import pyvista as pv

from dental3d.persistence.retainer_store import (
    import_retainer_file,
    store_retainer_record,
    load_retainer_record,
    remove_retainer_record,
)


class RetainerImportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.case_folder = self.root / "CASE-IMPORT"
        self.case_folder.mkdir(parents=True)
        self.stl_path = self.root / "retainer.stl"
        pv.Sphere(theta_resolution=16, phi_resolution=12, radius=10.0).save(self.stl_path)
        self.ply_path = self.root / "retainer.ply"
        pv.Sphere(theta_resolution=16, phi_resolution=12, radius=10.0).save(self.ply_path)
        self.invalid_path = self.root / "invalid.xyz"
        self.invalid_path.write_text("not a mesh")

    def tearDown(self):
        self.temp.cleanup()

    def test_import_stl_retainer(self):
        record = import_retainer_file(
            case_folder=self.case_folder,
            source_path=self.stl_path,
            jaw="upper",
            units="mm",
            coordinate_system="RAS",
            anatomical_identity="upper_arch",
        )
        self.assertEqual(record.jaw, "upper")
        self.assertEqual(record.origin, "imported")
        self.assertEqual(record.units, "mm")
        self.assertEqual(record.anatomical_identity, "upper_arch")
        self.assertIsNotNone(record.mesh_sha256)
        self.assertGreater(record.file_size_bytes, 0)
        self.assertTrue(record.mesh_path.is_file())

    def test_import_ply_retainer(self):
        record = import_retainer_file(
            case_folder=self.case_folder,
            source_path=self.ply_path,
            jaw="lower",
            units="mm",
            coordinate_system="RAS",
            anatomical_identity="lower_arch",
        )
        self.assertEqual(record.jaw, "lower")
        self.assertEqual(record.anatomical_identity, "lower_arch")

    def test_import_invalid_file_raises(self):
        with self.assertRaises(ValueError):
            import_retainer_file(
                case_folder=self.case_folder,
                source_path=self.invalid_path,
                jaw="upper",
                units="mm",
                coordinate_system="RAS",
                anatomical_identity="upper_arch",
            )

    def test_import_unsupported_format_raises(self):
        bad_path = self.root / "bad.txt"
        bad_path.write_text("not a mesh")
        with self.assertRaises(ValueError):
            import_retainer_file(
                case_folder=self.case_folder,
                source_path=bad_path,
                jaw="upper",
                units="mm",
                coordinate_system="RAS",
                anatomical_identity="upper_arch",
            )

    def test_import_preserves_original_source(self):
        original_size = self.stl_path.stat().st_size
        record = import_retainer_file(
            case_folder=self.case_folder,
            source_path=self.stl_path,
            jaw="upper",
            units="mm",
            coordinate_system="RAS",
            anatomical_identity="upper_arch",
        )
        self.assertEqual(self.stl_path.stat().st_size, original_size)
        self.assertTrue(self.stl_path.is_file())
        self.assertTrue(record.mesh_path.is_file())

    def test_store_and_load_imported_retainer(self):
        record = import_retainer_file(
            case_folder=self.case_folder,
            source_path=self.stl_path,
            jaw="upper",
            units="mm",
            coordinate_system="RAS",
            anatomical_identity="upper_arch",
        )
        saved_path = store_retainer_record(self.case_folder, record)
        self.assertTrue(saved_path.is_file())

        loaded = load_retainer_record(self.case_folder, record.retainer_id)
        self.assertIsNotNone(loaded)
        self.assertEqual(loaded.retainer_id, record.retainer_id)
        self.assertEqual(loaded.jaw, "upper")
        self.assertEqual(loaded.origin, "imported")

    def test_remove_retainer_record_preserves_mesh(self):
        record = import_retainer_file(
            case_folder=self.case_folder,
            source_path=self.stl_path,
            jaw="upper",
            units="mm",
            coordinate_system="RAS",
            anatomical_identity="upper_arch",
        )
        mesh_path = record.mesh_path
        self.assertTrue(mesh_path.is_file())

        result = remove_retainer_record(self.case_folder, record.retainer_id, delete_mesh=False)
        self.assertTrue(result)
        self.assertTrue(mesh_path.is_file())
        loaded = load_retainer_record(self.case_folder, record.retainer_id)
        self.assertIsNone(loaded)

    def test_multiple_retainer_versions(self):
        record1 = import_retainer_file(
            case_folder=self.case_folder,
            source_path=self.stl_path,
            jaw="upper",
            units="mm",
            coordinate_system="RAS",
            anatomical_identity="upper_arch",
        )
        record2 = import_retainer_file(
            case_folder=self.case_folder,
            source_path=self.ply_path,
            jaw="lower",
            units="mm",
            coordinate_system="RAS",
            anatomical_identity="lower_arch",
        )
        store_retainer_record(self.case_folder, record1)
        store_retainer_record(self.case_folder, record2)

        ids = list(Path(self.case_folder / "retainers").glob("*.json"))
        self.assertEqual(len(ids), 2)


if __name__ == "__main__":
    unittest.main()