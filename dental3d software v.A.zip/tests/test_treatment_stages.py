import json
import tempfile
import unittest
from pathlib import Path

import pyvista as pv

from dental3d.persistence.case_store import CaseStore, CaseStoreError
from dental3d.validation.mesh_validation import load_and_validate_mesh


class TreatmentStageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = CaseStore(self.root / "cases")
        self.case = self.store.create_case(case_id="CASE-STAGES")

    def tearDown(self):
        self.temp.cleanup()

    def add_scan(self, name, stage_id=None, anatomy="upper_arch"):
        source = self.root / name
        pv.Sphere(theta_resolution=10, phi_resolution=8).triangulate().save(source)
        return self.store.add_scan(self.case, load_and_validate_mesh(source), unit="mm",
                                   anatomical_identity=anatomy, stage_id=stage_id)

    def test_new_case_has_persistent_mandatory_endpoints(self):
        stages = self.case.ordered_stages()
        self.assertEqual([(stage.name, stage.stage_type) for stage in stages],
                         [("Initial", "initial"), ("Final", "final")])
        reopened = self.store.load_case(self.case.case_folder)
        self.assertEqual([stage.stage_id for stage in reopened.ordered_stages()],
                         [stage.stage_id for stage in stages])

    def test_intermediates_can_be_edited_and_reordered_between_endpoints(self):
        first = self.store.create_stage(self.case, "Progress 1", "First review", "2026-01-01")
        second = self.store.create_stage(self.case, "Progress 2")
        self.store.update_stage(self.case, first.stage_id, name="Review", description="Updated", stage_date=None)
        self.store.reorder_intermediate_stages(self.case, [second.stage_id, first.stage_id])
        self.assertEqual([stage.name for stage in self.case.ordered_stages()],
                         ["Initial", "Progress 2", "Review", "Final"])
        self.assertEqual(self.store.load_case(self.case.case_folder).find_stage(first.stage_id).description, "Updated")

    def test_assignment_moving_unassigning_and_stage_deletion_preserve_files_and_hashes(self):
        intermediate = self.store.create_stage(self.case, "Progress")
        scan = self.add_scan("upper.stl", intermediate.stage_id)
        source_hash, source = scan.sha256, Path(scan.original_source_path)
        managed = self.case.case_folder / "scans" / scan.managed_filename
        self.store.assign_scan_to_stage(self.case, scan.scan_id, None)
        self.assertIsNone(scan.stage_id)
        self.store.assign_scan_to_stage(self.case, scan.scan_id, intermediate.stage_id)
        with self.assertRaisesRegex(CaseStoreError, "Confirm moving"):
            self.store.delete_stage(self.case, intermediate.stage_id)
        self.store.delete_stage(self.case, intermediate.stage_id, unassign_scans=True)
        self.assertIsNone(scan.stage_id)
        self.assertTrue(source.is_file())
        self.assertTrue(managed.is_file())
        self.assertEqual(scan.sha256, source_hash)

    def test_mandatory_stages_cannot_be_deleted_and_empty_stages_are_valid(self):
        initial, final = self.case.ordered_stages()
        with self.assertRaisesRegex(CaseStoreError, "cannot be deleted"):
            self.store.delete_stage(self.case, initial.stage_id)
        with self.assertRaisesRegex(CaseStoreError, "cannot be deleted"):
            self.store.delete_stage(self.case, final.stage_id)
        self.assertEqual(len(self.case.scans), 0)

    def test_schema_one_case_migrates_without_guessing_scan_stage_or_changing_hash(self):
        scan = self.add_scan("legacy.stl")
        metadata = self.case.case_folder / "case.json"
        payload = json.loads(metadata.read_text(encoding="utf-8"))
        payload["schema_version"] = 1
        payload.pop("stages")
        payload["scans"][0].pop("stage_id")
        metadata.write_text(json.dumps(payload), encoding="utf-8")
        reopened = self.store.load_case(self.case.case_folder)
        self.assertEqual([stage.stage_type for stage in reopened.ordered_stages()], ["initial", "final"])
        self.assertIsNone(reopened.scans[0].stage_id)
        self.assertEqual(reopened.scans[0].sha256, scan.sha256)
        self.store.save_case(reopened)
        migrated = json.loads(metadata.read_text(encoding="utf-8"))
        self.assertEqual(migrated["schema_version"], 2)
        self.assertEqual(len(migrated["stages"]), 2)


if __name__ == "__main__":
    unittest.main()
