import tempfile
import unittest
from pathlib import Path

import numpy as np
import pyvista as pv

from dental3d.validation.mesh_validation import load_and_validate_mesh


class MeshValidationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.mesh = pv.Sphere(theta_resolution=12, phi_resolution=10).triangulate()

    def tearDown(self):
        self.temp.cleanup()

    def test_valid_stl_has_hash_counts_bounds_and_unknown_units(self):
        path = self.root / "upper.stl"
        self.mesh.save(path)
        result = load_and_validate_mesh(path)
        self.assertEqual(result.metadata.file_format, ".stl")
        self.assertIsNone(result.metadata.declared_units)
        self.assertGreater(result.point_count, 0)
        self.assertGreater(result.face_count, 0)
        self.assertEqual(len(result.dimensions), 3)
        self.assertTrue(result.is_triangular_surface)
        self.assertEqual(len(result.sha256), 64)
        self.assertGreater(result.file_size_bytes, 0)

    def test_valid_ply_loads(self):
        path = self.root / "lower.ply"
        self.mesh.save(path, binary=False)
        result = load_and_validate_mesh(path)
        self.assertEqual(result.metadata.file_format, ".ply")
        self.assertGreater(result.face_count, 0)

    def test_rejects_missing_empty_unsupported_and_faceless_files(self):
        with self.assertRaisesRegex(ValueError, "does not exist"):
            load_and_validate_mesh(self.root / "missing.stl")
        empty = self.root / "empty.stl"
        empty.write_bytes(b"")
        with self.assertRaisesRegex(ValueError, "empty"):
            load_and_validate_mesh(empty)
        unsupported = self.root / "mesh.obj"
        unsupported.write_text("", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "Unsupported"):
            load_and_validate_mesh(unsupported)
        faceless = self.root / "points.ply"
        pv.PolyData(np.array([[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1]], dtype=float)).save(
            faceless, binary=False)
        with self.assertRaisesRegex(ValueError, "polygon surface"):
            load_and_validate_mesh(faceless)

    def test_rejects_non_finite_coordinates_in_ascii_ply(self):
        path = self.root / "non-finite.ply"
        mesh = self.mesh.copy()
        points = mesh.points.copy()
        points[0, 0] = np.nan
        mesh.points = points
        mesh.save(path, binary=False)
        with self.assertRaisesRegex(ValueError, "non-finite"):
            load_and_validate_mesh(path)

    def test_rejects_zero_spatial_extent(self):
        path = self.root / "flat.stl"
        flat = pv.Plane(i_resolution=2, j_resolution=2).triangulate()
        flat.points[:, 2] = 0.0
        flat.save(path)
        with self.assertRaisesRegex(ValueError, "zero-size"):
            load_and_validate_mesh(path)


if __name__ == "__main__":
    unittest.main()
