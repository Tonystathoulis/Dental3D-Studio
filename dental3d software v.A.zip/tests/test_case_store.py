import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import pyvista as pv

from dental3d.domain.case_manager import CaseManager
from dental3d.persistence.case_store import CaseStore, CaseStoreError
from dental3d.validation.mesh_validation import load_and_validate_mesh


class CaseStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = CaseStore(self.root / "cases")

    def tearDown(self):
        self.temp.cleanup()

    def make_scan(self, name="scan.stl"):
        source = self.root / "source" / name
        source.parent.mkdir(exist_ok=True)
        pv.Sphere(theta_resolution=12, phi_resolution=10).triangulate().save(source)
        return source, load_and_validate_mesh(source)

    def test_create_save_reopen_case_and_record_dates(self):
        case = self.store.create_case("PATIENT-ALPHA", "Initial scan review", case_id="CASE-ALPHA-01")
        self.assertTrue((case.case_folder / "case.json").is_file())
        self.assertTrue((case.case_folder / "scans").is_dir())
        self.assertTrue((case.case_folder / "analysis").is_dir())
        self.assertTrue((case.case_folder / "reports").is_dir())
        self.assertEqual(case.created_at_utc, case.last_modified_utc)
        self.store.save_case(case)
        reopened = self.store.load_case(case.case_folder)
        self.assertEqual(reopened.case_id, "CASE-ALPHA-01")
        self.assertEqual(reopened.patient_reference, "PATIENT-ALPHA")
        self.assertTrue(reopened.last_modified_utc)

    def test_generated_case_ids_are_unique(self):
        first = self.store.create_case()
        second = self.store.create_case()
        self.assertNotEqual(first.case_id, second.case_id)
        self.assertTrue(first.case_id.startswith("CASE-"))
        self.assertTrue(second.case_id.startswith("CASE-"))

    def test_duplicate_case_id_does_not_overwrite(self):
        case = self.store.create_case(case_id="CASE-DUPLICATE")
        metadata_path = case.case_folder / "case.json"
        original = metadata_path.read_bytes()
        with self.assertRaises(CaseStoreError):
            self.store.create_case(case_id="CASE-DUPLICATE")
        self.assertEqual(metadata_path.read_bytes(), original)

    def test_missing_and_malformed_case_metadata_are_reported(self):
        missing = self.root / "missing"
        missing.mkdir()
        with self.assertRaisesRegex(CaseStoreError, "missing"):
            self.store.load_case(missing)
        malformed = self.root / "CASE-BAD"
        malformed.mkdir()
        (malformed / "case.json").write_text("{broken", encoding="utf-8")
        with self.assertRaisesRegex(CaseStoreError, "Could not read"):
            self.store.load_case(malformed)
        incomplete = self.root / "CASE-INCOMPLETE"
        incomplete.mkdir()
        (incomplete / "case.json").write_text(json.dumps({"schema_version": 1}), encoding="utf-8")
        with self.assertRaisesRegex(CaseStoreError, "incomplete"):
            self.store.load_case(incomplete)

    def test_import_copies_file_with_provenance_hash_and_unknown_unit(self):
        case = self.store.create_case(case_id="CASE-IMPORT")
        source, validated = self.make_scan("same.stl")
        scan = self.store.add_scan(
            case, validated, label="Upper Jaw", unit="unknown",
            anatomical_identity="upper_arch", coordinate_system="RAS",
            coordinate_system_evidence="Documented dataset frame",
        )
        self.assertTrue(source.is_file(), "The original scan must remain untouched.")
        managed = case.case_folder / "scans" / scan.managed_filename
        self.assertTrue(managed.is_file())
        self.assertNotEqual(managed, source)
        self.assertEqual(scan.original_source_path, str(source.resolve()))
        self.assertEqual(scan.unit, "unknown")
        self.assertEqual(scan.sha256, hashlib.sha256(source.read_bytes()).hexdigest())
        self.assertEqual(hashlib.sha256(managed.read_bytes()).hexdigest(), scan.sha256)
        reopened = self.store.load_case(case.case_folder)
        self.assertEqual(reopened.scans[0].label, "Upper Jaw")
        self.assertEqual(reopened.scans[0].unit, "unknown")
        self.assertEqual(reopened.scans[0].anatomical_identity, "upper_arch")
        self.assertEqual(reopened.scans[0].coordinate_system, "RAS")
        self.assertEqual(reopened.scans[0].coordinate_system_evidence, "Documented dataset frame")

    def test_units_and_coordinate_metadata_persist_and_analysis_override_is_not_a_source_edit(self):
        case = self.store.create_case(case_id="CASE-METADATA")
        _, validated = self.make_scan("metadata.stl")
        scan = self.store.add_scan(
            case, validated, label="Upper arch", unit="mm", unit_evidence="Import dialog selection",
            anatomical_identity="upper_arch", coordinate_system="RAS",
            coordinate_frame_id="fixture-frame-01",
            coordinate_system_evidence="Fixture documentation",
        )
        self.store.update_scan_coordinate_metadata(
            case, scan.scan_id, coordinate_system="RAS", coordinate_frame_id="fixture-frame-01",
            coordinate_system_evidence="Fixture documentation; confirmed from scan header notes",
        )
        reopened = self.store.load_case(case.case_folder)
        restored = reopened.find_scan(scan.scan_id)
        self.assertEqual(restored.unit, "mm")
        self.assertEqual(restored.unit_evidence, "Import dialog selection")
        self.assertEqual(restored.coordinate_system, "RAS")
        self.assertEqual(restored.coordinate_frame_id, "fixture-frame-01")
        self.assertIn("scan header notes", restored.coordinate_system_evidence)
        # Analysis overrides live in analysis/UI state and never mutate this persisted record.
        source_unit = restored.unit
        analysis_override = "cm"
        self.assertNotEqual(analysis_override, source_unit)
        self.assertEqual(restored.unit, "mm")

    def test_legacy_scan_metadata_defaults_to_unknown_without_inference(self):
        case = self.store.create_case(case_id="CASE-LEGACY")
        _, validated = self.make_scan("legacy.stl")
        scan = self.store.add_scan(case, validated, unit="mm")
        path = case.case_folder / "case.json"
        payload = json.loads(path.read_text(encoding="utf-8"))
        for key in ("unit_evidence", "coordinate_frame_id"):
            payload["scans"][0].pop(key, None)
        path.write_text(json.dumps(payload), encoding="utf-8")
        reopened = self.store.load_case(case.case_folder)
        restored = reopened.find_scan(scan.scan_id)
        self.assertEqual(restored.unit, "mm")
        self.assertEqual(restored.unit_evidence, "")
        self.assertEqual(restored.coordinate_frame_id, "unknown")

    def test_duplicate_filenames_get_distinct_managed_paths(self):
        case = self.store.create_case(case_id="CASE-DUPFILES")
        source, validated = self.make_scan("repeat.stl")
        first = self.store.add_scan(case, validated)
        second = self.store.add_scan(case, validated)
        self.assertEqual(first.original_filename, second.original_filename)
        self.assertNotEqual(first.managed_filename, second.managed_filename)
        self.assertEqual(len(list((case.case_folder / "scans").iterdir())), 2)

    def test_failed_import_leaves_case_metadata_and_scan_folder_unchanged(self):
        case = self.store.create_case(case_id="CASE-ROLLBACK")
        metadata_path = case.case_folder / "case.json"
        before = metadata_path.read_bytes()
        invalid = self.root / "invalid.stl"
        invalid.write_bytes(b"not an stl mesh")
        with self.assertRaises(ValueError):
            validated = load_and_validate_mesh(invalid)
            self.store.add_scan(case, validated)
        self.assertEqual(metadata_path.read_bytes(), before)
        self.assertEqual(case.scans, [])
        self.assertEqual(list((case.case_folder / "scans").iterdir()), [])

    def test_tampered_managed_copy_is_not_loaded(self):
        case = self.store.create_case(case_id="CASE-TAMPER")
        _, validated = self.make_scan()
        scan = self.store.add_scan(case, validated)
        (case.case_folder / "scans" / scan.managed_filename).write_bytes(b"changed")
        with self.assertRaisesRegex(CaseStoreError, "checksum"):
            self.store.load_scan_mesh(case, scan)

    def test_metadata_write_failure_rolls_back_managed_copy_and_case_state(self):
        case = self.store.create_case(case_id="CASE-WRITE-FAIL")
        source, validated = self.make_scan("write-fail.stl")
        before = (case.case_folder / "case.json").read_bytes()
        with patch.object(self.store, "_write_metadata", side_effect=OSError("simulated storage failure")):
            with self.assertRaises(CaseStoreError):
                self.store.add_scan(case, validated)
        self.assertEqual(case.scans, [])
        self.assertEqual((case.case_folder / "case.json").read_bytes(), before)
        self.assertEqual(list((case.case_folder / "scans").iterdir()), [])
        self.assertTrue(source.is_file())

    def test_remove_scan_never_deletes_original_source(self):
        case = self.store.create_case(case_id="CASE-REMOVE")
        source, validated = self.make_scan("keep-original.stl")
        scan = self.store.add_scan(case, validated)
        managed = case.case_folder / "scans" / scan.managed_filename
        self.store.remove_scan(case, scan.scan_id)
        self.assertTrue(source.is_file())
        self.assertFalse(managed.exists())
        self.assertEqual(case.scans, [])

    def test_case_manager_selects_only_scans_in_active_case(self):
        case = self.store.create_case(case_id="CASE-STATE")
        manager = CaseManager()
        manager.open_case(case)
        self.assertEqual(manager.case_id, case.case_id)
        with self.assertRaises(ValueError):
            manager.select_scan("not-in-case")
        manager.close_case()
        self.assertIsNone(manager.case_id)

    def test_viewport_guidance_state_transitions(self):
        case = self.store.create_case(case_id="CASE-VIEWPORT")
        manager = CaseManager()
        self.assertEqual(manager.viewport_state, "no_case")

        manager.open_case(case)
        self.assertEqual(manager.viewport_state, "empty_case")

        _, validated = self.make_scan()
        scan = self.store.add_scan(case, validated)
        self.assertEqual(manager.viewport_state, "scan_unselected")
        manager.select_scan(scan.scan_id)
        self.assertEqual(manager.viewport_state, "scan_loaded")

        manager.select_scan(None)
        self.assertEqual(manager.viewport_state, "scan_unselected")
        self.store.remove_scan(case, scan.scan_id)
        self.assertEqual(manager.viewport_state, "empty_case")

        manager.close_case()
        self.assertEqual(manager.viewport_state, "no_case")


if __name__ == "__main__":
    unittest.main()
