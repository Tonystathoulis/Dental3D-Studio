import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import unittest

import vtk
from PySide6.QtWidgets import QApplication

from dental3d.ui.main_window import CtrlRotateTrackballStyle, DentalStudioWindow


class ViewportControlTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_ctrl_left_drag_rotates_shift_left_drag_pans_and_plain_drag_is_ignored(self):
        window = vtk.vtkRenderWindow()
        window.SetOffScreenRendering(1)
        window.AddRenderer(vtk.vtkRenderer())
        interactor = vtk.vtkRenderWindowInteractor()
        interactor.SetRenderWindow(window)
        style = CtrlRotateTrackballStyle()
        interactor.SetInteractorStyle(style)
        interactor.SetEventPosition(100, 100)

        interactor.SetControlKey(1)
        style.OnLeftButtonDown()
        self.assertEqual(style.GetState(), vtk.VTKIS_ROTATE)
        style.OnLeftButtonUp()

        interactor.SetControlKey(0)
        interactor.SetShiftKey(1)
        style.OnLeftButtonDown()
        self.assertEqual(style.GetState(), vtk.VTKIS_PAN)
        style.OnLeftButtonUp()

        interactor.SetShiftKey(0)
        style.OnLeftButtonDown()
        self.assertEqual(style.GetState(), vtk.VTKIS_NONE)

    def test_viewport_hint_has_only_the_documented_controls_and_can_wrap(self):
        window = DentalStudioWindow()
        try:
            hint = window.controls_hint
            self.assertEqual(hint.text(), "CTRL DRAG TO ROTATE · SHIFT + DRAG TO PAN")
            self.assertNotIn("SCROLL TO ZOOM", hint.text())
            self.assertTrue(hint.wordWrap())
            self.assertEqual(hint.minimumWidth(), 0)
        finally:
            window.close()
            window.plotter.close()


if __name__ == "__main__":
    unittest.main()
