"""Dental3D Studio desktop entry point."""
from dental3d.ui.main_window import launch


if __name__ == "__main__":
    launch()
